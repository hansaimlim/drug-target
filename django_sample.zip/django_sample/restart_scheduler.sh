#!/bin/bash

echo 'Restarting celery beat and workers...'
kill -9 $(ps aux | grep celery | grep -v grep | awk '{print $2}' | tr '\n'  ' ') > /dev/null 2>&1
sleep 10
rm logs/celery.*
celery -A config.celery_app beat -l info --logfile=logs/celery.beat.log --detach
celery -A config.celery_app worker -l info --logfile=logs/celery.log --detach
echo 'Celery restart complete.'