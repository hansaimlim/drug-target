"""Gunicorn *development* config file"""

# Django WSGI application path in pattern MODULE_NAME:VARIABLE_NAME
wsgi_app = "config.wsgi:application"
# The granularity of Error log outputs
loglevel = "info"
# The number of worker processes for handling requests
workers = 4
# The socket to bind
bind = "0.0.0.0:61875"
# Restart workers when code changes (development only!)
reload = True
# Write access and error info to /var/log
accesslog = errorlog = "/app/limh25/flu/logs/gunicorn_dev.log"
# Redirect stdout/stderr to log file
capture_output = True
# PID file so you can easily fetch process ID
pidfile = "/app/limh25/flu/logs/dev.pid"
# Daemonize the Gunicorn process (detach & enter background)
daemon = True

timeout = 1200