from django.http import Http404
from django.db.models import Sum, Count, Q
import datetime
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework import permissions
from biorxiv import models as biorxiv_models
from biorxiv.serializers import ArticleSerializer
from googlenews import models as googlenews_models
from googlenews.serializers import GoogleNewsSerializer
# Create your views here.


class KeywordPreprintList(APIView):
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get(self, request, format=None, keyword='', max_count=5):
        articles = biorxiv_models.Article.objects.filter(
                Q(title__icontains=keyword) |
                Q(abstract__icontains=keyword)
            ).order_by('-date')[:max_count]
        serializer = ArticleSerializer(articles, many=True)
        return Response(serializer.data)

    def post(self, request, format=None, keyword='', max_count=5):
        articles = biorxiv_models.Article.objects.filter(
                Q(title__icontains=keyword) |
                Q(abstract__icontains=keyword)
            ).order_by('-date')[:max_count]
        serializer = ArticleSerializer(articles, many=True)
        return Response(serializer.data)


class KeywordGoogleNewsList(APIView):
    permission_classes = [permissions.IsAuthenticatedOrReadOnly]

    def get(self, request, format=None, keyword='', max_count=5):
        articles = googlenews_models.GoogleNewsRawData.objects.filter(
            Q(title__icontains=keyword) |
            Q(snippet__icontains=keyword)
        ).order_by('-date')[:max_count]
        serializer = GoogleNewsSerializer(articles, many=True)
        return Response(serializer.data)

    def post(self, request, format=None, keyword='', max_count=5):
        articles = googlenews_models.GoogleNewsRawData.objects.filter(
            Q(title__icontains=keyword) |
            Q(snippet__icontains=keyword)
        ).order_by('-date')[:max_count]
        serializer = GoogleNewsSerializer(articles, many=True)
        return Response(serializer.data)

# class KeywordArticleList(APIView):
#     """
#     List of biorxiv and googlenews articles containing the given keyword
#     """

#     def get(self, request, format=None, keyword=''):

        
#         googlenews_articles = googlenews_models.GoogleNewsRawData.objects.filter(
#             Q(title__icontains=keyword) |
#             Q(snippet__icontains=keyword)
#         ).order_by('-date')
