from django.urls import path, reverse_lazy
from api import views
from django.views.generic import TemplateView

app_name = 'api'
urlpatterns = [
    path('biorxiv', views.KeywordPreprintList.as_view(), name='biorxiv_keyword_post'),
    path('googlenews', views.KeywordGoogleNewsList.as_view(), name='googlenews_keyword_post'),
    path('biorxiv/<str:keyword>/', views.KeywordPreprintList.as_view(), name='biorxiv_keyword'),
    path('googlenews/<str:keyword>/', views.KeywordGoogleNewsList.as_view(), name='googlenews_keyword'),
]