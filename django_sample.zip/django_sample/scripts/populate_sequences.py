import os
import re
import time
import numpy as np
import pandas as pd
import json
from Bio import pairwise2
from Bio import SeqIO
from Bio.Align import substitution_matrices
from datetime import datetime
from django.conf import settings
from proteins import utils
from proteins import models



def run():
    segment_sequence_dir = settings.SEGMENT_SEQUENCE_DIR
    segment_sequence_files = [f for f in os.listdir(segment_sequence_dir) if f.endswith('.fasta')]

    since = time.time()
    count = 0
    for f in segment_sequence_files:
        seqs = SeqIO.parse(os.path.join(segment_sequence_dir, f), 'fasta')
        segment_info = f.strip().split('.')[0].split('_')
        if segment_info[0] == 'A':
            subtype, _ = models.MoleculeSubtype.objects.get_or_create(name=segment_info[1])
            seg = segment_info[1][0]  # H or N
        elif segment_info[0] == 'B':
            seg = segment_info[2][0]  # H or N
            if segment_info[1] == 'UNK':
                subtype, _ = models.MoleculeSubtype.objects.get_or_create(name='B-Unknown')
            elif segment_info[1] == 'Vic':
                subtype, _ = models.MoleculeSubtype.objects.get_or_create(name='B-Victoria')
            elif segment_info[1] == 'Yam':
                subtype, _ = models.MoleculeSubtype.objects.get_or_create(name='B-Yamagata')
            else:
                raise ValueError("Cannot parse segment information from filename {}".format(f))
        else:
            raise ValueError("Cannot parse segment information from filename {}".format(f))

        if seg == 'H':
            Segment = models.Hemagglutinin
        elif seg == 'N':
            Segment = models.Neuraminidase
        else:
            raise ValueError("Invalid segment type. {}".format(seg))

        for seq in seqs:
            seqid = seq.id
            ids = seqid.strip().split('|')
            if len(ids) < 8:
                # sequence id not well-formatted
                continue
            isolate_id = ids[0]
            isolate = models.Isolate.objects.filter(accession=isolate_id).first()
            if not isolate:
                continue
            molecule_id = ids[6]
            s, created = Segment.objects.get_or_create(
                accession=molecule_id,
                subtype=subtype,
                isolate=isolate,
                sequence=str(seq.seq)
            )
            if created:
                count += 1

    elapsed = (time.time() - since)/60.0

    print("Complete. Created {} sequences from {} files. {:.2f} minutes elapsed.".format(
        count, len(segment_sequence_files), elapsed))

            
    
