import os
import numpy as np
import json
import pandas as pd
from Bio import pairwise2
from Bio import SeqIO
from Bio.Align import substitution_matrices
from django.conf import settings
from proteins import utils
from proteins import models
from proteins import sequence_alignment as sa

def align_ha():

    refs = models.ReferenceHemagglutinin.objects.all().order_by()
    has = models.Hemagglutinin.objects.all().order_by()
    count = 0
    count_created = 0
    max_count = refs.count() * has.count()
    for ref in refs:
        for ha in has:
            aln = sa.pairwise_align(ref_seq=ref.sequence, query_seq=ha.sequence, clean=True)
            ref_aln = aln['reference_aligned']
            query_aln = aln['query_aligned']
            score = aln['score']
            aln_obj, created = models.PairwiseAlignedHemagglutinin.objects.get_or_create(
                query=ha, reference=ref,
                score=score,
                query_aligned=query_aln,
                reference_aligned=ref_aln,
            )

            count += 1
            if created:
                count_created += 1
            if count % 1000:
                print("... Created {} alignment objects. ({}/{}) alignments processed.".format(count_created, count, max_count))
    print("HA alignment complete. Attemted {} HA against {} refs. {} new alignment populated.".format(
        has.count(), refs.count(), count_created
    ))


def run():
    align_ha()

