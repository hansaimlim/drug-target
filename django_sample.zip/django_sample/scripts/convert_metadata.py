import os
import numpy as np
import pandas as pd
import json
from datetime import datetime
from django.conf import settings
from proteins import utils

def get_metadata():
    metadata_files = [f for f in os.listdir(settings.GISAID_METADATA_XLS_DIR) if f.endswith('.xls')]
    metas = [pd.read_excel(os.path.join(settings.GISAID_METADATA_XLS_DIR, f)) for f in metadata_files]
    return metas

def run():
    # settings.GISAID_METADATA_XLS_DIR  # only contains .xls files downloaded from gisaid
    # settings.GISAID_METADATA_JSON_DIR

    today = datetime.today()
    isolate_info = {} # isolate_id -> dict
    metas = get_metadata()

    total_count = 0
    nonhuman_skipped = 0

    for meta in metas:
        for idx, row in meta.iterrows():
            host = row['Host']
            if type(host) != str:
                host = 'Unknown'

            isolate_id = row['Isolate_Id']
            lineage = row['Lineage']
            subtype = row['Subtype']
            passage = row['Passage_History']
            location = row['Location']
            collection_date = row['Collection_Date']
            submission_date = row['Submission_Date']
            # segment ids:
            # 'PB2 Segment_Id', 'PB1 Segment_Id', 'PA Segment_Id', 
            # 'HA Segment_Id', 'NP Segment_Id', 'NA Segment_Id', 
            # 'MP Segment_Id', 'NS Segment_Id', 'HE Segment_Id', 'P3 Segment_Id'
            if type(row['HA Segment_Id']) == str:
                ha_id = row['HA Segment_Id'].strip().split('|')[0]
            else:
                ha_id = None
            if type(row['NA Segment_Id']) == str:
                na_id = row['NA Segment_Id'].strip().split('|')[0]
            else:
                na_id = None
            if type(row['PB1 Segment_Id']) == str:
                pb1_id = row['PB1 Segment_Id'].strip().split('|')[0]
            else:
                pb1_id = None
            if type(row['PB2 Segment_Id']) == str:
                pb2_id = row['PB2 Segment_Id'].strip().split('|')[0]
            else:
                pb2_id = None
            if type(row['PA Segment_Id']) == str:
                pa_id = row['PA Segment_Id'].strip().split('|')[0]
            else:
                pa_id = None
            if type(row['NP Segment_Id']) == str:
                np_id = row['NP Segment_Id'].strip().split('|')[0]
            else:
                np_id = None
            if type(row['MP Segment_Id']) == str:
                mp_id = row['MP Segment_Id'].strip().split('|')[0]
            else:
                mp_id = None
            if type(row['NS Segment_Id']) == str:
                ns_id = row['NS Segment_Id'].strip().split('|')[0]
            else:
                ns_id = None
            if type(row['HE Segment_Id']) == str:
                he_id = row['HE Segment_Id'].strip().split('|')[0]
            else:
                he_id = None
            if type(row['P3 Segment_Id']) == str:
                p3_id = row['P3 Segment_Id'].strip().split('|')[0]
            else:
                p3_id = None

            isolate_name = row['Isolate_Name']
            submit_lab = row['Submitting_Lab']
            origin_lab = row['Originating_Lab']
            
            host_age = row['Host_Age']
            host_age_unit = row['Host_Age_Unit']
            host_gender = row['Host_Gender']
            d = {
                'isolate_id'     : isolate_id,
                'isolate_name'   : isolate_name,
                'subtype'        : subtype,
                'lineage'        : lineage,
                'passage'        : passage,
                'location'       : location,
                'collection_date': collection_date,
                'submission_date': submission_date,
                'ha_id'          : ha_id,
                'na_id'          : na_id,
                'pb1_id'         : pb1_id,
                'pb2_id'         : pb2_id,
                'pa_id'          : pa_id,
                'p3_id'          : p3_id,
                'np_id'          : np_id,
                'mp_id'          : mp_id,
                'ns_id'          : ns_id,
                'he_id'          : he_id,
                'submit_lab'     : submit_lab,
                'origin_lab'     : origin_lab,
                'host'           : host,
                'host_age'       : host_age,
                'host_age_unit'  : host_age_unit,
                'host_gender'    : host_gender,
            }
            isolate_info[isolate_id] = d
            total_count += 1
    output_file_dated = os.path.join(settings.GISAID_METADATA_JSON_DIR, "metadata_{}-{}-{}.json".format(today.year, today.month, today.day))
    utils.save_json(isolate_info, output_file_dated)
    output_file_latest = os.path.join(settings.GISAID_METADATA_JSON_DIR, "metadata_latest.json")  # overwritten every time
    utils.save_json(isolate_info, output_file_latest)
    print("Complete. {} isolate records written to {} ({} non-human records excluded)".format(
        total_count, output_file_dated, nonhuman_skipped
    ))