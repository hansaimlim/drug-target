import os
import numpy as np
import pandas as pd
import json
import time
from datetime import datetime
from django.conf import settings
from proteins import utils
from proteins import passage
from proteins import models

def get_data_stat(metas, convert_dict):
    since = time.time()
    count = {
        'total': 0,
        'passage_known': 0,
        'passage_unknown': 0,
        'original': 0,
        'egg_passaged': 0,
        'cell_passaged': 0,

    }
    for meta in metas:
        meta = meta.replace(np.nan, '', regex=True)
        for idx, row in meta.iterrows():
            passage = row['Passage_History'].strip().lstrip()
            conv = convert_dict[passage]
            if conv['passage_known']:
                count['passage_known'] += 1
                if not conv['is_passaged']:
                    count['original'] += 1
                else:
                    if conv['cell_passaged']:
                        count['cell_passaged'] += 1
                    elif conv['egg_passaged']:
                        count['egg_passaged'] += 1
            else:
                count['passage_unknown'] += 1
            count['total'] += 1
    elapsed = (time.time() - since)/60.0
    print("Done. {:.2f} minutes elapsed.".format(elapsed))
    print(count)

def get_unique_passages(metas):
    unique_passages = []
    for meta in metas:
        meta = meta.replace(np.nan, '', regex=True)
        p = list(meta['Passage_History'].unique())
        unique_passages += p
    unique_passages = list(set(unique_passages))
    unique_passages = [p.strip().lstrip() for p in unique_passages]
    print("Collected {} unique passage strings from {} metadata files.".format(
        len(unique_passages), len(metas)
    ))
    return unique_passages

def get_metadata():
    metadata_files = [f for f in os.listdir(settings.GISAID_METADATA_XLS_DIR) if f.endswith('.xls')]
    metas = [pd.read_excel(os.path.join(settings.GISAID_METADATA_XLS_DIR, f)) for f in metadata_files]
    return metas

def populate_db(info_dict):
    count = 0
    for pa in info_dict.keys():
        info = info_dict[pa]
        name = info['passage_original']
        standard_name = info['passage_converted']
        is_known = info['passage_known']
        is_passaged = info['is_passaged']
        is_egg_passaged = info['egg_passaged']
        is_cell_passaged = info['cell_passaged']
        p = models.Passage.objects.create(
            name=name, standardized_name=standard_name,
            is_known=is_known, is_passaged=is_passaged,
            is_egg_passaged=is_egg_passaged,
            is_cell_passaged=is_cell_passaged
        )
        count += 1
    print("Populate db complete. {} Passage objects created.".format(count))
    

def run():
    metas = get_metadata()
    unique_passages = get_unique_passages(metas)
    unique_passages_converted = {}

    outfile1 = os.path.join(settings.MEDIA_ROOT, "gisaid_data_stat/unique_passages.txt")
    outfile2 = os.path.join(settings.MEDIA_ROOT, "gisaid_data_stat/unique_passages_converted.txt")
    outfile3 = os.path.join(settings.MEDIA_ROOT, "gisaid_data_stat/unique_passages_unknown.txt")
    outfile4 = os.path.join(settings.MEDIA_ROOT, "gisaid_data_stat/passage_convert_dict.json")
    
    with open(outfile1, 'w') as out:
        for p in unique_passages:
            out.write("{}\n".format(p))

    for p in unique_passages:
        pas = passage.convert_passage(p)
        unique_passages_converted[p] = pas

    utils.save_json(unique_passages_converted, outfile4)

    with open(outfile2, 'w') as out:
        out.write("Passage_string\tConverted_passages\tPassage_is_known\tIs_passaged\tCell_passaged\tEgg_passaged\n")
        for p in unique_passages_converted:
            info = unique_passages_converted[p]
            if not info['passage_known']:
                continue
            out.write("{}\t{}\t{}\t{}\t{}\t{}\n".format(
                info['passage_original'], info['passage_converted'], info['passage_known'], 
                info['is_passaged'], info['cell_passaged'], info['egg_passaged']))
    
    with open(outfile3, 'w') as out:
        out.write("Passage_string\tConverted_passages\tPassage_is_known\tIs_passaged\tCell_passaged\tEgg_passaged\n")
        for p in unique_passages_converted:
            info = unique_passages_converted[p]
            if not info['passage_known']:
                out.write("{}\t{}\t{}\t{}\t{}\t{}\n".format(
                info['passage_original'], info['passage_converted'], info['passage_known'], 
                info['is_passaged'], info['cell_passaged'], info['egg_passaged']))

    get_data_stat(metas, unique_passages_converted)
    populate_db(unique_passages_converted)

    