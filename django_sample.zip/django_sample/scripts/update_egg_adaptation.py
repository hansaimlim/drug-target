import os
import sys
import re
import csv
import time
import numpy as np
import pandas as pd
import json
import tqdm
from datetime import datetime
from django.conf import settings
from proteins import utils
from proteins import models
import scipy.stats as stats
from Bio import SeqIO, Seq, AlignIO
from proteins import sequence_alignment as sa
from nucleotides import models as nucl_models
from nucleotides import translate as nucl_translate
from annotations import models as annot_models
from annotations import glycosylation as glyco

### global variables
msa_input_dir = os.path.join(settings.MEDIA_ROOT, "HA_MSA_input")
msa_output_dir = os.path.join(settings.MEDIA_ROOT, "HA_MSA_output")
ha_accessions = models.Hemagglutinin.objects.all().order_by().values_list('accession', flat=True)
hs = models.Hemagglutinin.objects.in_bulk(ha_accessions, field_name='accession')
ha_refs = models.ReferenceHemagglutinin.objects.all()
valid_subtypes = ['H3', 'H1', 'B-Unknown', 'B-Yamagata', 'B-Victoria']
valid_aa = ['A','C','D','E','F','G','H','I','K','L','M','N','P','Q','R','S','T','V','W','Y']
fasta_files = {s:os.path.join(msa_input_dir, "{}.fasta".format(s)) for s in valid_subtypes}
ref_files = {s:os.path.join(msa_input_dir, "{}_ref.fasta".format(s)) for s in valid_subtypes}
aln_files = {s:os.path.join(msa_output_dir, "{}.aln".format(s))for s in valid_subtypes}
subtype_objects = {s:models.MoleculeSubtype.objects.filter(name=s).first() for s in valid_subtypes}
isolate_info_file = os.path.join(msa_output_dir, 'Isolate_information.csv')


def collect_passage_info():

    isolate_info_file = os.path.join(msa_output_dir, 'Isolate_information.csv')
    with open(isolate_info_file, 'w') as out:
        out.write('Isolate,HA,Lineage,Clade,Passage,CollectionDate\n')
        for ha_accession in tqdm.tqdm(hs, total=len(hs)):
            h = hs[ha_accession]
            p = h.isolate.passage
            passage_class = ''
            if h.isolate.clade:
                clade_name = h.isolate.clade.full_name
            else:
                clade_name = 'Unassigned'
            
            if not p:
                passage_class = 'Unknown'
            elif not p.is_passaged:
                passage_class = 'Original'
            elif (p.is_egg_passaged) and (not p.is_cell_passaged):
                passage_class = 'Egg'
            elif (not p.is_egg_passaged) and (p.is_cell_passaged):
                passage_class = 'Cell'
            else:
                passage_class = 'Mix'
            out.write('{},{},{},{},{},{}\n'.format(
                h.isolate.accession, h.accession, h.isolate.lineage.name, clade_name, passage_class, h.isolate.collection_date))
            
    # Isolate,HA,Lineage,Clade,Passage,CollectionDate
    # EPI_ISL_523,EPI2453,Unknown,Unassigned,Original,1997-01-01

    isolate2passage = {}
    molecule2passage = {}
    molecule2isolate = {}
    with open(isolate_info_file, 'r') as inf:
        header = next(inf)
        for line in inf:
            line = line.strip().split(',')
            isolate_id = line[0]
            molecule_id = line[1]
            lineage = line[2]
            clade = line[3]
            passage = line[4]  # Original / Egg / Cell / Mix / Unknown
            collection_date = line[5]

            isolate2passage[isolate_id] = passage
            molecule2passage[molecule_id] = passage
            molecule2isolate[molecule_id] = isolate_id
    return {
        'isolate2passage':isolate2passage,
        'molecule2passage':molecule2passage,
        'molecule2isolate':molecule2isolate,
        }


def collect_sequences_per_lineage():
    print("Collecting hemagglutinin sequences...")
    
    sequence_counts = {s:0 for s in valid_subtypes}

    for hr in ha_refs:
        if hr.ha.subtype.name in valid_subtypes:
            fasta_file = os.path.join(msa_input_dir, "{}_ref.fasta".format(hr.ha.subtype.name))
            with open(fasta_file, 'w') as out:
                out.write('>{}|{}|{}|{}|HA\n'.format(
                    hr.ha.isolate.accession, hr.ha.isolate.name, hr.ha.accession, hr.ha.subtype.name))
                out.write('\n'.join([hr.mature_sequence[i:i+60] for i in range(0, len(hr.mature_sequence), 60)]))

    for ha_accession in tqdm.tqdm(hs, total=len(hs)):
        ha = hs[ha_accession]
        if ha.subtype.name in valid_subtypes:
            with open(fasta_files[ha.subtype.name], 'a') as out:
                out.write('>{}|{}|{}|{}|HA\n'.format(
                    ha.isolate.accession, ha.isolate.name, ha.accession, ha.subtype.name
                ))
                out.write('\n'.join([ha.sequence[i:i+60] for i in range(0, len(ha.sequence), 60)]))
                out.write('\n')
            sequence_counts[ha.subtype.name] += 1
    
    print("Complete. {}".format(sequence_counts))


def collect_and_update_enrichment_scores(isolate2passage, update=True):
    enrichment_score_dict = {s:None for s in valid_subtypes}
    print("Collecting egg-adaptation enrichment scores.")
    for s in aln_files:
        print("  Collecting enrichment scores for {}...".format(s))
        aln_file = aln_files[s]
        subtype_obj = subtype_objects[s]
        alignment = AlignIO.read(aln_file, "fasta")
        position_count_matrix = {
            pos: {
            'Original':{aa:0 for aa in valid_aa},
            'Egg':{aa:0 for aa in valid_aa},
            'Cell':{aa:0 for aa in valid_aa},
            'Mix':{aa:0 for aa in valid_aa},
            'Unknown':{aa:0 for aa in valid_aa},
            } for pos in range(len(alignment[0].seq))
        }

        for ali in tqdm.tqdm(alignment, total=len(alignment)):
            isolate_id = ali.description.strip().split('|')[0]
            if isolate_id not in isolate2passage:
                continue
            passage = isolate2passage[isolate_id]
            for pos, aa in enumerate(str(ali.seq)):
                if aa not in valid_aa:
                    continue
                position_count_matrix[pos][passage][aa] += 1

        enrichment_scores = []
        for pos in tqdm.tqdm(position_count_matrix, total=len(position_count_matrix)):
            matrix = position_count_matrix[pos]
            original = np.array([matrix['Original'][aa] for aa in valid_aa])
            egg = np.array([matrix['Egg'][aa] for aa in valid_aa])
            cell = np.array([matrix['Cell'][aa] for aa in valid_aa])
            mix = np.array([matrix['Mix'][aa] for aa in valid_aa])

            # compute enrichment scores
            minimum_appearance = 30
            for o, e, c, m, aa in zip(original, egg, cell, mix, valid_aa):
                non_mix_count = o + e + c
                egg_count = e
                if non_mix_count < minimum_appearance:
                    continue
                enrichment_scores.append({
                    'position': pos,
                    'amino_acid': aa,
                    'mutation': '{}{}'.format(pos, aa),
                    'score': float(egg_count) / float(non_mix_count),
                    'non_mix_count': non_mix_count,
                    'original_count': o,
                    'cell_count': c,
                    'egg_count': e,
                    'mix_count': m,
                })
        enrichment_score_dict[s] = enrichment_scores
        if update:
            print("    Updating enrichment scores...")
            for es in tqdm.tqdm(enrichment_scores, total=len(enrichment_scores)):
                obj, _ = annot_models.EggAdaptationEnrichmentScore.objects.get_or_create(subtype=subtype_obj, position=es['position'], amino_acid=es['amino_acid'])
                if obj.score != es['score']:
                    obj.score = es['score']
                    obj.count_original = es['original_count']
                    obj.count_cell = es['cell_count']
                    obj.count_egg = es['egg_count']
                    obj.save()

    print("Complete.")
    return enrichment_score_dict


def run_mafft():
    """
    mafft --auto --anysymbol --thread -1 --keeplength --addfragments /app/limh25/flu/flu/media/HA_MSA_input/H3.fasta 
      /app/limh25/flu/flu/media/HA_MSA_input/H3_ref.fasta > /app/limh25/flu/flu/media/HA_MSA_output/H3.aln
    """
    cmd = "mafft --auto --quiet --anysymbol --thread -1 --keeplength --addfragments {fasta_file} {ref_file} > {output_file}"

    print("Start MAFFT alignment...")
    for sub in tqdm.tqdm(valid_subtypes, total=len(valid_subtypes)):
        fasta_file = fasta_files[sub]
        ref_file = ref_files[sub]
        output_file = aln_files[sub]
        os.system(cmd.format(fasta_file=fasta_file,ref_file=ref_file,output_file=output_file))
    print("MSA complete.")


def run():
    os.makedirs(msa_input_dir, exist_ok=True)
    os.makedirs(msa_output_dir, exist_ok=True)
    collect_sequences_per_lineage()

    # run alignment
    run_mafft()

    # collect egg-adaptation residues
    passage_dicts = collect_passage_info()
    isolate2passage = passage_dicts['isolate2passage']

    # update to database
    collect_and_update_enrichment_scores(isolate2passage, update=True)

    