import os
import re
import time
import numpy as np
import pandas as pd
import json
from Bio import pairwise2
from Bio import SeqIO
from Bio.Align import substitution_matrices
from datetime import datetime
from django.conf import settings
from proteins import utils
from proteins import models
from proteins import vaccine
from proteins import sequence_alignment as sa
from proteins import epitopes as ep

def populate_vaccine_ref_alignment(reset=False):
    if reset:
        models.VaccineToReferenceHemagglutinin.objects.all().delete()

    vaccines = models.VaccineHemagglutinin.objects.all().order_by()
    refs = models.ReferenceHemagglutinin.objects.all().order_by()

    count = 0
    for ref in refs:
        ref_seq = ref.full_sequence
        for vac in vaccines:
            vac_seq = vac.ha.sequence
            aln = sa.pairwise_align(ref_seq=ref_seq, query_seq=vac_seq)
            ref_aln = aln['reference_aligned']
            vac_aln = aln['query_aligned']
            score = aln['score']

            v2r, created = models.VaccineToReferenceHemagglutinin.objects.get_or_create(
                vaccine=vac, reference=ref,
                score=score, vaccine_aligned=vac_aln, reference_aligned=ref_aln,
                vaccine_start=aln['query_start'], reference_start=aln['reference_start'],
            )
            if created:
                count += 1
    print("Complete. Populated {} vaccine-reference HA alignments.".format(count))

def populate_vaccine_ha(reset=False):
    if reset:
        models.VaccineHemagglutinin.objects.all().delete()

    h3_vaccine_names = list(vaccine.H3N2_VACCINES.keys())
    h1_vaccine_names = list(vaccine.H1N1_VACCINES.keys())
    vic_vaccine_names = list(vaccine.VICTORIA_VACCINES.keys())
    yam_vaccine_names = list(vaccine.YAMAGATA_VACCINES.keys())
    pairs = [
        (h3_vaccine_names, "H3", vaccine.H3N2_VACCINES),
        (h1_vaccine_names, "H1", vaccine.H1N1_VACCINES),
        (vic_vaccine_names, "B", vaccine.VICTORIA_VACCINES),
        (yam_vaccine_names, "B", vaccine.YAMAGATA_VACCINES)
    ]
    count = 0
    for pair in pairs:
        names = pair[0]
        qs = models.Hemagglutinin.objects.filter(subtype__name__icontains=pair[1])
        for name in names:
            vaccine_info = pair[2][name]
            isolate_name = pair[2][name]['name']
            passage = vaccine_info['passage'].lower()  # cell or egg
            years = sorted(vaccine_info['years'])  # list of ascending integers e.g. [2020, 2021]
            latest_vaccine_year = years[-1]  # years is sorted ascending
            isolate_id = vaccine_info.get('isolate_id', '')
            qs_ = qs.filter(accession=isolate_id)
            if qs_.count() == 0:
                if passage == 'egg':
                    qs_ = qs.filter(isolate__name__iexact=isolate_name).filter(isolate__passage__is_known=True).filter(isolate__passage__is_egg_passaged=True)
                else:
                    qs_ = qs.filter(isolate__name__iexact=isolate_name).filter(isolate__passage__is_known=True).filter(isolate__passage__is_cell_passaged=True)
                if qs_.count() > 0:
                    print("  Passage-matching isolate found for {}-{}".format(pair[1], isolate_name))
                else:
                    # reduce filter level
                    qs_ = qs.filter(isolate__name__iexact=isolate_name).filter(isolate__passage__is_known=True)
                    if qs_.count() > 0:
                        print("  Isolate found for {}-{}".format(pair[1], isolate_name))
                    else:
                        qs_ = qs.filter(isolate__name__iexact=isolate_name)
                        if qs_.count() == 0:
                            print("    Vaccine-HA not found. {}: {}.".format(pair[1], isolate_name, qs_.count()))
                            continue
            vh, created = models.VaccineHemagglutinin.objects.get_or_create(
                ha=qs_.first(),
                vaccine_years=years,
                latest_vaccine_year=latest_vaccine_year
            )
            if created:
                count += 1
    print("Complete. {} vaccine hemagglutinin objects created.".format(count))


def populate_ref_ha(reset=False):
    if reset:
        models.ReferenceHemagglutinin.objects.all().delete()
    sequence_dir = settings.HA_REFERENCE_SEQUENCE_DIR
    sequence_files = [f for f in os.listdir(sequence_dir) if f.endswith('fasta')]
    count = 0
    for f in sequence_files:
        seqs = SeqIO.parse(os.path.join(sequence_dir, f), "fasta")
        ref_name = f.strip().split('.')[0]  # e.g. H1_1933 or H1N1pdm from filenames
        epitope_dict = ep.get_epitope_dict_for_reference(ref_name)
        parts = {'mature':'', 'full':'', 'signal':''}
        for seq in seqs:
            seq_info = seq.id.strip().split('|')
            if len(seq_info) < 8:
                raise ValueError(
                    "Sequence header contains insufficient information. e.g. >EPI_ISL_69816|A/United_Kingdom/1/1933|A_/_H1N1|egg_2|seasonal|1933-01-10|EPI242056|HA|mature, Given: {}".format(seq.id))

            molecule_id = seq_info[-3]
            part = seq_info[-1]  # mature | full | signal
            parts[part.lower()] = str(seq.seq)

        r, created = models.ReferenceHemagglutinin.objects.get_or_create(
            ha=models.Hemagglutinin.objects.filter(accession=molecule_id).first(),
            reference_name=ref_name,
            full_sequence=parts['full'],
            mature_sequence=parts['mature'],
            signal_peptide=parts['signal'],
            epitopes=epitope_dict
        )
        if created:
            count += 1
    print("{} reference HA populated.".format(count))

def run():
    populate_ref_ha(reset=True)
    populate_vaccine_ha(reset=True)
    populate_vaccine_ref_alignment()