import os
import numpy as np
import json
import pandas as pd
import time
from Bio import SeqIO
from django.conf import settings
from proteins import utils
from proteins import models
from proteins import structure_info as si
from proteins import sequence_alignment as sa
from proteins import protein_structure as ps
from proteins import epitopes


def write_clade_ha_sequences(clade_name=''):
    # for the given clade
    # write out all HA sequences to one file 'clade_file'
    # also, write out the longest HA to 'clade_longest_file'
    fasta_header = ">{molecule_id}|{isolate_id}|{isolate_name}|HA"
    clade_basedir = settings.CLADE_SEQUENCE_BASE_DIR
    clade_dir = os.path.join(clade_basedir, 'ha')
    os.makedirs(clade_dir, exist_ok=True)
    clade_file = os.path.join(clade_dir, "{}.fasta".format(clade_name))
    clade_longest_file = os.path.join(clade_dir, "{}_longest.fasta".format(clade_name))
    since = time.time()

    has = models.Hemagglutinin.objects.filter(isolate__clade__full_name__iexact=clade_name).order_by()
    longest = {'length':0, 'sequence':'', 'header':''}
    with open(clade_file, "w") as out:
        for ha in has:
            header = fasta_header.format(
                molecule_id=ha.accession, isolate_id=ha.isolate.accession, isolate_name=ha.isolate.name)
            out.write(header+'\n')
            out.write('\n'.join([ha.sequence[i:i+60] for i in range(0, len(ha.sequence), 60)]))
            out.write('\n')
            if len(ha.sequence) > longest['length']:
                longest['length'] = len(ha.sequence)
                longest['sequence'] = ha.sequence
                longest['header'] = header
    with open(clade_longest_file, "w") as out:
        out.write(longest['header']+'\n')
        out.write('\n'.join([longest['sequence'][i:i+60] for i in range(0, longest['length'], 60)]))
        out.write('\n')

    return {
        'count': has.count(),
        'time': time.time() - since,
        'outfile': clade_file,
        'outfile_longest': clade_longest_file,
        'longest_length': longest['length']
        }

def run_mafft(input_file='', repr_file=''):
    clade_basedir = settings.CLADE_SEQUENCE_BASE_DIR
    clade_dir = os.path.join(clade_basedir, 'ha')
    outfile = os.path.join(clade_dir, os.path.basename(input_file).replace('.fasta','.aln'))
    
    cmd = "mafft --anysymbol --auto --thread -1 --keeplength --addfragments {input_file} {repr_file} > {outfile}"
    since = time.time()
    os.system(cmd.format(
        input_file=input_file, repr_file=repr_file, outfile=outfile))
    return {
        'time': time.time()-since,
        'outfile': outfile,
    }


def run():
    has = models.Hemagglutinin.objects.all()
    clade_names = has.order_by().values_list('isolate__clade__full_name',flat=True).distinct()
    for clade in clade_names:
        if not clade:
            continue
        if 'unassign' in clade.lower():
            continue
        print("Working on clade {}...".format(clade))
        print("  Writing HA sequences")
        r = write_clade_ha_sequences(clade_name=clade)
        print("  Complete. {} sequences written to {}. Longest sequence length {}; {:.2f} minutes elapsed.".format(
            r['count'], r['outfile'], r['longest_length'], r['time']/60.0
        ))
        print("  Running MSA for HA sequences")
        r2 = run_mafft(input_file=r['outfile'], repr_file=r['outfile_longest'])
        print(  "Complete. output written to {}. {:.2f} minutes elapsed.".format(r2['outfile'], r2['time']/60.0))