"""
A prototype script to update database from sequence upload.
The processes in this script will be automated.

Assumptions:
1. Amino acid sequences are uploaded in
    - /app/limh25/databases/gisaid/epiflu/aa
    - sequence files ends with .fasta
    - sequence headers formatted in >EPI_ISL_15579592|A/Catalonia/NSVH198257512/2022|A_/_H3N2|Original||2022-10-20|EPI2197882|NP
2. Metadata uploaded in
    - /app/limh25/databases/gisaid/epiflu/metadata
    - combined metadata in metadata_2022-12-22.json format
    - new metadata files ends with .xls


Processes:
1. Collect new isolates and HA/NA sequences
2. Update Isolate table with (clade = null) and passage=standardized_passage
3. Clade assignment performed using nextclade command-line interface
    - separated by subtype (h1n1, h3n2, vic, yam), collect HA nucleotide sequences for isolates (clade=null)
    - perform nextclade assignment
    - update isolate table with clade information
4. For each new HA sequence, perform alignment against each ReferenceHemagglutinin and update PairwiseAlignedHemagglutinin table
5. Record update history

"""

import os
import sys
import re
import csv
import time
import numpy as np
import pandas as pd
from contextlib import closing
from io import StringIO
import json
import tqdm
import multiprocessing as mp
from itertools import product, islice
from datetime import datetime, timedelta
from django.conf import settings
from django.db import connection
from django.core.management.color import no_style
from django.utils import timezone
from proteins import utils
from proteins import models
from Bio import SeqIO, Seq
from proteins import sequence_alignment as sa
from proteins import structure_info as si
from proteins import protein_structure as ps
from nucleotides import models as nucl_models
from nucleotides import translate as nucl_translate
from annotations import models as annot_models
from annotations import glycosylation as glyco
from proteins import vaccine
from proteins import epitopes as ep
from biotite.structure.io import pdb
from biotite import structure as bts


caches = {
        'host-Unknown'        : models.Host.objects.get_or_create(name='Unknown')[0],
        'gender-Unknown'      : models.Gender.objects.get_or_create(name='Unknown')[0],
        'passage-Unknown'     : models.Passage.objects.get_or_create(name='Unknown')[0],
        'lineage-Unknown'     : models.Lineage.objects.get_or_create(name='Unknown')[0],

        'continent-Unknown'   : models.Continent.objects.get_or_create(name='Unknown')[0],
        'country-Unknown'     : models.Country.objects.get_or_create(name='Unknown')[0],
        'region-Unknown'      : models.Region.objects.get_or_create(name='Unknown')[0],
        'lab-Unknown'         : models.Laboratory.objects.get_or_create(name='Unknown')[0],
        'isolate-subtype-Unknown'     : models.IsolateSubtype.objects.get_or_create(name='Unknown')[0],

    }  # for faster database query
batch_size = 10000  # for bulk_create operations
ncpus = 12  # for multiprocessing fasta parsing
protein_segment_models = models.SEGMENT_MODELS

nucleotide_segment_models = nucl_models.SEGMENT_MODELS

def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise ValueError('Boolean value expected.')

class NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return json.JSONEncoder.default(self, obj)

def load_json(filename):
    with open(filename, 'r') as fp:
        data = json.load(fp)
    return data

def save_json(data,filename):
    with open(filename, 'w') as fp:
        json.dump(data, fp, sort_keys=True, indent=4, cls=NumpyEncoder)


def sync_files(gisaid_dir):
    if not gisaid_dir.endswith('/'):
        gisaid_dir += '/'
    cmd = "scp -r limh25@amraelp00010519:/app/WL/GISAID_Flu/* {}".format(gisaid_dir)
    os.system(cmd)
    return gisaid_dir


def find_glyco_sites(x):
    prot_seq = x['protein_sequence']
    nucl_seq = x['nucleotide_sequence']
    aa_site = glyco.find_glycosylation_sites(prot_seq)
    if nucl_seq:
        nt_site = glyco.find_glycosylation_sites_from_nucleotide(nucl_seq)
    else:
        nt_site = {}
    x['aa_site'] = aa_site
    x['nt_site'] = nt_site
    return x


def update_glycosylation_sites(prot_obj, nucl_obj=None, annot_model=None):
    if not annot_model:
        raise ValueError("Annotation model (glycosylation site) must be defined.")
    
    aa_sites = glyco.find_glycosylation_sites(prot_obj.sequence)
    if nucl_obj and ('nt_sequence' in nucl_obj.longest_orf):
        nt_sites = glyco.find_glycosylation_sites_from_nucleotide(nucl_obj.longest_orf['nt_sequence'])
    else:
        nt_sites = {}
    
    obj, created = annot_model.objects.get_or_create(
        protein=prot_obj, nucleotide=nucl_obj,
        protein_sites=aa_sites,
        nucleotide_sites=nt_sites,
    )
    return obj, created
    

def update_ha_glycosylation_sites(reset=False):
    ha_accessions = models.Hemagglutinin.objects.all().values_list('accession', flat=True)
    prot_has = models.Hemagglutinin.objects.in_bulk(ha_accessions, field_name='accession')
    nucl_has = nucl_models.Hemagglutinin.objects.in_bulk(ha_accessions, field_name='accession')
    annot_model = annot_models.HemagglutininGlycosylationSite
    counts = {
        'total': 0,
        'created' : 0,
    }
    if reset:
        annot_models.HemagglutininGlycosylationSite.objects.all().delete()
        reset_sql = connection.ops.sequence_reset_sql(no_style(), [annot_models.HemagglutininGlycosylationSite])
        with connection.cursor() as cursor:
            for sql in reset_sql:
                cursor.execute(sql)

        inputs = []
        for ha_accession in prot_has:
            prot_ha = prot_has[ha_accession]
            nucl_ha = nucl_has.get(ha_accession, None)
            if nucl_ha and ('nt_sequence' in nucl_ha.longest_orf):
                nucl_sequence = nucl_ha.longest_orf['nt_sequence']
            else:
                nucl_sequence = None
            inputs.append({'ha_accession':ha_accession, 'protein_sequence': prot_ha.sequence, 'nucleotide_sequence': nucl_sequence})
        
        annot_objects = []
        print("  Collecting glycosylation site annotations...")
        with mp.Pool(ncpus) as pool:
            for res in tqdm.tqdm(pool.imap_unordered(find_glyco_sites, inputs), total=len(inputs)):
                prot_obj = prot_has[res['ha_accession']]
                nucl_obj = nucl_has.get(res['ha_accession'], None)
                aa_sites = res['aa_site']
                nt_sites = res['nt_site']

                annot_objects.append(annot_model(
                    protein=prot_obj, nucleotide=nucl_obj,
                    protein_sites=aa_sites,
                    nucleotide_sites=nt_sites,
                ))

        print("   Bulk-creating {} glycosylation site annotation instances...".format(len(annot_objects)))
        with tqdm.tqdm(total=len(annot_objects)) as pbar:
            for start in range(0, len(annot_objects), batch_size):
                batch = annot_objects[start:start+batch_size]
                annot_model.objects.bulk_create(
                    batch, batch_size=batch_size, ignore_conflicts=True)
                pbar.update(len(batch))
    else:
        # non-reset mode
    
        for ha_accession in tqdm.tqdm(prot_has, total=len(prot_has)):
            prot_ha = prot_has[ha_accession]
            
            existing_glycs = annot_models.HemagglutininGlycosylationSite.objects.filter(protein=prot_ha)
            if (existing_glycs.count() > 0) and (not reset):
                # already annotated and no reset
                continue
            nucl_ha = nucl_has.get(ha_accession, None)
            # nucl_ha may be None
            annot_obj, created = update_glycosylation_sites(prot_ha, nucl_obj=nucl_ha, annot_model=annot_model)
            if created:
                counts['created'] += 1
            counts['total'] += 1
    return counts

def parse_excel_file(excel_file):
    meta = pd.read_excel(excel_file)
    data = {}
    for idx,row in meta.iterrows():
        isolate_id = row['Isolate_Id']
        if type(isolate_id) == float: # cannot parse isolate id; skip
            continue
        segment_ids = {
            'PB2': row['PB2 Segment_Id'],
            'PB1': row['PB1 Segment_Id'],
            'PA': row['PA Segment_Id'],
            'HA': row['HA Segment_Id'],
            'NP': row['NP Segment_Id'],
            'NA': row['NA Segment_Id'],
            'MP': row['MP Segment_Id'],
            'NS': row['NS Segment_Id'],
            'HE': row['HE Segment_Id'],
            'P3': row['P3 Segment_Id'],
        }
        for segment in segment_ids:
            if type(segment_ids[segment]) == float:
                segment_ids[segment] = None
            else:
                segment_id_list = segment_ids[segment].strip().split(',')
                segment_ids[segment] = ','.join([sid.strip().split('|')[0] for sid in segment_id_list])
        lineage = row['Lineage']  # pdm09; Victoria; etc
        subtype = row['Subtype']  # A / H5N1; B;
        passage = row['Passage_History']
        location = row['Location'] 
        collection_date = row['Collection_Date'] 
        submission_date = row['Submission_Date']

        submit_sample_id = row['Submitting_Sample_Id']
        origin_sample_id = row['Originating_Sample_Id']

        isolate_name = row['Isolate_Name'] 
        submit_lab = row['Submitting_Lab'] 
        origin_lab = row['Originating_Lab'] 


        host = row['Host'] 
        host_age = row['Host_Age'] 
        host_age_unit = row['Host_Age_Unit'] 
        host_gender = row['Host_Gender'] 
        d = {
            'isolate_id'     : isolate_id,
            'isolate_name'   : isolate_name,
            'subtype'        : subtype,
            'lineage'        : lineage,
            'passage'        : passage,
            'location'       : location,
            'collection_date': collection_date,
            'submission_date': submission_date,
            'segment_ids'    : segment_ids,
            'submit_lab'     : submit_lab,
            'submit_sample_id': submit_sample_id,
            'origin_lab'     : origin_lab,
            'origin_sample_id': origin_sample_id,
            'host'           : host,
            'host_age'       : host_age,
            'host_age_unit'  : host_age_unit,
            'host_gender'    : host_gender,
        }
        data[isolate_id] = d
    return {'data':data, 'file':excel_file}

def collect_files(gisaid_dir, collect_old=True):
    metadata_files = []
    aa_files = []
    nt_files = []
    subdirs = os.listdir(gisaid_dir)
    old_dirs = {
        'metadata_dir': "/app/limh25/databases/gisaid_old/epiflu_old/metadata",
        'aa_dir'      : "/app/limh25/databases/gisaid_old/epiflu_old/aa",
        'nt_dir'      : "/app/limh25/databases/gisaid_old/epiflu_old/nt",
    }
    if collect_old:
        # collect metadata xls files from old directory
        # other files, such as aa.fasta and nt.fasta may have different headers
        files = os.listdir(old_dirs['metadata_dir'])
        for f in files:
            if f.endswith('xls'):
                metadata_files.append(os.path.join(old_dirs['metadata_dir'], f))
        files = os.listdir(old_dirs['aa_dir'])
        for f in files:
            if f.endswith('fasta'):
                aa_files.append(os.path.join(old_dirs['aa_dir'], f))
        files = os.listdir(old_dirs['nt_dir'])
        for f in files:
            if f.endswith('fasta'):
                nt_files.append(os.path.join(old_dirs['nt_dir'], f))
    for sd in subdirs:
        subdir = os.path.join(gisaid_dir, sd)
        if os.path.isdir(subdir):
            files = os.listdir(subdir)
            for f in files:
                if f.endswith('xls'):
                    metadata_files.append(os.path.join(subdir, f))
                elif f.endswith('fasta'):
                    if 'aa' in f.lower():
                        aa_files.append(os.path.join(subdir, f))
                    elif 'nt' in f.lower():
                        nt_files.append(os.path.join(subdir, f))
                    else:
                        continue
                else:
                    continue
    return {'aa_files': aa_files,
            'nt_files': nt_files,
            'metadata_files': metadata_files}


def update_metadata(latest_metadata, metadata_files):
    datasets = []
    with mp.Pool(ncpus) as pool:
        for d in tqdm.tqdm(pool.imap_unordered(parse_excel_file, metadata_files), total=len(metadata_files)):
            datasets.append(d['data'])

    for ds in datasets:
        latest_metadata.update(ds)
        print("  Metadata loaded. Current isolate count {}".format(len(latest_metadata)))
    return latest_metadata

def save_metadata(metadata, metadata_dir):
    today = datetime.now()
    metadata_output_file = os.path.join(metadata_dir, "metadata_{y}-{m}-{d}.json".format(
        y=today.year, m=today.month, d=today.day
    ))
    metadata_output_file_copy = os.path.join(metadata_dir, "metadata_latest.json")
    save_json(metadata, metadata_output_file)
    os.system("cp {} {}".format(metadata, metadata_output_file_copy))
    print("  Metadata written to {}. (also copied to {})".format(metadata_output_file, metadata_output_file_copy))
    return metadata_output_file_copy

def identify_molecule_subtype(isolate, segment_name):
    isolate_subtype = isolate.subtype.name if isolate.subtype else ''
    lineage = isolate.lineage.name if isolate.lineage else ''
    segment_patterns = {
        'HA': r'H(\d+)',
        'NA': r'N(\d+)'
    }
    if segment_name in segment_patterns:  # HA or NA only
        if isolate_subtype.lower().strip() == 'b':
            if lineage.lower().strip() in ['victoria', 'yamagata']:
                molecule_subtype = 'B-'+lineage
            else:
                molecule_subtype = 'B-Unknown'
        elif isolate_subtype.lower().strip().startswith('a'):
            sub = re.search(segment_patterns[segment_name], isolate_subtype)
            if sub is None:
                molecule_subtype = None
            else:
                molecule_subtype = sub[0]
        else:
            molecule_subtype = None
    else:
        molecule_subtype = None
    return molecule_subtype


def sort_isolate_ids(isolate_ids):
    id_dict = {i: int(i.strip().split('_')[-1]) for i in isolate_ids}
    return {k: v for k, v in sorted(id_dict.items(), key=lambda item: item[1])}

def check_nan(entry):
    # return None if NaN
    if type(entry) == float:
        if np.isnan(entry):
            return None
    return entry

def standardize_date(date_string):
    date_string = check_nan(date_string)
    if not date_string:
        return None

    full_pattern = r'([\d]{4})-([\d]{1,2})-([\d]{1,2})'
    month_pattern = r'([\d]{4})-([\d]{1,2})'
    year_pattern = r'([\d]{4})'

    m = re.search(full_pattern, date_string)
    if m:
        date = datetime.strptime(date_string, "%Y-%m-%d")
    else:
        m = re.search(month_pattern, date_string)
        if m:
            date = datetime.strptime(date_string, "%Y-%m")
        else:
            m = re.search(year_pattern, date_string)
            if m:
                date = datetime.strptime(date_string, "%Y")
            else:
                date = None
    return date

def parse_location(location):
    locs = location.strip().split('/')
    if len(locs) >= 3:
        continent = locs[0].lstrip().strip()
        country   = locs[1].lstrip().strip()
        region    = locs[2].lstrip().strip()
    elif len(locs) >= 2:
        continent = locs[0].lstrip().strip()
        country   = locs[1].lstrip().strip()
        region    = 'Unknown'
    elif len(locs) >= 1:
        continent = locs[0].lstrip().strip()
        country   = 'Unknown'
        region    = 'Unknown'
    else:
        continent = 'Unknown'
        country   = 'Unknown'
        region    = 'Unknown'
    return {
        'continent': continent,
        'country'  : country,
        'region'   : region,
    }

def populate_isolates(metadata, reset=False):
    if reset:
        models.Isolate.objects.all().delete()
        reset_sql = connection.ops.sequence_reset_sql(no_style(), [models.Isolate])
        with connection.cursor() as cursor:
            for sql in reset_sql:
                cursor.execute(sql)
        print("Removed all Isolate instances. Collecting metadata to bulk-create...")
    else:
        print("Parsing metadata to create isolate objects... (no reset)")

    since = time.time()
    segmentId2isolatePk = {}
    instances = []  # for bulk-create

    multi_segment_isolate_ids = {}  # isolate_ids with multiple HA / multiple NA / etc.
    
    for isolate_id in tqdm.tqdm(metadata, total=len(metadata)):
        data = metadata.get(isolate_id, None)
        if not data:
            continue
        segment_ids = data.get('segment_ids', {})

        for segment in segment_ids:
            segment_id_list = segment_ids.get(segment, '')
            if not segment_id_list:
                continue
            segment_id_list = segment_id_list.strip().split(',')
            # mostly 1 segment - 1 isolate, but sometimes multi-segment-1-isolate
            if len(segment_id_list) > 1:
                multi_segment_isolate_ids[isolate_id] = 1
            for sid in segment_id_list:
                segmentId2isolatePk[sid] = isolate_id
        collection_date = standardize_date(data['collection_date'])
        submission_date = standardize_date(data['submission_date'])
        host_txt = check_nan(data['host'])
        if host_txt:
            host = caches.get('host-{}'.format(host_txt), None)
            if not host:
                host, _ = models.Host.objects.get_or_create(name=host_txt)
                caches['host-{}'.format(host_txt)] = host
        
        host_age_unit_txt = check_nan(data['host_age_unit'])
        if host_age_unit_txt:
            host_age_unit = caches.get('host-age-unit-{}'.format(host_age_unit_txt), None)
            if not host_age_unit:
                host_age_unit, _ = models.AgeUnit.objects.get_or_create(name=host_age_unit_txt)
                caches['host-age-unit-{}'.format(host_age_unit_txt)] = host_age_unit

        host_age = check_nan(data['host_age'])
        host_gender_txt = check_nan(data['host_gender'])
        if host_gender_txt:
            host_gender = caches.get('gender-{}'.format(host_gender_txt), None)
            if not host_gender:
                host_gender, _ = models.Gender.objects.get_or_create(name=host_gender_txt)
                caches['gender-{}'.format(host_gender_txt)] = host_gender
        else:
            host_gender = caches['gender-Unknown']
        name = check_nan(data['isolate_name'])
        passage_txt = check_nan(data['passage'])
        if passage_txt:
            passage = caches.get('passage-{}'.format(passage_txt.strip().lstrip()), None)
            if not passage:
                passage = models.Passage.objects.filter(name__iexact=passage_txt.strip().lstrip()).first()
                caches['passage-{}'.format(passage_txt.strip().lstrip())] = passage
        else:
            passage = caches['passage-Unknown']
        
        lineage_txt = check_nan(data['lineage'])
        if lineage_txt:
            lineage = caches.get('lineage-{}'.format(lineage_txt), None)
            if not lineage:
                lineage, _ = models.Lineage.objects.get_or_create(name=lineage_txt)
                caches['lineage-{}'.format(lineage_txt)] = lineage
        else:
            lineage = caches['lineage-Unknown']
        
        location = check_nan(data['location'])
        if location:
            location = parse_location(location)
            continent = caches.get('continent-{}'.format(location['continent']), None)
            if not continent:
                continent, _ = models.Continent.objects.get_or_create(name=location['continent'])
                caches['continent-{}'.format(location['continent'])] = continent
            country = caches.get('country-{}'.format(location['country']), None)
            if not country:
                country, _   = models.Country.objects.get_or_create(name=location['country'])
                caches['country-{}'.format(location['country'])] = country
            region = caches.get('region-{}'.format(location['region']), None)
            if not region:
                region, _    = models.Region.objects.get_or_create(name=location['region'])
                caches['region-{}'.format(location['region'])] = region
        else:
            continent = caches['continent-Unknown']
            country   = caches['country-Unknown']
            region    = caches['region-Unknown']

        submit_sample_id = check_nan(data['submit_sample_id'])
        origin_sample_id = check_nan(data['origin_sample_id'])
        submit_lab_txt = check_nan(data['submit_lab'])
        origin_lab_txt = check_nan(data['origin_lab'])
        if submit_lab_txt:
            submit_lab = caches.get('lab-{}'.format(submit_lab_txt), None)
            if not submit_lab:
                submit_lab, _ = models.Laboratory.objects.get_or_create(name=submit_lab_txt)
                caches['lab-{}'.format(submit_lab_txt)] = submit_lab
        else:
            submit_lab = caches['lab-Unknown']
        if origin_lab_txt:
            origin_lab = caches.get('lab-{}'.format(origin_lab_txt), None)
            if not origin_lab:
                origin_lab, _ = models.Laboratory.objects.get_or_create(name=origin_lab_txt)
                caches['lab-{}'.format(origin_lab_txt)] = origin_lab
        else:
            origin_lab = caches['lab-Unknown']

        subtype_txt = check_nan(data['subtype'])
        if subtype_txt:
            subtype = caches.get('isolate-subtype-{}'.format(subtype_txt), None)
            if not subtype:
                subtype, _ = models.IsolateSubtype.objects.get_or_create(name=subtype_txt)
                caches['isolate-subtype-{}'.format(subtype_txt)] = subtype
        else:
            subtype = caches['isolate-subtype-Unknown']
        
        isolate = models.Isolate(
            accession=isolate_id, name=name,
            segment_ids=segment_ids,
            submit_sample_id=submit_sample_id,
            origin_sample_id=origin_sample_id,
            collection_date=collection_date,
            submission_date=submission_date,
            passage=passage, host=host, host_age=host_age, host_age_unit=host_age_unit,
            host_gender=host_gender, lineage=lineage, continent=continent,
            country=country, region=region,
            subtype=subtype,
            submit_lab=submit_lab, origin_lab=origin_lab
        )
        instances.append(isolate)

    print("   Bulk-creating (updating) Isolate instances...")
    with tqdm.tqdm(total=len(instances)) as pbar:
        for start in range(0, len(instances), batch_size):
            batch = instances[start:start+batch_size]
            models.Isolate.objects.bulk_create(
                batch, batch_size=batch_size, ignore_conflicts=True)

            pbar.update(len(batch))

    elapsed = (time.time() - since)/60.0
    print("Complete! Created {} isolate objects. {:.2f} mintes elapsed.".format(
        len(instances), elapsed
    ))

    with open('/app/limh25/databases/gisaid_processed/multi_segment_isolates.txt', 'w') as out:
        for isolate_id in multi_segment_isolate_ids:
            out.write(isolate_id+'\n')
    return segmentId2isolatePk


def collect_proteins(fasta_file):
    seqs = SeqIO.parse(fasta_file, "fasta")
    instances = []  # dict of (segment_name, segment_id) => {'isolate_id': isolate_id, 'segment_id': segment_id, 'segment_name': segment_name, 'sequence': seq.seq}
    for seq in seqs:
        header = seq.id.strip().split('|')
        # >EPI_ISL_1280|A/Turkey/California/189/66|A_/_H9N2|||1966-01-01|EPI5963|NP  -- old format
        # >A/Bari/42/2022|EPI_ISL_17063065|A_/_H3N2|||2022-11-14|PB2 -- new format
        if len(header) < 2:
            continue
        if header[0].lower().startswith('epi_isl'):
            isolate_id = header[0].strip()
        elif header[1].lower().startswith('epi_isl'):
            isolate_id = header[1].strip()
        else:
            # cannot parse fasta header
            continue
        segment_name = header[-1]
        segment_model = protein_segment_models.get(segment_name, None)
        if not segment_model:
            continue
        if header[2].lower().startswith('epi'):
            # fasta with explicit molecule id; take precedence
            segment_id = header[2].strip()
        else:
            segment_id = None

        instances.append({'isolate_id': isolate_id, 'segment_id': segment_id, 'segment_name': segment_name, 'sequence': seq.seq})

    return instances

def populate_proteins(fasta_files, reset=False):
    
    segment_instances = {s:{} for s in protein_segment_models}
    if reset:
        for segment in protein_segment_models:
            protein_segment_models[segment].objects.all().delete()
        reset_sql = connection.ops.sequence_reset_sql(no_style(), [protein_segment_models[segment] for segment in protein_segment_models])
        with connection.cursor() as cursor:
            for sql in reset_sql:
                cursor.execute(sql)

    since = time.time()
    print("Populating protein objects from fasta files...")
    instance_lists = []  # list of lists
    with mp.Pool(ncpus) as pool:
        for instances in tqdm.tqdm(pool.imap_unordered(collect_proteins, fasta_files), total=len(fasta_files)):
            instance_lists.append(instances)

    instance_list = [instance for sublist in instance_lists for instance in sublist]
    isolate_ids = list(set([ins['isolate_id'] for ins in instance_list]))
    isolates = models.Isolate.objects.order_by().in_bulk(isolate_ids, field_name='accession')
    for instance in tqdm.tqdm(instance_list, total=len(instance_list)):
        isolate = isolates.get(instance['isolate_id'], None)
        if not isolate:
            continue
        segment_model = protein_segment_models[instance['segment_name']]
        segment_id = instance['segment_id']  # molecule accession
        if not segment_id:
            segment_id_list = isolate.segment_ids.get(instance['segment_name'], None)
            if segment_id_list:
                segment_id = segment_id_list.strip().split(',')[0]
            else:
                segment_id = ''
            if not segment_id.lower().startswith('epi'):
                # no segment id or incorrect format
                continue
        if instance['segment_name'] in ['HA', 'NA']:
            mol_subtype_txt = identify_molecule_subtype(isolate, instance['segment_name']) or 'Unknown'
            mol_subtype = caches.get('molecule-subtype-{}'.format(mol_subtype_txt), None)
            if not mol_subtype:
                mol_subtype, _ = models.MoleculeSubtype.objects.get_or_create(name=mol_subtype_txt)
                caches['molecule-subtype-{}'.format(mol_subtype_txt)] = mol_subtype
            segment_instances[instance['segment_name']][segment_id] = segment_model(accession=segment_id, isolate=isolate, sequence=instance['sequence'], subtype=mol_subtype)
        else:
            segment_instances[instance['segment_name']][segment_id] = segment_model(accession=segment_id, isolate=isolate, sequence=instance['sequence'])

    for segment_name in segment_instances:
        sis = [segment_instances[segment_name][segment_id] for segment_id in segment_instances[segment_name]]
        sm = protein_segment_models[segment_name]
        print("   Bulk-creating {} protein instances...".format(segment_name))
        with tqdm.tqdm(total=len(sis)) as pbar:
            for start in range(0, len(sis), batch_size):
                batch = sis[start:start+batch_size]

                sm.objects.bulk_create(
                    batch, batch_size=batch_size, ignore_conflicts=True)
                pbar.update(len(batch))

    elapsed = (time.time() - since)/60.0
    print("Creating protein objects complete. {:.2f} minutes elapsed.".format(elapsed))
    return elapsed


def run_pairwise_ha_alignment(x):
    refseq = x['ref_ha_seq']
    qseq   = x['query_ha_seq']
    clean  = x['clean']
    aln = sa.pairwise_align(ref_seq=refseq, query_seq=qseq, clean=clean)
    x['ref_align'] = aln['reference_aligned']
    x['query_align'] = aln['query_aligned']
    x['score'] = aln['score']
    return x


def align_ha(max_previous_days=365, reset=False):
    if reset:
        models.PairwiseAlignedHemagglutinin.objects.all().delete()
        reset_sql = connection.ops.sequence_reset_sql(no_style(), [models.PairwiseAlignedHemagglutinin])
        with connection.cursor() as cursor:
            for sql in reset_sql:
                cursor.execute(sql)
    refs = models.ReferenceHemagglutinin.objects.in_bulk(models.ReferenceHemagglutinin.objects.all().order_by().values_list('pk', flat=True))
    ha_objects = models.Hemagglutinin.objects.in_bulk(
        models.Hemagglutinin.objects.filter(isolate__collection_date__gte=datetime.now() - timedelta(days=max_previous_days)).filter(isolate__host__name__iexact='human').order_by().values_list('pk', flat=True))

    pairs = list(product(list(refs.keys()), list(ha_objects.keys())))
    inputs = []
    outputs = []
    objects = []

    print("   Collecting sequence information for PairwiseAlignedHemagglutinin instances.")
    print("   Past {} days of hemagglutinin sequences will be aligned against reference HA.".format(max_previous_days))

    for pair in pairs:
        ref_pk = pair[0]
        ha_pk = pair[1]
        if (not ref_pk) or (not ha_pk):
            continue
        ref_obj = refs[ref_pk]
        ha_obj = ha_objects[ha_pk]

        if not reset:
            # if not resetting, check already existing alignments and skip
            aln_obj_count = models.PairwiseAlignedHemagglutinin.objects.filter(query=ha_obj).filter(reference=ref_obj).count()
            if aln_obj_count > 0:
                # pair previously aligned; skip
                continue
        d = {
            'ref_pk': ref_pk,
            'query_pk': ha_pk,
            'ref_ha_seq': ref_obj.ha.sequence,
            'query_ha_seq': ha_obj.sequence,
            'clean': True
        }
        inputs.append(d)

    print("   Running alignment for PairwiseAlignedHemagglutinin instances...")

    with mp.Pool(ncpus) as pool:
        for aln in tqdm.tqdm(pool.imap_unordered(run_pairwise_ha_alignment, inputs), total=len(inputs)):
            query = ha_objects.get(aln['query_pk'], None)
            ref = refs.get(aln['ref_pk'], None)
            score = aln['score']
            if (not query) or (not ref) or (not score):
                continue
            outputs.append(aln)

    for aln in tqdm.tqdm(outputs, total=len(outputs)):
        query = ha_objects.get(aln['query_pk'], None)
        ref = refs.get(aln['ref_pk'], None)
        score = aln['score']
        if (not query) or (not ref) or (not score):
            continue
        objects.append(models.PairwiseAlignedHemagglutinin(
            query=query, reference=ref,
            score=score, query_aligned=aln['query_align'],
            reference_aligned=aln['ref_align'],
        ))
    print("   Bulk-creating PairwiseAlignedHemagglutinin instances...")
    with tqdm.tqdm(total=len(objects)) as pbar:
        for start in range(0, len(objects), batch_size):
            batch = objects[start:start+batch_size]
            models.PairwiseAlignedHemagglutinin.objects.bulk_create(
                batch, batch_size=batch_size, ignore_conflicts=True)
            pbar.update(len(batch))

    return len(objects)


def write_ha_nt_sequences(isolate_ids, temp_dir):
    today = datetime.now()
    output_files = {l: os.path.join(temp_dir, "{l}_ha_nt_{y}-{m}-{d}.fasta".format(l=l,y=today.year,m=today.month,d=today.day))
        for l in isolate_ids
    }
    out_fhs = {l: open(output_files[l], 'w') for l in output_files}
    for l in out_fhs:
        out = out_fhs[l]
        ha_nucls = nucl_models.Hemagglutinin.objects.filter(isolate__pk__in=isolate_ids[l]).order_by()
        print("  Writing {} nt sequences to {}...".format(l, output_files[l]))
        for ha in tqdm.tqdm(ha_nucls, total=ha_nucls.count()):
            isolate = ha.isolate
            header = '>{}|{}|{}\n'.format(isolate.accession, isolate.name, ha.accession)
            seq = '\n'.join([ha.sequence[i:i+60] for i in range(0, len(ha.sequence), 60)])
            out.write(header)
            out.write(seq+'\n')
        out.close()
    return output_files

def run_nextclade(ha_nt_fasta_files, temp_dir, nextclade_datasets, clean=False):
    today = datetime.now()
    cmd = "nextclade run --dataset-name {dataset} --output-csv {output_file} {fasta_file}"
    output_files = {
        lin:os.path.join(temp_dir, "{l}_nextclade_{y}-{m}-{d}.csv".format(l=lin, y=today.year, m=today.month, d=today.day))
        for lin in ha_nt_fasta_files
    }
    for lin in ha_nt_fasta_files:
        fasta_file = ha_nt_fasta_files[lin]
        output_file = output_files[lin]
        os.system(cmd.format(
            dataset=nextclade_datasets[lin],
            output_file=output_file,
            fasta_file=fasta_file,
        ))
        if clean:
            os.system("rm {}".format(fasta_file))
    return output_files


def populate_clade_objects(clade_fullnames):
    # clade_fullnames: dict(fullname ->shortname)
    
    for clade in clade_fullnames:
        clade_obj = caches.get('clade-{}'.format(clade), None)
        if clade_obj:
            continue
        cs = clade.strip().split('.')
        clade_short = clade_fullnames[clade]
        clade_fullname_list = []
        for level, c in enumerate(cs):
            clade_fullname_list.append(c)
            clade_fullname = '.'.join(clade_fullname_list)
            if level == 0:
                clade_obj, _ = models.Clade.objects.get_or_create(
                    name=c, full_name=clade_fullname,
                    level=level,
                    # root clade; no parent clade
                    parent=None
                )
            else:
                clade_obj, clade_created = models.Clade.objects.get_or_create(
                    name=c, full_name=clade_fullname,
                    level=level, parent=clade_obj  # use the previous clade_obj as parent
                )

        if clade_obj.short_name != clade_short:
            # terminal clade newly created
            clade_obj.short_name = clade_short
            clade_obj.save()
        caches['clade-{}'.format(clade)] = clade_obj

def update_clade_assignment(nextclade_output_files, clean=True):
    isolate2clade = {}
    clade_shortnames = {}  # full-short
    for lin in nextclade_output_files:
        output_file = nextclade_output_files[lin]
        print("  Updating clades from {}...".format(output_file))
        with open(output_file, 'r') as csvfile:
            header = next(csvfile)
            # find index
            indices = {
                'isolate_id': None,
                'clade': None,
                'short_clade': None,
                'qc.overallscore': None,
            }
            for idx, h in enumerate(header.strip().split(';')):
                if h.lower() == 'seqname':
                    indices['isolate_id'] = idx
                elif h.lower() == 'clade':
                    indices['clade'] = idx
                elif h.lower() == 'short_clade':
                    indices['short_clade'] = idx
                elif h.lower() == 'qc.overallscore':
                    indices['qc.overallscore'] = idx
                else:
                    continue
            if not indices['isolate_id']:
                raise ValueError("isolate_id column could not be found in {}".format(output_file))
            if not indices['clade']:
                raise ValueError("clade column could not be found in {}".format(output_file))
            if not indices['qc.overallscore']:
                raise ValueError("qc.overallscore column could not be found in {}".format(output_file))
            if not indices['short_clade']:
                print("    short_clade column is not available in {}. Clade short names will be empty.".format(output_file))
            reader = csv.reader(csvfile, delimiter=';', quotechar='"')
            for line in reader:
                isolate_id = line[indices['isolate_id']].strip().split('|')[0]
                clade = line[indices['clade']].strip().lstrip()
                if indices['short_clade']:
                    clade_short = line[indices['short_clade']].strip().lstrip()
                else:
                    clade_short = ''
                qc_score = line[indices['qc.overallscore']].strip().lstrip()
                if clade.lower() == '':
                    continue
                if qc_score == '':
                    continue
                try:
                    qc_score = float(qc_score)
                except:
                    continue
                if qc_score > 29.0:
                    # low-quality; skip
                    continue

                clade_shortnames[clade] = clade_short
                isolate2clade[isolate_id] = clade

        if clean:
            os.system("rm {}".format(output_file))
    populate_clade_objects(clade_shortnames)
    isolates = models.Isolate.objects.in_bulk([i for i in isolate2clade], field_name='accession')
    isolates_to_update = []
    for isolate_id in isolate2clade:
        clade_name = isolate2clade[isolate_id]
        clade_obj = caches.get('clade-{}'.format(clade_name), None)
        obj = isolates[isolate_id]
        obj.clade = clade_obj
        isolates_to_update.append(obj)

    print("   Bulk-updating Isolate instances with clade information...")
    with tqdm.tqdm(total=len(isolates_to_update)) as pbar:
        for start in range(0, len(isolates_to_update), batch_size):
            batch = isolates_to_update[start:start+batch_size]
            models.Isolate.objects.bulk_update(
                batch, ['clade'], batch_size=batch_size)
            pbar.update(len(batch))

    return len(isolates_to_update)

def collect_nucleotides(fasta_file):
    seqs = SeqIO.parse(fasta_file, "fasta")
    instances = []  # dict of (segment_name, segment_id) => object
    for seq in seqs:
        header = seq.id.strip().split('|')
        # >EPI_ISL_17033246|A/Peregrine_falcon/Netherlands/5/2023|A_/_H5N1|2420053|2023-02-06|2023-02-27|Original|NP --old format
        # >A/Human/New_York/PV63150/2022|EPI_ISL_17064359|A_/_H3N2|Original||2022-06-17||NP|5 -- new format
        if len(header) < 2:
            continue
        if header[0].lower().startswith('epi_isl'):
            isolate_id = header[0]
            segment_name = header[-1]
            segment_id = None
        elif header[1].lower().startswith('epi_isl'):
            isolate_id = header[1]
            segment_name = header[-2]
            if header[2].strip().isdigit():
                segment_id = "EPI{}".format(header[2])
            else:
                segment_id = None
        else:
            # cannot parse fasta header
            continue
        segment_model = nucleotide_segment_models.get(segment_name, None)
        if not segment_model:
            continue

        try:
            longest_orf = nucl_translate.find_longest_orf(seq.seq)
        except:
            longest_orf = {
                        'aa_sequence': '',
                        'aa_sequence_length': 0,
                        'nt_sequence': '',
                        'nt_start': '',
                        'nt_end': '',
                        'frame': 0,
                        'strand': 0,
                    }

        instances.append({'isolate_id': isolate_id, 'segment_id': segment_id, 'segment_name': segment_name, 'sequence': seq.seq, 'longest_orf': longest_orf})
    return instances

def populate_nucleotides(fasta_files, reset=True):
    # it checks whether isolate object exists
    # thus, populating isolate must be done before this

    segment_instances = {s:{} for s in nucleotide_segment_models}
    if reset:
        for segment in nucleotide_segment_models:
            nucleotide_segment_models[segment].objects.all().delete()
        reset_sql = connection.ops.sequence_reset_sql(no_style(), [protein_segment_models[segment] for segment in protein_segment_models])
        with connection.cursor() as cursor:
            for sql in reset_sql:
                cursor.execute(sql)

    since = time.time()
    print("Populating nucleotide objects from fasta files...")
    instance_lists = []  # list of lists
    with mp.Pool(ncpus) as pool:  # reduced pool count due to memory shortage
        for instances in tqdm.tqdm(pool.imap_unordered(collect_nucleotides, fasta_files), total=len(fasta_files)):
            instance_lists.append(instances)

    instance_list = [instance for sublist in instance_lists for instance in sublist]
    isolate_ids = list(set([ins['isolate_id'] for ins in instance_list]))
    isolates = models.Isolate.objects.order_by().in_bulk(isolate_ids, field_name='accession')
    for instance in tqdm.tqdm(instance_list, total=len(instance_list)):
        isolate = isolates.get(instance['isolate_id'], None)
        if not isolate:
            continue
        segment_model = nucleotide_segment_models[instance['segment_name']]
        segment_id = instance['segment_id']  # molecule accession
        if not segment_id:
            segment_id_list = isolate.segment_ids.get(instance['segment_name'], None)
            if segment_id_list:
                segment_id = segment_id_list.strip().split(',')[0]
            else:
                segment_id = ''
            if not segment_id.lower().startswith('epi'):
                # no segment id or incorrect format
                continue
        if instance['segment_name'] in ['HA', 'NA']:
            mol_subtype_txt = identify_molecule_subtype(isolate, instance['segment_name']) or 'Unknown'
            mol_subtype = caches.get('molecule-subtype-{}'.format(mol_subtype_txt), None)
            if not mol_subtype:
                mol_subtype, _ = models.MoleculeSubtype.objects.get_or_create(name=mol_subtype_txt)
                caches['molecule-subtype-{}'.format(mol_subtype_txt)] = mol_subtype
            segment_instances[instance['segment_name']][segment_id] = segment_model(accession=segment_id, isolate=isolate, sequence=instance['sequence'], subtype=mol_subtype, longest_orf=instance['longest_orf'])
        else:
            segment_instances[instance['segment_name']][segment_id] = segment_model(accession=segment_id, isolate=isolate, sequence=instance['sequence'], longest_orf=instance['longest_orf'])


    for segment_name in segment_instances:
        sis = [segment_instances[segment_name][segment_id] for segment_id in segment_instances[segment_name]]
        sm = nucleotide_segment_models[segment_name]
        print("   Bulk-creating {} nucleotide instances...".format(segment_name))
        with tqdm.tqdm(total=len(sis)) as pbar:
            for start in range(0, len(sis), batch_size):
                batch = sis[start:start+batch_size]
                sm.objects.bulk_create(
                    batch, batch_size=batch_size, ignore_conflicts=True)
                pbar.update(len(batch))

    elapsed = (time.time() - since)/60.0
    print("Creating nucleotide objects complete. {:.2f} minutes elapsed.".format(elapsed))
    return elapsed


def update_history(latest_metadata_file, reassign_clades=True):
    # update updatehistory table

    count_dict = {
        'isolate': models.Isolate.objects.all().count(),
        'hemagglutinin': models.Hemagglutinin.objects.all().count(),
        'neuraminidase': models.Neuraminidase.objects.all().count(),
        'referencehemagglutinin': models.ReferenceHemagglutinin.objects.all().count(),
        'vaccinehemagglutinin': models.VaccineHemagglutinin.objects.all().count(),
        'pairwisealignedhemagglutinin': models.PairwiseAlignedHemagglutinin.objects.all().count(),
        'pdbstructure': models.PDBStructure.objects.all().count(),
        'referencehemagglutininstructurealigned': models.ReferenceHemagglutininStructureAligned.objects.all().count(),
    }
    if reassign_clades:

        h, _ = models.UpdateHistory.objects.get_or_create(
            metadata_file=latest_metadata_file,
            counts=count_dict,
            description="Clade assignment update."
        )
    else:
        h, _ = models.UpdateHistory.objects.get_or_create(
            metadata_file=latest_metadata_file,
            counts=count_dict,
            description="Update from new GISAID sequences."
        )
    print("Table row counts: {}".format(count_dict))


def populate_vaccine_ref_alignment(reset=False):
    if reset:
        models.VaccineToReferenceHemagglutinin.objects.all().delete()

    vaccines = models.VaccineHemagglutinin.objects.all().order_by()
    refs = models.ReferenceHemagglutinin.objects.all().order_by()

    count = 0
    for ref in refs:
        ref_seq = ref.full_sequence
        for vac in vaccines:
            vac_seq = vac.ha.sequence
            aln = sa.pairwise_align(ref_seq=ref_seq, query_seq=vac_seq)
            ref_aln = aln['reference_aligned']
            vac_aln = aln['query_aligned']
            score = aln['score']

            v2r, created = models.VaccineToReferenceHemagglutinin.objects.get_or_create(
                vaccine=vac, reference=ref,
                score=score, vaccine_aligned=vac_aln, reference_aligned=ref_aln,
                vaccine_start=aln['query_start'], reference_start=aln['reference_start'],
            )
            if created:
                count += 1
    print("Complete. Populated {} vaccine-reference HA alignments.".format(count))

def populate_vaccine_ha(reset=False):
    if reset:
        models.VaccineHemagglutinin.objects.all().delete()

    h3_vaccine_names = list(vaccine.H3N2_VACCINES.keys())
    h1_vaccine_names = list(vaccine.H1N1_VACCINES.keys())
    vic_vaccine_names = list(vaccine.VICTORIA_VACCINES.keys())
    yam_vaccine_names = list(vaccine.YAMAGATA_VACCINES.keys())
    pairs = [
        (h3_vaccine_names, "H3", vaccine.H3N2_VACCINES),
        (h1_vaccine_names, "H1", vaccine.H1N1_VACCINES),
        (vic_vaccine_names, "B", vaccine.VICTORIA_VACCINES),
        (yam_vaccine_names, "B", vaccine.YAMAGATA_VACCINES)
    ]
    count = 0
    for pair in pairs:
        names = pair[0]
        qs = models.Hemagglutinin.objects.filter(subtype__name__icontains=pair[1])
        for name in names:
            vaccine_info = pair[2][name]
            isolate_name = pair[2][name]['name']
            passage = vaccine_info['passage'].lower()  # cell or egg
            years = sorted(vaccine_info['years'])  # list of ascending integers e.g. [2020, 2021]
            latest_vaccine_year = years[-1]  # years is sorted ascending
            isolate_id = vaccine_info.get('isolate_id', '')
            qs_ = qs.filter(accession=isolate_id)
            if qs_.count() == 0:
                if passage == 'egg':
                    qs_ = qs.filter(isolate__name__iexact=isolate_name).filter(isolate__passage__is_known=True).filter(isolate__passage__is_egg_passaged=True)
                else:
                    qs_ = qs.filter(isolate__name__iexact=isolate_name).filter(isolate__passage__is_known=True).filter(isolate__passage__is_cell_passaged=True)
                if qs_.count() > 0:
                    print("  Passage-matching isolate found for {}-{}".format(pair[1], isolate_name))
                else:
                    # reduce filter level
                    qs_ = qs.filter(isolate__name__iexact=isolate_name).filter(isolate__passage__is_known=True)
                    if qs_.count() > 0:
                        print("  Isolate found for {}-{}".format(pair[1], isolate_name))
                    else:
                        qs_ = qs.filter(isolate__name__iexact=isolate_name)
                        if qs_.count() == 0:
                            print("    Vaccine-HA not found. {}: {}.".format(pair[1], isolate_name, qs_.count()))
                            continue
            vh, created = models.VaccineHemagglutinin.objects.get_or_create(
                ha=qs_.first(),
                vaccine_years=years,
                latest_vaccine_year=latest_vaccine_year
            )
            if created:
                count += 1
    print("Complete. {} vaccine hemagglutinin objects created.".format(count))


def populate_ref_ha(reset=False):
    if reset:
        models.ReferenceHemagglutinin.objects.all().delete()
    sequence_dir = settings.HA_REFERENCE_SEQUENCE_DIR
    sequence_files = [f for f in os.listdir(sequence_dir) if f.endswith('fasta')]
    count = 0
    for f in sequence_files:
        seqs = SeqIO.parse(os.path.join(sequence_dir, f), "fasta")
        ref_name = f.strip().split('.')[0]  # e.g. H1_1933 or H1N1pdm from filenames
        epitope_dict = ep.get_epitope_dict_for_reference(ref_name)
        parts = {'mature':'', 'full':'', 'signal':''}
        for seq in seqs:
            seq_info = seq.id.strip().split('|')
            if len(seq_info) < 8:
                raise ValueError(
                    "Sequence header contains insufficient information. e.g. >EPI_ISL_69816|A/United_Kingdom/1/1933|A_/_H1N1|egg_2|seasonal|1933-01-10|EPI242056|HA|mature, Given: {}".format(seq.id))

            molecule_id = seq_info[-3]
            part = seq_info[-1]  # mature | full | signal
            parts[part.lower()] = str(seq.seq)

        r, created = models.ReferenceHemagglutinin.objects.get_or_create(
            ha=models.Hemagglutinin.objects.filter(accession=molecule_id).first(),
            reference_name=ref_name,
            full_sequence=parts['full'],
            mature_sequence=parts['mature'],
            signal_peptide=parts['signal'],
            epitopes=epitope_dict
        )
        if created:
            count += 1
    print("{} reference HA populated.".format(count))



def populate_structures(reset=False):
    if reset:
        print("----populate_structures(reset=True). Will remove all existing PDBStructure objects and re-populate.")
        models.PDBStructure.objects.all().delete()

    print("  Start populating structures.")
    for pdb_id in si.STRUCTURE_INFO.keys():
        
        info = si.STRUCTURE_INFO[pdb_id]
        iso_subtype, _ = models.IsolateSubtype.objects.get_or_create(name=info['isolateSubtype'])
        mol_subtype, _ = models.MoleculeSubtype.objects.get_or_create(name=info['moleculeSubtype'])
        ref_ha_id = ep.get_epitope_reference_id(mol_subtype.name)
        if not ref_ha_id:
            continue
        ref_ha = models.Hemagglutinin.objects.filter(accession=ref_ha_id).first()
        if not ref_ha:
            continue
        epitope_dict = ep.get_epitope_dict_for_reference(mol_subtype.name)
        pdb_file = os.path.join(settings.PDB_STRUCTURE_DIR, "{}.pdb".format(pdb_id.lower()))


        chain_info = info['chain_info']
        segment_chains = [c for c in chain_info if chain_info[c]['segment']]
        pdb_obj = pdb.PDBFile.read(pdb_file)
        pdb_structure = pdb.get_structure(pdb_obj, model=1, altloc='occupancy')
        sasa_dicts = ps.compute_sasa(pdb_structure, probe_radius=1.4, point_number=1000, ignore_ions=True)
        alignments = {}
        all_residues = []  # {'chain_id':chain_id, 'res_id': res_id, 'res_name': res_name, 'com': center-of-mass}
        for chain in bts.chain_iter(pdb_structure):
            aa_filt = bts.filter_amino_acids(chain)
            chain = chain[aa_filt]
            if chain.shape[0] < 1:
                continue
            chain_id = chain[0].chain_id
            if chain_id not in segment_chains:
                # skip non-influenza chains, e.g. Fabs
                continue
            for r in bts.residue_iter(chain):
                all_residues.append(
                        {
                            'chain_id': r[0].chain_id,
                            'res_id':int(r[0].res_id), 
                            'res_name':r[0].res_name,
                            'com':ps.compute_center_of_mass_residue(r)
                        })
            res = bts.get_residues(chain)
            threes = res[1]
            res_num = res[0]
            chain_seq = ''.join([utils.three2one(three).upper() for three in threes])
            aln = sa.pairwise_align(ref_seq=ref_ha.sequence, query_seq=chain_seq, clean=True)
            d = {
                'chain_id'     : chain_id,
                'ref_aligned'  : aln['reference_aligned'],
                'ref_start'    : aln['reference_start'],
                'query_aligned': aln['query_aligned'],
                'query_start'  : aln['query_start'],
                'query_residue_numbers': res_num,
                'score'        : aln['score']
            }
            alignments[chain_id] = d

        epitope_map = sa.collect_epitope_map(alignments, epitope_dict)
        pair_pot_dict = ps.collect_residue_pair_potential(all_residues, com_dist_max=7.0, res_id_diff=4)
        # print(pair_pot_dict)

        structure_obj, created = models.PDBStructure.objects.get_or_create(
            pdb_id=pdb_id, isolate_subtype=iso_subtype, molecule_subtype=mol_subtype,
            description=info['description'],
            short_description=info['short_description'],
            chain_info=info['chain_info'],
            pdb_file=pdb_file,
            epitopes=epitope_map,
            sasa=sasa_dicts['sasa_dict'],
            pair_potential=pair_pot_dict,
            relative_sasa=sasa_dicts['rel_sasa_dict']
        )

        if created:
            print("    Created {}".format(structure_obj))

def popuate_structure_align_map():
    pdb_objects = models.PDBStructure.objects.all().order_by()
    count = 0
    for ref in models.ReferenceHemagglutinin.objects.all().order_by():
        ref_id = ref.ha.accession
        ref_seq = ref.full_sequence
        ref_name = ref.reference_name
        pdb_ids = si.REFERENCE_MATCH[ref_name]
        for pdb_id in pdb_ids:
            pdb_object = pdb_objects.filter(pdb_id=pdb_id).first()
            chain_info = pdb_object.chain_info
            segment_chains = [c for c in chain_info if chain_info[c]['segment']]
            pdb_obj = pdb.PDBFile.read(pdb_object.pdb_file)
            pdb_structure = pdb.get_structure(pdb_obj, model=1, altloc='occupancy')
            alignments = {}
            for chain in bts.chain_iter(pdb_structure):
                aa_filt = bts.filter_amino_acids(chain)
                chain = chain[aa_filt]
                if chain.shape[0] < 1:
                    continue
                num_res = bts.get_residue_count(chain)
                chain_id = chain[0].chain_id
                if chain_id not in segment_chains:
                    # skip non-influenza chains, e.g. Fabs
                    continue
                res = bts.get_residues(chain)
                threes = res[1]
                res_num = res[0]
                chain_seq = ''.join([utils.three2one(three).upper() for three in threes])
                aln = sa.pairwise_align(ref_seq=ref_seq, query_seq=chain_seq, clean=True)
                ref_aln = aln['reference_aligned']
                chain_aln = aln['query_aligned']
                score = aln['score']  # bitscore
                d = {
                    'ref_id': ref_id,
                    'query_pdb_id': pdb_id,
                    'chain_id': chain_id,
                    'ref_aligned': ref_aln,
                    'ref_start': aln['reference_start'],
                    'query_aligned': chain_aln,
                    'query_start': aln['query_start'],
                    'query_residue_numbers': res_num,  # 1-based residue indices in pdb file
                    'score': score,
                }
                alignments[chain_id] = d

            position_map = sa.collect_position_map(alignments)

            ref_str, created = models.ReferenceHemagglutininStructureAligned.objects.get_or_create(
                reference=ref, structure=pdb_object, position_map=position_map
            )
            if created:
                print("    Created alignment: {}".format(ref_str))
                count += 1
    
    print("Complete. Total {} ref-structure alignment objects created.".format(count))


def create_update_history(
        metadata_file='', counts={}, 
        description='', status=models.DatabaseStatus.ON
    ):
    obj = models.UpdateHistory.objects.create(
        metadata_file=metadata_file, counts=counts, description=description,
        status=status
    )
    return obj


def run():
    since = time.time()
    gisaid_dir = "/app/limh25/databases/gisaid_download"   # for files directly downloaded from gisaid
    gisaid_dir = sync_files(gisaid_dir)
    gisaid_processed_dir = "/app/limh25/databases/gisaid_processed"  # for processed files containing gisaid data
    
    files = collect_files(gisaid_dir, collect_old=True)  # {'aa_files': aa_files, 'nt_files': nt_files, 'metadata_files': metadata_files}

    reassign_clades = True
    reset = True
    
    # collect latest metadata
    latest_metadata_file = models.UpdateHistory.objects.latest().metadata_file
    if os.path.isfile(latest_metadata_file):
        latest_metadata = load_json(latest_metadata_file)
    else:
        latest_metadata = {}
    latest_metadata = update_metadata(latest_metadata, files['metadata_files'])
    latest_metadata_file = save_metadata(latest_metadata, gisaid_processed_dir)

    update_history_obj = create_update_history(metadata_file=latest_metadata_file, description='Update initiated', 
                                               status=models.DatabaseStatus.UPDATE_IN_PROGRESS_ISOLATE)

    segmentId2isolatePk = populate_isolates(latest_metadata, reset=reset)
    protein_objects_count = populate_proteins(files['aa_files'], reset=reset)
    nucleotide_objects_count = populate_nucleotides(files['nt_files'], reset=reset)

    update_history_obj.status = models.DatabaseStatus.UPDATE_IN_PROGRESS_ANNOTATIONS
    update_history_obj.description = "Isolate/sequence update complete. Updating annotations"
    update_history_obj.save()
    if reset:
        print("  Populating reference HA")
        populate_ref_ha(reset=reset)
        print("  Populating vaccine HA")
        populate_vaccine_ha(reset=reset)
        print("  Aligning vaccine-ref HA")
        populate_vaccine_ref_alignment()
        print("  Populating structures")
        populate_structures(reset=reset)
        print("  Computing sequence-structure alignment")
        popuate_structure_align_map()


    # annotate glycosylation sites
    print("  Updating glycosylation sites.")
    update_history_obj.status = models.DatabaseStatus.UPDATE_IN_PROGRESS_ANNOTATIONS
    update_history_obj.description = "Updating glycosylation sites"
    update_history_obj.save()
    glyc_counts = update_ha_glycosylation_sites(reset=reset)
    print("  Glycosylation sites annotated. {}".format(glyc_counts))

    # collect sequences where clade=null
    # collect isolate ids grouped by subtypes
    nextclade_temp_dir = settings.NEXTCLADE_TEMP_DIR
    nextclade_datasets = settings.NEXTCLADE_DATASET_NAMES
    if reassign_clades:
        isolate_ids_to_assign = {
            'h1n1': models.Isolate.objects.filter(subtype__name__icontains='h1n1').order_by().values_list('pk', flat=True),
            'h3n2': models.Isolate.objects.filter(subtype__name__icontains='h3n2').order_by().values_list('pk', flat=True),
            'b-victoria': models.Isolate.objects.filter(subtype__name__icontains='b').filter(lineage__name__icontains='victoria').order_by().values_list('pk', flat=True),
            'b-yamagata': models.Isolate.objects.filter(subtype__name__icontains='b').filter(lineage__name__icontains='yamagata').order_by().values_list('pk', flat=True)
        }
    else:
        isolate_ids_to_assign = {
            'h1n1': models.Isolate.objects.filter(clade=None).filter(subtype__name__icontains='h1n1').order_by().values_list('pk', flat=True),
            'h3n2': models.Isolate.objects.filter(clade=None).filter(subtype__name__icontains='h3n2').order_by().values_list('pk', flat=True),
            'b-victoria': models.Isolate.objects.filter(clade=None).filter(subtype__name__icontains='b').filter(lineage__name__icontains='victoria').order_by().values_list('pk', flat=True),
            'b-yamagata': models.Isolate.objects.filter(clade=None).filter(subtype__name__icontains='b').filter(lineage__name__icontains='yamagata').order_by().values_list('pk', flat=True)
        }
    update_history_obj.status = models.DatabaseStatus.UPDATE_IN_PROGRESS_CLADE_ASSIGNMENT
    update_history_obj.description = "Updating clade assignment"
    update_history_obj.save()
    ha_nt_fasta_files = write_ha_nt_sequences(isolate_ids_to_assign, nextclade_temp_dir)

    # perform nextclade assignment
    nextclade_output_files = run_nextclade(ha_nt_fasta_files, nextclade_temp_dir, nextclade_datasets, clean=True)

    # update isolate table with clade assignment
    updated_clade_count = update_clade_assignment(nextclade_output_files, clean=True)

    # update updatehistory table
    update_history_obj.status = models.DatabaseStatus.ON
    update_history_obj.description = "Update complete"
    update_history_obj.metadata_file = latest_metadata_file
    update_history_obj.counts = {
        'isolate': models.Isolate.objects.all().count(),
        'hemagglutinin': models.Hemagglutinin.objects.all().count(),
        'neuraminidase': models.Neuraminidase.objects.all().count(),
        'referencehemagglutinin': models.ReferenceHemagglutinin.objects.all().count(),
        'vaccinehemagglutinin': models.VaccineHemagglutinin.objects.all().count(),
        'pairwisealignedhemagglutinin': models.PairwiseAlignedHemagglutinin.objects.all().count(),
        'pdbstructure': models.PDBStructure.objects.all().count(),
        'referencehemagglutininstructurealigned': models.ReferenceHemagglutininStructureAligned.objects.all().count(),
    }
    update_history_obj.save()
    # update_history(latest_metadata_file, reassign_clades=reassign_clades)

    elapsed = (time.time() - since)/60.0
    print("Update complete. {:.2f} minutes elapsed.".format(elapsed))

    # max_previous_days = 30
    # print("Performing optional task. Pairwise alignment between HAs (past {} days) and reference HAs".format(max_previous_days))
    # # # pairwise alignment between new HA and reference HA
    # new_pairwise_alignment_count = align_ha(max_previous_days=max_previous_days)
    
