import os
import re
import time
import numpy as np
import pandas as pd
import json
from Bio import SeqIO
from datetime import datetime
from django.conf import settings
from proteins import utils
from proteins import models

def to_refs():
    ref2subs = settings.REFERENCE_TO_SUBTYPES
    refs = models.ReferenceHemagglutinin.objects.all().order_by()
    has = models.Hemagglutinin.objects.all().order_by()
    individual_sequence_dir = "/app/limh25/flu/flu/media/individual_sequences"
    ref_dir = settings.HA_REFERENCE_SEQUENCE_DIR
    params = {
        'subs_mat': 'BLOSUM62',
        'gap_open_penalty': -11.0,
        'gap_extension_penalty': -1.0,
    }

    alignment_dict = {}

    for ref in refs:
        refname = ref.reference_name
        individual_sequence_subdir = os.path.join(individual_sequence_dir, refname)
        os.makedirs(individual_sequence_subdir, exist_ok=True)

        query_types = ref2subs[refname]
        for ha in has.filter(subtype__name__in=query_types):
            filename = os.path.join(individual_sequence_subdir, "{}.fasta".format(ha.accession))

            with open(filename, 'w') as out:
                out.write('>{}\n'.format(ha.accession))
                out.write('{}'.format(
                    '\n'.join([ha.sequence[i:i+60] for i in range(0, len(ha.sequence), 60)])
                ))
            
            aln_id = "{}-{}".format(ref.accession, ha.accession)
            d = {
                'id': aln_id,
                'refname': refname,
                'subs_mat': params['subs_mat'],
                'gap_open_penalty': params['gap_open_penalty'],
                'gap_extension_penalty': params['gap_extension_penalty'],
                'ref_id': ref.accession,
                'query_id': ha.accession,
            }
            alignment_dict[aln_id] = d
    utils.save_json(alignment_dict, "/app/limh25/flu/scripts/HA_mass_alignment.json")

def to_vacs():
    has = models.Hemagglutinin.objects.all().order_by()
    vacs = models.VaccineHemagglutinin.objects.all().order_by()
    vaccine_dir = "/app/limh25/flu/flu/media/individual_sequences/vaccines"
    all_dir = "/app/limh25/flu/flu/media/individual_sequences/all"
    params = {
        'subs_mat': 'BLOSUM62',
        'gap_open_penalty': -11.0,
        'gap_extension_penalty': -1.0,
    }
    alignment_dict = {}
    for vac in vacs:
        vac_acc = vac.ha.accession
        vac_seq = vac.ha.sequence
        vac_file = os.path.join(vaccine_dir, "{}.fasta".format(vac_acc))
        with open(vac_file, "w") as out:
            out.write('>{}\n'.format(vac_acc))
            out.write('\n'.join([vac_seq[i:i+60] for i in range(0, len(vac_seq), 60)]))
        for ha in has:
            aln_id = "{}-{}".format(vac_acc, ha.accession)
            ha_subdir = os.path.join(all_dir, ha.accession.replace('EPI','')[:2])
            os.makedirs(ha_subdir, exist_ok=True)
            ha_file = os.path.join(ha_subdir, "{}.fasta".format(ha.accession))
            if not os.path.isfile(ha_file):
                with open(ha_file, "w") as out:
                    out.write('>{}\n'.format(ha.accession))
                    out.write('\n'.join([ha.sequence[i:i+60] for i in range(0, len(ha.sequence), 60)]))
            d = {
                'id': aln_id,
                'vaccine_strain': vac.ha.isolate.name,
                'subs_mat': params['subs_mat'],
                'gap_open_penalty': params['gap_open_penalty'],
                'gap_extension_penalty': params['gap_extension_penalty'],
                'ref_id': vac_acc,
                'subdir_number': ha.accession.replace('EPI','')[:2],
                'query_id': ha.accession,
            }
            alignment_dict[aln_id] = d
    utils.save_json(alignment_dict, "/app/limh25/flu/scripts/HA_vaccine_mass_alignment.json")


def run():
    # to_refs()
    to_vacs()

