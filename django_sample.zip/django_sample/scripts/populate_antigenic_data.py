import os
import numpy as np
import pandas as pd
import json
import tqdm
from datetime import datetime
from django.conf import settings
from proteins import utils
from proteins import models as prot_models
from proteins import sequence_alignment as sa
from nucleotides import models as nucl_models
from nucleotides import translate as nucl_translate
from annotations import models as annot_models
from annotations import glycosylation as glyco


def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise ValueError('Boolean value expected.')

class NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return json.JSONEncoder.default(self, obj)

def load_json(filename):
    with open(filename, 'r') as fp:
        data = json.load(fp)
    return data

def save_json(data,filename):
    with open(filename, 'w') as fp:
        json.dump(data, fp, sort_keys=True, indent=4, cls=NumpyEncoder)


def collect_json_data(jsonl_file):

    data = []
    with open(jsonl_file, 'r') as inf:
        for line in inf:
            data.append(json.loads(line.strip()))
    return data

def get_standardized_isolate_id(name):
    name_table = {
        'A/N. CALEDONIA/20/99': 'EPI_ISL_158137',
        'A/FLORIDA/04/2004': 'EPI_ISL_6292',  # A/FLORIDA/4/2004
        'A/KENTUCKY/01/2005': 'EPI_ISL_6295', # A/Kentucky/1/2005
        'A/PENNSYLVANIA/01/2006': 'EPI_ISL_6309', # A/Pennsylvania/1/2006
        'A/KANGWON/799/2005': 'EPI_ISL_64651', # A/Gangwon/799/2005
        'A/ARIZONA/01/2006': 'EPI_ISL_6308', # A/Arizona/1/2006
        'A/VIRGINIA/01/2006': 'EPI_ISL_6311', # A/Virginia/1/2006
        'A/Brisbane/59/2007 [MDCKx+2]': 'EPI_ISL_76250',
        'A/Bordeaux/1314/07': 'EPI_ISL_23921', # A/Bordeaux/1314/2007
        'A/BRISBANE/59/2007 IVR-148': 'EPI_ISL_60784', # IVR-148(A/Brisbane/59/2007)
        'A/BRISBANE/10/2010 IVR-158': 'EPI_ISL_13563956', # IVR-158 (A/Brisbane/10/2010)
        'A/HONG KONG/1870/2008 E': 'EPI_ISL_26231', # A/Hong Kong/1870/2008
        'A/CALIFORNIA/07/2009 NYMC X-179A': 'EPI_ISL_207653', # A/California/07/2009 NYMC X-179A (14/116)
        'A/ILLINOIS/33295(9)/2007': 'EPI_ISL_356946', # A/Illinois/9/2007
        'A/ST PETERSBURG/100/2011': 'EPI_ISL_89916', # A/St. Petersburg/100/2011
        'A/CALIFORNIA/07/2009  [X-179A]': 'EPI_ISL_73798', # A/California/07/2009 X-179A
        'A/WYOMING/31/2012@': 'EPI_ISL_134436',
        'A/CALIFORNIA/7/2009': 'EPI_ISL_31158', # A/California/07/2009
        'A/BANGLADESH/2021/2012 [1]': 'EPI_ISL_129692',
        'A/WASHINGTON/24/2012 [1]': 'EPI_ISL_128403',
        'A/DOMINICAN R./7293/2013': 'EPI_ISL_142876', # A/Dominican Republic/7293/2013
        'A/HONG KONG/5008/13': 'EPI_ISL_164398', # A/Hong Kong/5008/2013
        'A/PERU/51 /2016': 'EPI_ISL_230528', # A/Peru/51/2016
        'A/MONTANA/50/2016MDCK': 'EPI_ISL_248953', #A/Montana/50/2016

        #####------H3N2 below ------#####
        'A/NEW JERSEY/04/2001': 'EPI_ISL_185575', # A/New Jersey/4/2001
        'A/WASHINGTON/07/2001': 'EPI_ISL_188020', # A/Washington/7/2001
        'A/SOUTH DAKOTA/01/2001': 'EPI_ISL_187038', # A/South Dakota/1/2001
        'A/S. AUSTRALIA/98/2001': 'EPI_ISL_186265', # A/South Australia/98/2001
        'A/S. AUSTRALIA/102/2001': 'EPI_ISL_68007', # A/South Australia/102/2001
        'A/DARWIN/03/2000': 'EPI_ISL_5522535', # A/DARWIN/3/2000
        'A/PANAMA/2007/99': 'EPI_ISL_2674', # A/Panama/2007/1999
        'A/WEST VIRGINIA/01/2005': 'EPI_ISL_11547', # A/West Virginia/1/2005
        'A/WYOMING/03/2003 X-147': 'EPI_ISL_6949771', # X-147 (A/Wyoming/3/2003)
        'A/NORTH DAKOTA/01/2004': 'EPI_ISL_21241', # A/North Dakota/1/2004
        'A/GEORGIA/01/2005': 'EPI_ISL_11551', # A/Georgia/1/2005
        'A/NEW YORK/03/2005': 'EPI_ISL_11552',
        'A/ARIZONA/03/2005': 'EPI_ISL_11550', # A/Arizona/3/2005
        'A/VIRGINIA/03/2005': 'EPI_ISL_11553', # A/Virginia/3/2005
        'A/KENTUCKY/03/2006': 'EPI_ISL_21271',  # A/KENTUCKY/3/2006
        'A/WISCONSIN/67/05 R-161B': 'EPI_ISL_11976298', # X-161B (A/Wisconsin/67/2005)
        'A/N. CAROLINA/04/2016': 'EPI_ISL_208613', # A/North Carolina/04/2016
    }
    return name_table.get(name, None)

def run():
    reset = True
    base_dir = "/app/limh25/databases/flu_antigenic"
    h1n1_file = os.path.join(base_dir, "h1n1/h1n1_antigenic_data.json")
    h3n2_file = os.path.join(base_dir, "h3n2/h3n2_antigenic_data.json")
    log_dir = "/app/limh25/flu/logs"
    log_file = os.path.join(log_dir, "titer_log.txt")
    datasets = {
        'H1N1': collect_json_data(h1n1_file),
        'H3N2': collect_json_data(h3n2_file)
    }
    if reset:
        annot_models.HemagglutininAntigenicTiter.objects.all().delete()

    with open(log_file, 'w') as out:
        for subtype in datasets:
            dataset = datasets[subtype]
            count = 0
            count_self = 0
            reference_self_dilution_samples = {}  # key: ref_virus_name -> [ (published_year, collection_date, self_dilution) ]
            ref_ha_objects = {}
            out.write("Start processing {} antigenic data...\n".format(subtype))
            for data in tqdm.tqdm(dataset, total=len(dataset)):
                test_virus_name = data['test_virus_name']
                standard_id = get_standardized_isolate_id(test_virus_name)
                # search for matching hemagglutinin object
                if standard_id:
                    test_ha = prot_models.Hemagglutinin.objects.filter(isolate__accession__iexact=standard_id).first()
                else:
                    test_ha = prot_models.Hemagglutinin.objects.filter(isolate__name__iexact=test_virus_name).first()
                if not test_ha:
                    out.write("Test virus hemagglutinin object not found. Skipping {}.\n".format(test_virus_name))
                    continue

                titers = data['meta_data'][0]
                pub_year = titers['publishing_year']
                try:
                    collection_date = datetime.strptime(titers['collection_date'], '%m/%d/%Y')
                except:
                    continue
                passage = titers['passage']
                titer_samples = titers['hi_titer_data']

                for titer_sample in titer_samples:
                    self_dilution = titer_sample['reference_self_dilution']
                    dilution = titer_sample['dilution']
                    reference_virus_name = titer_sample['reference_virus_name']
                    standard_id_ref = get_standardized_isolate_id(reference_virus_name)
                    if standard_id_ref:
                        ref_ha = prot_models.Hemagglutinin.objects.filter(isolate__accession__iexact=standard_id_ref).first()
                    else:
                        ref_ha = prot_models.Hemagglutinin.objects.filter(isolate__name__iexact=reference_virus_name).first()
                    if not ref_ha:
                        out.write("Ref virus hemagglutinin object not found. Skipping {}.\n".format(reference_virus_name))
                        continue
                    ref_ha_objects[reference_virus_name] = ref_ha
                    if reference_virus_name not in reference_self_dilution_samples:
                        reference_self_dilution_samples[reference_virus_name] = [(pub_year, collection_date, self_dilution)]
                    else:
                        reference_self_dilution_samples[reference_virus_name].append((pub_year, collection_date, self_dilution))
                    titer_obj, created = annot_models.HemagglutininAntigenicTiter.objects.get_or_create(
                        published_year=pub_year, collection_date=collection_date,
                        test_virus=test_ha, reference_virus=ref_ha,
                        dilution=dilution
                    )
                    count += 1
            for ref_name in reference_self_dilution_samples:
                ref_samples = list(set(reference_self_dilution_samples[ref_name]))
                for ref_sample in ref_samples:
                    titer_obj, created = annot_models.HemagglutininAntigenicTiter.objects.get_or_create(
                        published_year=ref_sample[0], collection_date=ref_sample[1], dilution=ref_sample[2],
                        test_virus=ref_ha_objects[ref_name], reference_virus=ref_ha_objects[ref_name],
                    )
                    count_self += 1
            
            out.write("\n{}: Created {} titer objects, including {} self-dilutions.\n".format(subtype, count+count_self, count_self))

