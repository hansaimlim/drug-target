import os
import re
import numpy as np
import pandas as pd
import json
import tqdm
from Bio import AlignIO, SeqIO, Seq, SeqRecord
from datetime import datetime
from django.conf import settings
from proteins import utils
from proteins import models as prot_models
from nucleotides import models as nucl_models
from annotations import models as annot_models

base_path = "/app/limh25/databases/gisaid_processed"
output_path_per_clade = os.path.join(base_path, "per_clade")
output_path_per_lineage = os.path.join(base_path, "per_lineage")

def write_sequences_to_fasta(fasta_file, objects):
    ref_seq = {'obj': None, 'sequence': '', 'count-x': 999}
    with open(fasta_file, 'w') as out:
        print("  output file: {}".format(fasta_file))
        for obj in tqdm.tqdm(objects, total=objects.count()):
            passage_name = obj.isolate.passage.standardized_name if obj.isolate.passage else 'Unknown'
            subtype_name = obj.isolate.subtype.name if obj.isolate.subtype else 'Unknown'
            header = '>{}|{}|{}|{}|{}\n'.format(
                obj.isolate.accession, obj.isolate.name, obj.accession, 
                passage_name, subtype_name
            )
            seq = '\n'.join([obj.sequence[i:i+60] for i in range(0, len(obj.sequence), 60)])
            out.write(header)
            out.write(seq)
            out.write('\n')

            if len(obj.sequence) > len(ref_seq['sequence']):
                # longer than previous longest
                if obj.sequence.upper().count('X') <= ref_seq['count-x']:
                    ref_seq['obj'] = obj
                    ref_seq['sequence'] = obj.sequence
                    ref_seq['count-x'] = obj.sequence.upper().count('X')
    return ref_seq


def write_single_sequence_to_fasta(fasta_file, obj):
    with open(fasta_file, 'w') as out:
        passage_name = obj.isolate.passage.standardized_name if obj.isolate.passage else 'Unknown'
        subtype_name = obj.isolate.subtype.name if obj.isolate.subtype else 'Unknown'
        header = '>{}|{}|{}|{}|{}\n'.format(
                obj.isolate.accession, obj.isolate.name, obj.accession, 
                passage_name, subtype_name
            )
        seq = '\n'.join([obj.sequence[i:i+60] for i in range(0, len(obj.sequence), 60)])
        out.write(header)
        out.write(seq)
        out.write('\n')


def write_sequences_per_clade(proteins, nucleotides, clade, segment_name):
    prot_file = os.path.join(output_path_per_clade, "{}_aa_{}.fasta".format(segment_name, clade))
    prot_ref_file = os.path.join(output_path_per_clade, "{}_aa_ref_{}.fasta".format(segment_name, clade))
    nucl_file = os.path.join(output_path_per_clade, "{}_nt_{}.fasta".format(segment_name, clade))
    nucl_ref_file = os.path.join(output_path_per_clade, "{}_nt_ref_{}.fasta".format(segment_name, clade))

    if proteins.count() > 0:
        ref_prot = write_sequences_to_fasta(prot_file, proteins)
        write_single_sequence_to_fasta(prot_ref_file, ref_prot['obj'])
    if nucleotides.count() > 0:
        ref_nucl = write_sequences_to_fasta(nucl_file, nucleotides)
        write_single_sequence_to_fasta(nucl_ref_file, ref_nucl['obj'])
    data = {
        'protein_fasta': prot_file,
        'nucleotide_fasta': nucl_file,
        'protein_count': proteins.count(),
        'nucleotide_count': nucleotides.count(),
    }
    return data


def write_sequences_per_subtype(proteins, nucleotides, subtype, segment_name):
    
    prot_file = os.path.join(output_path_per_lineage, "{}_aa_{}.fasta".format(segment_name, subtype.replace('A / ','')))
    prot_ref_file = os.path.join(output_path_per_lineage, "{}_aa_ref_{}.fasta".format(segment_name, subtype.replace('A / ','')))
    nucl_file = os.path.join(output_path_per_lineage, "{}_nt_{}.fasta".format(segment_name, subtype.replace('A / ','')))
    nucl_ref_file = os.path.join(output_path_per_lineage, "{}_nt_ref_{}.fasta".format(segment_name, subtype.replace('A / ','')))

    if proteins.count() > 0:
        ref_prot = write_sequences_to_fasta(prot_file, proteins)
        write_single_sequence_to_fasta(prot_ref_file, ref_prot['obj'])
    if nucleotides.count() > 0:
        ref_nucl = write_sequences_to_fasta(nucl_file, nucleotides)
        write_single_sequence_to_fasta(nucl_ref_file, ref_nucl['obj'])
    
    data = {
        'protein_fasta': prot_file,
        'nucleotide_fasta': nucl_file,
        'protein_count': proteins.count(),
        'nucleotide_count': nucleotides.count(),
    }
    return data


def write_sequences():
    # unique_clades = prot_models.Isolate.objects.order_by().filter(host__name__iexact='human').values_list('clade__full_name', flat=True).distinct()
    # unique_subtypes = prot_models.Isolate.objects.order_by().filter(host__name__iexact='human').values_list('subtype__name', flat=True).distinct()
    unique_clades = prot_models.Clade.objects.order_by().in_bulk(prot_models.Isolate.objects.order_by().values_list('clade__full_name', flat=True).distinct(), field_name='full_name')
    unique_subtypes = prot_models.IsolateSubtype.objects.order_by().in_bulk(prot_models.Isolate.objects.order_by().values_list('subtype__name', flat=True).distinct(), field_name='name')

    pairs = [
        {
          'segment'        : 'HA',
          'isolate_model'  : prot_models.Isolate,
          'prot_model'     : prot_models.Hemagglutinin,
          'nucl_model'     : nucl_models.Hemagglutinin,

        },
        {
          'segment'        : 'NA',
          'isolate_model'  : prot_models.Isolate,
          'prot_model'     : prot_models.Neuraminidase,
          'nucl_model'     : nucl_models.Neuraminidase,
        }
    ]

    for pair in pairs:
        segment_name = pair['segment']
        
        for clade in unique_clades:
            if not clade:
                # skipping unknown clades
                continue
            prot_model = pair['prot_model'].objects.filter(isolate__clade__full_name__iexact=clade).order_by()
            nucl_model = pair['nucl_model'].objects.filter(isolate__clade__full_name__iexact=clade).order_by()
            print("   Clade:{}, protein-count:{}".format(clade, prot_model.count()))
            results = write_sequences_per_clade(prot_model, nucl_model, clade, segment_name)
            ff = annot_models.FastaFilebyClade.objects.create(
                fasta_file=results['protein_fasta'], sequence_type=annot_models.SequenceType.AMINO_ACID,
                num_sequences=results['protein_count'], category=unique_clades[clade]
            )
            ff = annot_models.FastaFilebyClade.objects.create(
                fasta_file=results['nucleotide_fasta'], sequence_type=annot_models.SequenceType.NUCLEOTIDE,
                num_sequences=results['nucleotide_count'], category=unique_clades[clade]
            )
        
        for subtype in unique_subtypes:
            # proteins = prot_model.objects.filter(isolate__host__name__iexact='human').filter(isolate__subtype__name__iexact=subtype).order_by()
            # nucleotides = nucl_model.objects.filter(isolate__host__name__iexact='human').filter(isolate__subtype__name__iexact=subtype).order_by()
            prot_model = pair['prot_model'].objects.filter(isolate__subtype__name__iexact=subtype).filter(isolate__host__name__iexact='human').order_by()
            nucl_model = pair['nucl_model'].objects.filter(isolate__subtype__name__iexact=subtype).filter(isolate__host__name__iexact='human').order_by()
            print("   Subtype:{}, protein-count:{}".format(subtype, prot_model.count()))
            if subtype.lower().startswith('b'):
                unique_mol_subtypes = prot_models.MoleculeSubtype.objects.order_by().in_bulk(prot_model.values_list('subtype__name', flat=True).distinct(), field_name='name')
                for mol_sub in unique_mol_subtypes:
                    prot_model_ = prot_model.filter(subtype__name__icontains=mol_sub)
                    nucl_model_ = nucl_model.filter(subtype__name__icontains=mol_sub)
                    print("     Subtype:{}, mol-subtype:{}, protein-count:{}".format(subtype, mol_sub, prot_model.count()))
                    results = write_sequences_per_subtype(prot_model_, nucl_model_, mol_sub, segment_name)
                    ff = annot_models.FastaFilebySubtype.objects.create(
                        fasta_file=results['protein_fasta'], sequence_type=annot_models.SequenceType.AMINO_ACID,
                        num_sequences=results['protein_count'], category=unique_subtypes[subtype],
                        subcategory=unique_mol_subtypes[mol_sub]
                    )
                    ff = annot_models.FastaFilebySubtype.objects.create(
                        fasta_file=results['nucleotide_fasta'], sequence_type=annot_models.SequenceType.NUCLEOTIDE,
                        num_sequences=results['nucleotide_count'], category=unique_subtypes[subtype],
                        subcategory=unique_mol_subtypes[mol_sub]
                    )
                        
            else:
                print("Writing {} sequences...".format(subtype))
                results = write_sequences_per_subtype(prot_model, nucl_model, subtype, segment_name)
                ff = annot_models.FastaFilebySubtype.objects.create(
                    fasta_file=results['protein_fasta'], sequence_type=annot_models.SequenceType.AMINO_ACID,
                    num_sequences=results['protein_count'], category=unique_subtypes[subtype]
                )
                ff = annot_models.FastaFilebySubtype.objects.create(
                    fasta_file=results['nucleotide_fasta'], sequence_type=annot_models.SequenceType.NUCLEOTIDE,
                    num_sequences=results['nucleotide_count'], category=unique_subtypes[subtype]
                )
  

def run():
    write_sequences()


    