import os
import re
import time
import numpy as np
import pandas as pd
import json
from datetime import datetime
from django.conf import settings
from proteins import utils
from proteins import models

def sort_isolate_ids(isolate_ids):
    id_dict = {i: int(i.strip().split('_')[-1]) for i in isolate_ids}
    return {k: v for k, v in sorted(id_dict.items(), key=lambda item: item[1])}

def check_nan(entry):
    # return None if NaN
    if type(entry) == float:
        if np.isnan(entry):
            return None
    return entry

def standardize_date(date_string):
    date_string = check_nan(date_string)
    if not date_string:
        return None

    full_pattern = r'([\d]{4})-([\d]{1,2})-([\d]{1,2})'
    month_pattern = r'([\d]{4})-([\d]{1,2})'
    year_pattern = r'([\d]{4})'

    m = re.search(full_pattern, date_string)
    if m:
        date = datetime.strptime(date_string, "%Y-%m-%d")
    else:
        m = re.search(month_pattern, date_string)
        if m:
            date = datetime.strptime(date_string, "%Y-%m")
        else:
            m = re.search(year_pattern, date_string)
            if m:
                date = datetime.strptime(date_string, "%Y")
            else:
                date = None
    return date


def parse_location(location):
    locs = location.strip().split('/')
    if len(locs) >= 3:
        continent = locs[0].lstrip().strip()
        country   = locs[1].lstrip().strip()
        region    = locs[2].lstrip().strip()
    elif len(locs) >= 2:
        continent = locs[0].lstrip().strip()
        country   = locs[1].lstrip().strip()
        region    = 'Unknown'
    elif len(locs) >= 1:
        continent = locs[0].lstrip().strip()
        country   = 'Unknown'
        region    = 'Unknown'
    else:
        continent = 'Unknown'
        country   = 'Unknown'
        region    = 'Unknown'
    return {
        'continent': continent,
        'country'  : country,
        'region'   : region,
    }


def run():
    metadata_file = os.path.join(settings.GISAID_METADATA_JSON_DIR, "metadata_latest.json")
    metadata = utils.load_json(metadata_file)
    isolate_ids = [k for k in sort_isolate_ids(list(metadata.keys()))]

    count = 0
    since = time.time()
    for isolate_id in isolate_ids:
        data = metadata[isolate_id]
        collection_date = standardize_date(data['collection_date'])
        submission_date = standardize_date(data['submission_date'])
        host, _ = models.Host.objects.get_or_create(name=data['host'])
        host_age_unit = check_nan(data['host_age_unit'])
        if host_age_unit:
            host_age_unit, _ = models.AgeUnit.objects.get_or_create(name=host_age_unit)
        host_age = check_nan(data['host_age'])
        host_gender = check_nan(data['host_gender'])
        if host_gender:
            host_gender, _ = models.Gender.objects.get_or_create(name=host_gender)
        else:
            host_gender, _ = models.Gender.objects.get_or_create(name='Unknown')
        name = data['isolate_name']
        passage = check_nan(data['passage'])
        if passage:
            passage = models.Passage.objects.get(name=passage.strip().lstrip())
        else:
            passage = models.Passage.objects.get(name='Unknown')
        
        lineage = check_nan(data['lineage'])
        if lineage:
            lineage, _ = models.Lineage.objects.get_or_create(name=lineage)
        else:
            lineage, _ = models.Lineage.objects.get_or_create(name='Unknown')
        
        location = check_nan(data['location'])
        if location:
            location = parse_location(location)
            continent, _ = models.Continent.objects.get_or_create(name=location['continent'])
            country, _   = models.Country.objects.get_or_create(name=location['country'])
            region, _    = models.Region.objects.get_or_create(name=location['region'])
        else:
            continent, _ = models.Continent.objects.get_or_create(name='Unknown')
            country, _   = models.Country.objects.get_or_create(name='Unknown')
            region, _    = models.Region.objects.get_or_create(name='Unknown')

        submit_lab = check_nan(data['submit_lab'])
        origin_lab = check_nan(data['origin_lab'])
        if submit_lab:
            submit_lab, _ = models.Laboratory.objects.get_or_create(name=submit_lab)
        else:
            submit_lab, _ = models.Laboratory.objects.get_or_create(name='Unknown')
        if origin_lab:
            origin_lab, _ = models.Laboratory.objects.get_or_create(name=origin_lab)
        else:
            origin_lab, _ = models.Laboratory.objects.get_or_create(name='Unknown')

        subtype = check_nan(data['subtype'])
        if subtype:
            subtype, _ = models.IsolateSubtype.objects.get_or_create(name=subtype)
        else:
            subtype, _ = models.IsolateSubtype.objects.get_or_create(name='Unknown')
        
        isolate = models.Isolate.objects.create(
            accession=isolate_id, name=name,
            collection_date=collection_date, submission_date=submission_date,
            host=host, host_age=host_age, passage=passage,
            host_age_unit=host_age_unit, host_gender=host_gender,
            lineage=lineage, continent=continent, country=country, region=region,
            subtype=subtype, submit_lab=submit_lab, origin_lab=origin_lab
        )
        count += 1

    elapsed = (time.time() - since)/60.0

    print("Complete! Created {} isolate objects. {:.2f} mintes elapsed.".format(
        count, elapsed
    ))
        