import os
import sys
import re
import csv
import time
import numpy as np
import pandas as pd
from contextlib import closing
from io import StringIO
import json
import tqdm
import multiprocessing as mp
from django.db.models import Sum, Count, Q
from itertools import product, islice
from datetime import datetime, timedelta
from django.conf import settings
from django.db import connection
from django.core.management.color import no_style
from django.utils import timezone
from proteins import utils
from proteins import models
from Bio import SeqIO, Seq
from proteins import sequence_alignment as sa
from proteins import structure_info as si
from proteins import protein_structure as ps
from proteins import views as prot_views
from nucleotides import models as nucl_models
from nucleotides import translate as nucl_translate
from annotations import models as annot_models
from annotations import glycosylation as glyc
from proteins import vaccine
from proteins import epitopes as ep
from proteins import reference2structure as ref2pdb
from biotite.structure.io import pdb
from biotite import structure as bts


caches = {
        # 'host-Unknown'        : models.Host.objects.get_or_create(name='Unknown')[0],
        # 'gender-Unknown'      : models.Gender.objects.get_or_create(name='Unknown')[0],
        # 'passage-Unknown'     : models.Passage.objects.get_or_create(name='Unknown')[0],
        # 'lineage-Unknown'     : models.Lineage.objects.get_or_create(name='Unknown')[0],

        # 'continent-Unknown'   : models.Continent.objects.get_or_create(name='Unknown')[0],
        # 'country-Unknown'     : models.Country.objects.get_or_create(name='Unknown')[0],
        # 'region-Unknown'      : models.Region.objects.get_or_create(name='Unknown')[0],
        # 'lab-Unknown'         : models.Laboratory.objects.get_or_create(name='Unknown')[0],
        # 'isolate-subtype-Unknown'     : models.IsolateSubtype.objects.get_or_create(name='Unknown')[0],
    }  # for faster database query
batch_size = 10000  # for bulk_create operations
ncpus = 14  # for multiprocessing fasta parsing
protein_segment_models = models.SEGMENT_MODELS
nucleotide_segment_models = nucl_models.SEGMENT_MODELS

has = models.Hemagglutinin.objects.in_bulk(models.Hemagglutinin.objects.all().values_list('accession', flat=True), field_name='accession')
unique_subtypes = models.IsolateSubtype.objects.order_by().in_bulk(models.Isolate.objects.order_by().values_list('subtype__name', flat=True).distinct(), field_name='name')
has_by_subtype = {
    'H1N1': models.Hemagglutinin.objects.in_bulk(models.Hemagglutinin.objects.filter(isolate__subtype__name__icontains='h1n1').filter(isolate__isnull=False).order_by().distinct().values_list('accession', flat=True), field_name='accession'),
    'H3N2': models.Hemagglutinin.objects.in_bulk(models.Hemagglutinin.objects.filter(isolate__subtype__name__icontains='h3n2').filter(isolate__isnull=False).order_by().distinct().values_list('accession', flat=True), field_name='accession'),
    'B-Victoria': models.Hemagglutinin.objects.in_bulk(models.Hemagglutinin.objects.filter(isolate__subtype__name__icontains='b').filter(isolate__isnull=False).filter(subtype__name__icontains='victoria').order_by().distinct().values_list('accession', flat=True), field_name='accession'),
    'B-Yamagata': models.Hemagglutinin.objects.in_bulk(models.Hemagglutinin.objects.filter(isolate__subtype__name__icontains='b').filter(isolate__isnull=False).filter(subtype__name__icontains='yamagata').order_by().distinct().values_list('accession', flat=True), field_name='accession'),
}
pdb_objects = models.PDBStructure.objects.in_bulk(models.PDBStructure.objects.all().order_by().values_list('pdb_id', flat=True), field_name='pdb_id')
subtype2pdbid = {
    'H1N1': '4m4y',
    'H3N2': '4o5n',
    'B-Victoria': '4fqm',
    'B-Yamagata': '2rfu',
}
subtype2referencename = {
    "H1N1": "H1_PR34",
    "H3N2": "H3",
    "B-Victoria": "B_Victoria",
    "B-Yamagata": "B_Yamagata",
}
ref_has = models.ReferenceHemagglutinin.objects.in_bulk(models.ReferenceHemagglutinin.objects.all().order_by().values_list('reference_name', flat=True), field_name='reference_name')
vaccine_objects = models.VaccineHemagglutinin.objects.in_bulk(models.VaccineHemagglutinin.objects.all().order_by('-latest_vaccine_year').values_list('pk', flat=True), field_name='pk')
vaccine_has_by_subtype = {
    'H1N1': models.VaccineHemagglutinin.objects.in_bulk(models.VaccineHemagglutinin.objects.filter(ha__subtype__name__icontains='h1').filter(ha__isolate__isnull=False).order_by('-latest_vaccine_year').distinct().values_list('pk', flat=True), field_name='pk'),
    'H3N2': models.VaccineHemagglutinin.objects.in_bulk(models.VaccineHemagglutinin.objects.filter(ha__subtype__name__icontains='h3').filter(ha__isolate__isnull=False).order_by('-latest_vaccine_year').distinct().values_list('pk', flat=True), field_name='pk'),
    'B-Victoria': models.VaccineHemagglutinin.objects.in_bulk(models.VaccineHemagglutinin.objects.filter(ha__subtype__name__icontains='victoria').filter(ha__isolate__isnull=False).order_by('-latest_vaccine_year').distinct().values_list('pk', flat=True), field_name='pk'),
    'B-Yamagata': models.VaccineHemagglutinin.objects.in_bulk(models.VaccineHemagglutinin.objects.filter(ha__subtype__name__icontains='yamagata').filter(ha__isolate__isnull=False).order_by('-latest_vaccine_year').distinct().values_list('pk', flat=True), field_name='pk'),
}




def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise ValueError('Boolean value expected.')

class NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return json.JSONEncoder.default(self, obj)

def load_json(filename):
    with open(filename, 'r') as fp:
        data = json.load(fp)
    return data

def save_json(data,filename):
    with open(filename, 'w') as fp:
        json.dump(data, fp, sort_keys=True, indent=4, cls=NumpyEncoder)


def collect_pairwise_features(x):
    # intended for multiprocessing
    subtype = x['subtype']
    input_ha_accession = x['input_ha_accession']
    pdb_id = x['pdb_id']
    vaccine_pk = x['vaccine_pk']
    output_file = x['output_file']

    ref_name = subtype2referencename[subtype]
    input_ha = has_by_subtype[subtype][input_ha_accession]
    input_sequence = input_ha.sequence
    input_glyc_sites = glyc.find_glycosylation_sites(input_sequence)

    structure_obj = pdb_objects.get(pdb_id, None)
    vaccine_obj = vaccine_objects.get(vaccine_pk, None)
    reference_obj = ref_has.get(ref_name, None)
    position_map = caches.get('posmap-ref{}-struc{}'.format(reference_obj.pk, structure_obj.pk), None)
    if (not structure_obj) or (not vaccine_obj) or (not reference_obj) or (not position_map):
        return None

    vaccine_glyc_sites = caches['vac-glyc-{}'.format(vaccine_pk)]
    try:
        alignment_input_vac = sa.pairwise_align(ref_seq=vaccine_obj.ha.sequence, query_seq=input_sequence)
        z = zip(alignment_input_vac['reference_aligned'], alignment_input_vac['query_aligned'])  # make sure the alignment does not produce an error
    except:
        return None
    vaccine2reference = caches['vac2ref-vac{}-ref{}'.format(vaccine_obj.pk, reference_obj.pk)]
    egg_adaptation_dict = caches['egg-{}'.format(reference_obj.pk)]
    mutation_info = prot_views.collect_mutations_for_structure_visualization(alignment_input_vac, vaccine2reference, position_map, structure_obj, reference_obj, input_glyc_sites, vaccine_glyc_sites, egg_adaptation_dict)

    # triple_alignment = mutation_info['triple_alignment']
    substitutions = mutation_info['substitutions']
    
    d = {
        'pdb_id': pdb_id,
        'subtype': subtype,
        'query_ha_id': input_ha_accession,
        'query_isolate_id': input_ha.isolate.accession,
        'query_isolate_name': input_ha.isolate.name,
        'query_sequence_count_x': input_ha.sequence.upper().count('X'),
        # 'query_sequence': input_sequence,
        'vaccine_isolate_id': vaccine_obj.ha.isolate.accession,
        'vaccine_isolate_name': vaccine_obj.ha.isolate.name,
        'vaccine_ha_id': vaccine_obj.ha.accession,
        # 'vaccine_sequence': vaccine_obj.ha.sequence,
        'vaccine_sequence_count_x': vaccine_obj.ha.sequence.upper().count('X'),
        'vaccine_years': vaccine_obj.vaccine_years,
        'query_vaccine_alignment': alignment_input_vac,
        'vaccine_to_reference': vaccine2reference,
        'substitutions': substitutions,
    }
    save_json(d, output_file)

    return d


def populate_posmap_cache():
    count = 0
    pairs = list(product(list(ref_has.keys()), list(pdb_objects.keys())))
    for pair in tqdm.tqdm(pairs, total=len(pairs)):
        ref_name, pdb_id = pair
        ref_obj = ref_has[ref_name]
        pdb_obj = pdb_objects[pdb_id]
        caches['posmap-ref{}-struc{}'.format(ref_obj.pk, pdb_obj.pk)] = ref2pdb.get_position_map(ref_obj, pdb_obj)
        count += 1
    return count


def populate_vaccine2reference_cache():
    count = 0
    pairs = list(product(list(ref_has.keys()), list(vaccine_objects.keys())))
    for pair in tqdm.tqdm(pairs, total=len(pairs)):
        ref_name, vaccine_pk = pair
        reference_obj = ref_has.get(ref_name, None)
        vaccine_obj = vaccine_objects.get(vaccine_pk, None)
        if (not reference_obj) or (not vaccine_obj):
            continue
        vaccine2reference_obj = models.VaccineToReferenceHemagglutinin.objects.filter(vaccine=vaccine_obj).filter(reference=reference_obj).first()
        vaccine2reference = {}
        vac_idx = vaccine2reference_obj.vaccine_start
        ref_idx = vaccine2reference_obj.reference_start
        for i, (v, r) in enumerate(zip(vaccine2reference_obj.vaccine_aligned, vaccine2reference_obj.reference_aligned)):
            if v != '-':
                vaccine2reference[vac_idx] = ref_idx
                vac_idx += 1
            if r != '-':
                ref_idx += 1
        caches['vac2ref-vac{}-ref{}'.format(vaccine_obj.pk, reference_obj.pk)] = vaccine2reference
        count += 1
    return count


def populate_eggadaptation_cache():
    count = 0
    for ref_name in tqdm.tqdm(ref_has, total=len(ref_has)):
        reference_obj = ref_has.get(ref_name, None)
        if not reference_obj:
            continue
        egg_adaptation_sites = annot_models.EggAdaptationEnrichmentScore.objects.filter(subtype=reference_obj.ha.subtype).filter(score__gte=0.5)
        egg_adaptation_dict = {
            (e.position, e.amino_acid):{
                'score':e.score, 'count_original': e.count_original,
                'count_cell': e.count_cell, 'count_egg': e.count_egg,
                'position': e.position, 'amino_acid': e.amino_acid,
            } 
            for e in egg_adaptation_sites
        }
        caches['egg-{}'.format(reference_obj.pk)] = egg_adaptation_dict
        count += 1
    return count

def populate_vaccine_glyc_cache():
    count = 0
    for vac_pk in tqdm.tqdm(vaccine_objects, total=len(vaccine_objects)):
        vaccine_obj = vaccine_objects.get(vac_pk, None)
        if not vaccine_obj:
            continue

        vaccine_glyc_sites = glyc.find_glycosylation_sites(vaccine_obj.ha.sequence)
        caches['vac-glyc-{}'.format(vac_pk)] = vaccine_glyc_sites
        count += 1
    return count


def run():
    output_basedir = "/app/limh25/databases/pairwise_ha_features"

    posmap_count = populate_posmap_cache()
    print("{} position maps cached.".format(posmap_count))
    v2r_count = populate_vaccine2reference_cache()
    print("{} Vaccine2Reference alignment cached.".format(v2r_count))
    egg_count = populate_eggadaptation_cache()
    print("{} Egg adaptation dict cached.".format(egg_count))
    vac_glyc_count = populate_vaccine_glyc_cache()
    print("{} vaccine glyc sites cached.".format(vac_glyc_count))


    for subtype in has_by_subtype:
        print("Processing {} subtype....".format(subtype))
        output_subtype_dir = os.path.join(output_basedir, subtype)
        os.makedirs(output_subtype_dir, exist_ok=True)
        
        inputs = []
        print("  Collecting inputs for multiprocessing...")
        for ha_accession in tqdm.tqdm(has_by_subtype[subtype], total=len(has_by_subtype[subtype])):
            subdir_name = ha_accession.lower().replace('epi','')[2:4]  # '31' from EPI423145
            subdir = os.path.join(output_subtype_dir, subdir_name)
            os.makedirs(subdir, exist_ok=True)
            for vac_pk in vaccine_has_by_subtype[subtype]:
                output_file = os.path.join(subdir, "{}_{}.json".format(vaccine_has_by_subtype[subtype][vac_pk].ha.accession, ha_accession))
                d = {
                    'subtype': subtype,
                    'input_ha_accession': ha_accession,
                    'pdb_id': subtype2pdbid.get(subtype, None),
                    'vaccine_pk': vac_pk,
                    'output_file': output_file,
                }
                inputs.append(d)
        print("  Extracting features into {}".format(output_subtype_dir))
        with mp.Pool(ncpus) as pool:
            for _ in tqdm.tqdm(pool.imap_unordered(collect_pairwise_features, inputs), total=len(inputs)):
                pass

