import os
import sys
import re
import json
import random
import tqdm
from proteins import utils
from django.conf import settings
from django.db.models import Count
from Bio import SeqIO, Seq
from Bio.Blast.Applications import NcbiblastpCommandline
from Bio.Blast import NCBIXML
from proteins import models as protein_models
from nucleotides import models as nucl_models
from annotations import models as annot_models

TYPES = ['original-egg', 'original-cell', 'original-mix', 'cell-egg', 'cell-mix', 'egg-mix']


def collect_passage_info():
    output_dir = os.path.join(settings.MEDIA_ROOT, "HA_MSA_output")
    hs = protein_models.Hemagglutinin.objects.all().order_by()

    output_file = os.path.join(output_dir, 'Isolate_information.csv')
    with open(output_file, 'w') as out:
        out.write('Isolate,HA,Lineage,Clade,Passage,CollectionDate\n')
        for h in tqdm.tqdm(hs, total=hs.count()):
            p = h.isolate.passage
            passage_class = ''
            if h.isolate.clade:
                clade_name = h.isolate.clade.full_name
            else:
                clade_name = 'Unassigned'
            if not p.is_passaged:
                passage_class = 'Original'
            elif (p.is_egg_passaged) and (not p.is_cell_passaged):
                passage_class = 'Egg'
            elif (not p.is_egg_passaged) and (p.is_cell_passaged):
                passage_class = 'Cell'
            else:
                passage_class = 'Mix'
            out.write('{},{},{},{},{},{}\n'.format(
                h.isolate.accession, h.accession, h.isolate.lineage.name, clade_name, passage_class, h.isolate.collection_date))


def populate_passage_adaptation_types():
    for t in TYPES:
        obj, _ = annot_models.PassageAdaptationType.objects.get_or_create(name=t)

def run():
    collect_passage_info()
    sys.exit()
    populate_passage_adaptation_types()
    adaption_type_objects = {t:annot_models.PassageAdaptationType.objects.filter(name=t).first() for t in TYPES}
    multi_passage_strains = protein_models.Isolate.objects.values('name').annotate(Count('id')).order_by().filter(id__count__gt=1)

    print("Start collecting for {} isolates".format(multi_passage_strains.count()))
    
    for ms in tqdm.tqdm(multi_passage_strains, total=len(multi_passage_strains)):
        isolates = protein_models.Isolate.objects.filter(name=ms['name'])
        ori_isolates = isolates.filter(passage__is_passaged=False)
        cell_isolates = isolates.filter(passage__is_cell_passaged=True).filter(passage__is_egg_passaged=False)
        egg_isolates = isolates.filter(passage__is_egg_passaged=True).filter(passage__is_cell_passaged=False)
        mix_isolates = isolates.filter(passage__is_egg_passaged=True).filter(passage__is_cell_passaged=True)

        for oi in ori_isolates:
            for ei in egg_isolates:
                obj, _ = annot_models.PairwisePassageAdaptation.objects.get_or_create(
                    adaptation_type=adaption_type_objects['original-egg'],
                    strain1=oi, strain2=ei
                )
            for ci in cell_isolates:
                obj, _ = annot_models.PairwisePassageAdaptation.objects.get_or_create(
                    adaptation_type=adaption_type_objects['original-cell'],
                    strain1=oi, strain2=ci
                )
            for mi in mix_isolates:
                obj, _ = annot_models.PairwisePassageAdaptation.objects.get_or_create(
                    adaptation_type=adaption_type_objects['original-mix'],
                    strain1=oi, strain2=mi
                )
        for ci in cell_isolates:
            for ei in egg_isolates:
                obj, _ = annot_models.PairwisePassageAdaptation.objects.get_or_create(
                    adaptation_type=adaption_type_objects['cell-egg'],
                    strain1=ci, strain2=ei
                )
            for mi in mix_isolates:
                obj, _ = annot_models.PairwisePassageAdaptation.objects.get_or_create(
                    adaptation_type=adaption_type_objects['cell-mix'],
                    strain1=ci, strain2=mi
                )
        for ei in egg_isolates:
            for mi in mix_isolates:
                obj, _ = annot_models.PairwisePassageAdaptation.objects.get_or_create(
                    adaptation_type=adaption_type_objects['egg-mix'],
                    strain1=ei, strain2=mi
                )
    print("Complete.")