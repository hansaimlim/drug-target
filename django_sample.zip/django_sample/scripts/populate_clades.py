import os
import re
import time
import numpy as np
import pandas as pd
import json
from datetime import datetime
from django.conf import settings
from proteins import utils
from proteins import models

def run():
    base_dir = "/app/limh25/flu/flu/media/nextclade/output"
    lineages = ['h1n1', 'h3n2', 'victoria', 'yamagata']

    count = {
        'updated': 0,
        'unassigned': 0,
        'skipped': 0,
    }

    for lin in lineages:
        clade_file = os.path.join(base_dir, "{}/nextclade.csv".format(lin))  # delimted by ';'

        with open(clade_file, 'r') as inf:
            header = next(inf)
            for line in inf:
                line = line.strip().split(';')
                isolate_id = line[0]
                clade = line[1].strip().lstrip()
                if clade.lower() in ['', 'unassigned']:
                    count['unassigned'] += 1
                    continue
                cs = clade.strip().split('.')

                clade_fullname_list = []

                for level, c in enumerate(cs):
                    clade_fullname_list.append(c)
                    clade_fullname = '.'.join(clade_fullname_list)
                    if level == 0:
                        clade_obj, _ = models.Clade.objects.get_or_create(
                            name=c, full_name=clade_fullname,
                            level=level,
                            # root clade; no parent clade
                            parent=None
                        )
                    else:
                        clade_obj, _ = models.Clade.objects.get_or_create(
                            name=c, full_name=clade_fullname,
                            level=level, parent=clade_obj  # use the previous clade_obj as parent
                        )
                isolate = models.Isolate.objects.filter(accession=isolate_id).first()
                if isolate:
                    isolate.clade = clade_obj
                    isolate.save()
                    count['updated'] += 1
                else:
                    count['skipped'] += 1
    
    print("Complete. Counts {}.".format(count))

