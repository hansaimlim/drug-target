import os
import numpy as np
import json
import pandas as pd
from Bio import SeqIO
from Bio.Align import substitution_matrices
from biotite.structure.io import pdb
from biotite import structure as bts
from django.conf import settings
from proteins import utils
from proteins import models
from proteins import structure_info as si
from proteins import sequence_alignment as sa
from proteins import protein_structure as ps
from proteins import epitopes


def populate_structures(reset=False):
    if reset:
        print("----populate_structures(reset=True). Will remove all existing PDBStructure objects and re-populate.")
        models.PDBStructure.objects.all().delete()

    print("  Start populating structures.")
    for pdb_id in si.STRUCTURE_INFO.keys():
        
        info = si.STRUCTURE_INFO[pdb_id]
        iso_subtype, _ = models.IsolateSubtype.objects.get_or_create(name=info['isolateSubtype'])
        mol_subtype, _ = models.MoleculeSubtype.objects.get_or_create(name=info['moleculeSubtype'])
        ref_ha_id = epitopes.get_epitope_reference_id(mol_subtype.name)
        ref_ha = models.Hemagglutinin.objects.filter(accession=ref_ha_id).first()
        epitope_dict = epitopes.get_epitope_dict_for_reference(mol_subtype.name)
        pdb_file = os.path.join(settings.PDB_STRUCTURE_DIR, "{}.pdb".format(pdb_id.lower()))


        chain_info = info['chain_info']
        segment_chains = [c for c in chain_info if chain_info[c]['segment']]
        pdb_obj = pdb.PDBFile.read(pdb_file)
        pdb_structure = pdb.get_structure(pdb_obj, model=1, altloc='occupancy')
        sasa_dicts = ps.compute_sasa(pdb_structure, probe_radius=1.4, point_number=1000, ignore_ions=True)
        alignments = {}
        all_residues = []  # {'chain_id':chain_id, 'res_id': res_id, 'res_name': res_name, 'com': center-of-mass}
        for chain in bts.chain_iter(pdb_structure):
            aa_filt = bts.filter_amino_acids(chain)
            chain = chain[aa_filt]
            if chain.shape[0] < 1:
                continue
            chain_id = chain[0].chain_id
            if chain_id not in segment_chains:
                # skip non-influenza chains, e.g. Fabs
                continue
            for r in bts.residue_iter(chain):
                all_residues.append(
                        {
                            'chain_id': r[0].chain_id,
                            'res_id':int(r[0].res_id), 
                            'res_name':r[0].res_name,
                            'com':ps.compute_center_of_mass_residue(r)
                        })
            res = bts.get_residues(chain)
            threes = res[1]
            res_num = res[0]
            chain_seq = ''.join([utils.three2one(three).upper() for three in threes])
            aln = sa.pairwise_align(ref_seq=ref_ha.sequence, query_seq=chain_seq, clean=True)
            d = {
                'chain_id'     : chain_id,
                'ref_aligned'  : aln['reference_aligned'],
                'ref_start'    : aln['reference_start'],
                'query_aligned': aln['query_aligned'],
                'query_start'  : aln['query_start'],
                'query_residue_numbers': res_num,
                'score'        : aln['score']
            }
            alignments[chain_id] = d

        epitope_map = sa.collect_epitope_map(alignments, epitope_dict)
        pair_pot_dict = ps.collect_residue_pair_potential(all_residues, com_dist_max=7.0, res_id_diff=4)
        # print(pair_pot_dict)

        structure_obj, created = models.PDBStructure.objects.get_or_create(
            pdb_id=pdb_id, isolate_subtype=iso_subtype, molecule_subtype=mol_subtype,
            description=info['description'],
            short_description=info['short_description'],
            chain_info=info['chain_info'],
            pdb_file=pdb_file,
            epitopes=epitope_map,
            sasa=sasa_dicts['sasa_dict'],
            pair_potential=pair_pot_dict,
            relative_sasa=sasa_dicts['rel_sasa_dict']
        )

        if created:
            print("    Created {}".format(structure_obj))

def popuate_structure_align_map():
    pdb_objects = models.PDBStructure.objects.all().order_by()
    count = 0
    for ref in models.ReferenceHemagglutinin.objects.all().order_by():
        ref_id = ref.ha.accession
        ref_seq = ref.full_sequence
        ref_name = ref.reference_name
        pdb_ids = si.REFERENCE_MATCH[ref_name]
        for pdb_id in pdb_ids:
            pdb_object = pdb_objects.filter(pdb_id=pdb_id).first()
            chain_info = pdb_object.chain_info
            segment_chains = [c for c in chain_info if chain_info[c]['segment']]
            pdb_obj = pdb.PDBFile.read(pdb_object.pdb_file)
            pdb_structure = pdb.get_structure(pdb_obj, model=1, altloc='occupancy')
            alignments = {}
            for chain in bts.chain_iter(pdb_structure):
                aa_filt = bts.filter_amino_acids(chain)
                chain = chain[aa_filt]
                if chain.shape[0] < 1:
                    continue
                num_res = bts.get_residue_count(chain)
                chain_id = chain[0].chain_id
                if chain_id not in segment_chains:
                    # skip non-influenza chains, e.g. Fabs
                    continue
                res = bts.get_residues(chain)
                threes = res[1]
                res_num = res[0]
                chain_seq = ''.join([utils.three2one(three).upper() for three in threes])
                aln = sa.pairwise_align(ref_seq=ref_seq, query_seq=chain_seq, clean=True)
                ref_aln = aln['reference_aligned']
                chain_aln = aln['query_aligned']
                score = aln['score']  # bitscore
                d = {
                    'ref_id': ref_id,
                    'query_pdb_id': pdb_id,
                    'chain_id': chain_id,
                    'ref_aligned': ref_aln,
                    'ref_start': aln['reference_start'],
                    'query_aligned': chain_aln,
                    'query_start': aln['query_start'],
                    'query_residue_numbers': res_num,  # 1-based residue indices in pdb file
                    'score': score,
                }
                alignments[chain_id] = d

            position_map = sa.collect_position_map(alignments)

            ref_str, created = models.ReferenceHemagglutininStructureAligned.objects.get_or_create(
                reference=ref, structure=pdb_object, position_map=position_map
            )
            if created:
                print("    Created alignment: {}".format(ref_str))
                count += 1
    
    print("Complete. Total {} ref-structure alignment objects created.".format(count))

def run():
    populate_structures(reset=True)  # run if there is any new pdb entry to add
    popuate_structure_align_map()