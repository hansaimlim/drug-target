from django.db import models
from django.core.validators import MinLengthValidator
from news_notifier.users.models import User
from django.conf import settings
# Create your models here.

class Source(models.Model):
    name = models.CharField(
        max_length=100, unique=True,
        help_text="source of google search results. e.g. Nature"
    )
    date_created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return "{}".format(self.name)

class GoogleNewsRawData(models.Model):
    """
    Contains raw data fetched from google news using SerpApi
    """
    link = models.URLField(
        max_length=1024, unique=True,
        help_text="link field from SerpApi result. max 300 characters; unique constraint"
    )
    title = models.CharField(
        max_length=500,
        help_text="title field from SerpApi result. max 300 characters."
    )
    source = models.ForeignKey(Source, on_delete=models.CASCADE)
    date = models.DateField(null=True, blank=True)  # date of the news
    snippet = models.CharField(
        max_length=1000,
        help_text="snippet field from SerpApi result. max 500 characters."
    )
    date_created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return "Source: {}. Title: {}".format(self.source.name, self.title)

class GoogleNewsVariantLabel(models.Model):
    """
    User-defined labels for each google news article
    True if the article is likely contain information about new emerging variants
    """
    sample = models.OneToOneField(GoogleNewsRawData, on_delete=models.CASCADE, primary_key=True)
    label = models.BooleanField(default=False)
    labeled_by = models.ForeignKey(User, null=True, blank=True, default=None, on_delete=models.CASCADE)

    def __str__(self):
        return "News: {}, VariantLabel: {}".format(
            self.sample.title, self.label
        )