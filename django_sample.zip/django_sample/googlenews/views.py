from django.contrib.messages.views import SuccessMessageMixin
from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic.base import TemplateView
from django.urls import reverse_lazy
from django.conf import settings
from django.template.defaulttags import register
from django.db.models import Sum, Count
from django.core.mail import send_mail
from django.utils import timezone
from django.contrib import messages
from django.utils.safestring import mark_safe
import os
import time
import datetime
import json
from collections import Counter
from googlenews import models
from googlenews import forms


class NewsListView(TemplateView):
    template_name = "googlenews/news_list.html"
    model = models.GoogleNewsRawData

    def get(self, request):
        form = forms.NewsSearchForm()
        ctx = {
            'form': form,
        }
        return render(request, self.template_name, ctx)


class UpdateNewsView(TemplateView):
    model = models.GoogleNewsRawData
    template_name = "googlenews/update_news.html"

    def get_obj(self, pk):
        return get_object_or_404(self.model, pk=pk)

    def get(self, request, pk=None):
        obj = self.get_obj(pk)
        newsForm = forms.NewsForm(instance=obj)
        ctx = {
            'object': obj,
            'pk': pk,
            'form': newsForm,
        }
        return render(request, self.template_name, ctx)
    
    def post(self, request, pk=None):
        obj = self.get_obj(pk)
        newsForm = forms.NewsForm(request.POST, instance=obj)
        if newsForm.is_valid():
            newsForm.save()
            messages.success(request, mark_safe("<strong>Updated news: {}</strong>".format(obj.title)))
            return redirect('googlenews:main')
        else:
            ctx = {
                'object': obj,
                'pk': pk,
                'form': newsForm,
            }
            messages.error(request, mark_safe("<strong>Form invalid</strong>"))
            return render(request, self.template_name, ctx)



class UpdateNewsLabelView(TemplateView):
    model = models.GoogleNewsRawData
    template_name = "googlenews/update_news_label.html"
    
    def get_news_obj(self, pk):
        return get_object_or_404(self.model, pk=pk)
    
    def get_news_label_obj(self, news_obj):
        return models.GoogleNewsVariantLabel.objects.filter(sample=news_obj)

    def create_news_label(self, news_obj, user, label=False):
        news_label_obj = models.GoogleNewsVariantLabel.objects.create(
            sample=news_obj, labeled_by=user, label=False)
        return news_label_obj

    def get(self, request, news_pk=None):
        news_obj = self.get_news_obj(news_pk)
        news_label_obj = self.get_news_label_obj(news_obj)
        
        if news_label_obj.count() == 0:
            # no label exists. create one
            news_label_obj = self.create_news_label(news_obj, request.user)
        else:
            news_label_obj = news_label_obj.first()
        
        newsLabelForm = forms.NewsLabelForm(instance=news_label_obj, initial={'labeled_by':request.user})
        ctx = {
            'news_obj': news_obj,
            'news_label_obj': news_label_obj,
            'form': newsLabelForm,
        }
        return render(request, self.template_name, ctx)

    def post(self, request, news_pk=None):
        news_obj = self.get_news_obj(news_pk)
        news_label_obj = self.get_news_label_obj(news_obj).first()
        newsLabelForm = forms.NewsLabelForm(request.POST, instance=news_label_obj)
        if newsLabelForm.is_valid():
            newsLabelForm.save()
            messages.success(request, mark_safe("<strong>Updated news label: {}</strong>".format(news_obj.title)))
            return redirect('googlenews:main')
        else:
            print(newsLabelForm.errors)
            newsLabelForm = forms.NewsLabelForm(request.POST, instance=news_label_obj, initial={'labeled_by':request.user})
            ctx = {
                'news_obj': news_obj,
                'news_label_obj': news_label_obj,
                'form': newsLabelForm,
            }
            messages.error(request, mark_safe("<strong>Form invalid</strong>"))
            return render(request, self.template_name, ctx)
