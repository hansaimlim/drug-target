from __future__ import absolute_import, unicode_literals
import re
from celery import shared_task
from datetime import datetime, date, timedelta
from dateutil.relativedelta import relativedelta
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver
from googlenews import models
from googlenews import newspicker
from googlenews.email import send_email_message
from googlenews.serpapi import collect_news

@receiver(post_save, sender=models.GoogleNewsRawData)
def create_label(sender, instance, created, **kwargs):
    keywords = settings.NEW_VARIANT_KEYWORDS
    if created:
        picked = newspicker.keyword_based_picker(instance.title, instance.snippet)
        lab_obj = models.GoogleNewsVariantLabel.objects.create(
            sample=instance, label=picked, labeled_by=None
        )

@shared_task(name='collect_googlenews')
def collect_googlenews():
    """
    Collect daily SARS-CoV-2 google news and send email report
    """
    query = "SARS-CoV-2"
    now = datetime.now()
    news = collect_news(query)
    created = {
        'source': 0,
        'news': 0,
    }
    selected_news = {}
    pattern = "(\d+)\s+(\D+)\s+(\D+)$"  # to capture "2 days ago", etc
    for n in news:
        link = n['link']
        title = n['title']
        source = n['source']
        date_ = n['date']  # date is often inexact, like 5 weeks ago; 2 months ago, etc
        m = re.search(pattern, date_)
        if m is None:
            try:
                article_date = datetime.strptime(date_, "%b %d, %Y")
            except:
                print("Article date provided in unknown format. given:{}".format(date_))
                article_date = None
        else:
            if m[3].lower() == 'ago':
                increment = int(m[1])
                unit = m[2].lower()
                if unit in ['min', 'minutes', 'mins']:
                    article_date = now - timedelta(minutes=increment)
                elif unit in ['hour', 'hours', 'hrs']:
                    article_date = now - timedelta(hours=increment)
                elif unit in ['day', 'days']:
                    article_date = now - timedelta(days=increment)
                elif unit in ['week', 'weeks']:
                    article_date = now - timedelta(weeks=increment)
                elif unit in ['month', 'months']:
                    article_date = now - relativedelta(months=increment)
                else:
                    print("Cannot convert article date format. given:{}".format(date_))
                    article_date = None
            else:
                print("Cannot convert article date format. given:{}".format(date_))
                article_date = None

        snippet = n['snippet']

        source_obj, source_created = models.Source.objects.get_or_create(name=source)
        if source_created:
            created['source'] += 1
        news_obj = models.GoogleNewsRawData.objects.filter(link=link)
        if news_obj.count() == 0:
            # news not found by the link
            news_obj = models.GoogleNewsRawData.objects.create(
                link=link, title=title, source=source_obj, snippet=snippet, date=article_date
            )
            created['news'] += 1

            # newly collected news. check if keywords present
            picked = newspicker.keyword_based_picker(title, snippet)
            if picked:
                selected_news[link] = {
                    'link': link,
                    'title': title,
                    'source': source,
                    'date': date_,
                    'snippet': snippet,
                }
    
    
    if len(selected_news) > 0:
        selected_news_string = ''
        for link in selected_news:
            news = selected_news[link]
            selected_news_string += "Title: {}\nSource: {}\nDate: {}\nLink: {}\nSnippet: {}\n\n".format(
                news['title'], news['source'], news['date'], news['link'], news['snippet']
            )
    else:
        selected_news_string = "We detected no news matching the variant keywords.\n"

    send_email_message(
        subject="Daily Google News Updates", 
        email_body="Collected {} news from {} sources\n{} articles matching the variant keywords are shown below.\n\n{}".format(created['news'], created['source'], len(selected_news), selected_news_string), 
        recipients=settings.GOOGLE_NEWS_RECIPIENTS
    )
