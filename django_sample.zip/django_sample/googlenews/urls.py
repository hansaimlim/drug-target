from django.urls import path, reverse_lazy
from googlenews import views
from googlenews import ajax_datatable_views
from django.views.generic import TemplateView

app_name = 'googlenews'
urlpatterns = [
    path('', views.NewsListView.as_view(), name='main'),
    path('ajax_datatable/news_list/', ajax_datatable_views.NewsListView.as_view(), name='ajax_datatable_news_list'),

    path('edit_news/<int:pk>/', views.UpdateNewsView.as_view(), name='edit_news'),
    path('edit_news_label/<int:news_pk>/', views.UpdateNewsLabelView.as_view(), name='edit_news_label'),
]