from django.conf import settings
from serpapi import GoogleSearch

def collect_news(query):
    search = GoogleSearch({
        "q": "{query}".format(query=query), 
        "hl": "en",
        "gl": "us",
        "google_domain": "google.com",
        "tbm": "nws",
        "tbs": "cdr:2",
        "num": "100",
        "api_key": settings.SERPAPI_KEY
      })
    result = search.get_dict()
    news_results = result['news_results']
    return news_results
