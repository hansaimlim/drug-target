from django.conf import settings

def keyword_based_picker(title, snippet):
    keywords = settings.NEW_VARIANT_KEYWORDS

    total_points = 0
    for kw in keywords:
        if kw.lower() in title.lower():
            total_points += settings.KEYWORD_IN_TITLE_POINT
        if kw.lower() in snippet.lower():
            total_points += settings.KEYWORD_IN_SNIPPET_POINT
    if total_points >= settings.GOOGLENEWS_MIN_POINTS:
        label = True
    else:
        label = False
    return label
