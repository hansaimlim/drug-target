from django.contrib.messages.views import SuccessMessageMixin
from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic import ListView
from django.views.generic.base import TemplateView
from django.core.paginator import Paginator
from django.urls import reverse_lazy
from django.conf import settings
from django.template.defaulttags import register
from django.template.loader import render_to_string
from django.db.models import Sum, Count, Q, OuterRef, Subquery
from django.core.mail import send_mail
from django.utils import timezone
from ajax_datatable.views import AjaxDatatableView
import os
import requests
import time
import datetime
import json
from googlenews import forms
from googlenews import models

"""
column_defs = [{
    'name': 'currency',                 # required
    'data': None,
    'title': 'Currency',                # optional: default = field verbose_name or column name
    'visible': True,                    # optional: default = True
    'searchable': True,                 # optional: default = True if visible, False otherwise
    'orderable': True,                  # optional: default = True if visible, False otherwise
    'foreign_field': 'manager__name',   # optional: follow relation
    'm2m_foreign_field': 'manager__name',   # optional: follow m2m relation
    'placeholder': False,               # ???
    'className': 'css-class-currency',  # optional class name for cell
    'defaultContent': '<h1>test</h1>',  # ???
    'width': 300,                       # optional: controls the minimum with of each single column
    'choices': None,                    # see `Filtering single columns` below
    'initialSearchValue': None,         # see `Filtering single columns` below
    'autofilter': False,                # see `Filtering single columns` below
    'boolean': False,                   # treat calculated column as BooleanField
    'max_length': 0,                    # if > 0, clip result longer then max_length
    'lookup_field': '__icontains',      # used for searches; default: '__iexact' for columns with choices, '__icontains' in all other cases
}
"""

class NewsListView(AjaxDatatableView):
    model = models.GoogleNewsVariantLabel
    title = "Google News List"
    initial_order = [
        ["date", "desc"],
    ]
    length_menu = [
        [20, 50, 100], [20, 50, 100],
    ]
    search_values_separator = '+'

    column_defs = [
        {'name': 'id', 'visible': False, 'searchable': False, 'orderable': True},
        {'name': 'title', 'title': 'Title', 'visible': True, 'searchable': False, 'orderable': True, 'placeholder': True},
        {'name': 'source', 'title': 'Source', 'visible': False, 'searchable': False, 'orderable': True, 'foreign_field': 'sample__source__name'},
        {'name': 'date', 'title': 'Date', 'visible':True, 'searchable': False, 'orderable': True, 'foreign_field': 'sample__date'},
        {'name': 'link', 'title': 'Article', 'visible':True, 'searchable': False, 'orderable': False, 'placeholder': True},
        {'name': 'snippet', 'title': 'Snippet', 'visible': False, 'searchable': False, 'orderable': False, 'foreign_field':'sample__snippet'},
        {'name': 'label', 'title': 'Is variant news', 'visible': True, 'searchable': False, 'orderable': True, 'placeholder': True},
        {'name': 'edit_news', 'title': 'Edit News', 'visible': True, 'searchable': False, 'orderable': False, 'placeholder': True},
        {'name': 'edit_label', 'title': 'Edit Label', 'visible': True, 'searchable': False, 'orderable': False, 'placeholder': True},
    ]

    def get_initial_queryset(self, request=None):
        queryset = self.model.objects.all().order_by()
        keyword = request.POST.get('keyword')
        if keyword is not None:
            keyword = keyword.strip()
            queryset = queryset.filter(
                Q(sample__title__icontains=keyword)|
                Q(sample__snippet__icontains=keyword)
            )
        source = request.POST.get('source')
        label = request.POST.get('label')

        if source != '':
            queryset = queryset.filter(sample__source__name=source)
        if label.lower() == 'true':
            queryset = queryset.filter(label=True)
        elif label.lower() == 'false':
            queryset = queryset.filter(label=False)
        else:
            queryset = queryset

        return queryset

    def customize_row(self, row, obj):

        article_title = obj.sample.title
        title_max_chars = 90
        if len(article_title) > title_max_chars:
            row['title'] = "{}...".format(article_title[:title_max_chars])
        else:
            row['title'] = "{}".format(article_title)

        edit_news_url = reverse_lazy('googlenews:edit_news', kwargs={'pk': obj.sample.pk})
        edit_label_url = reverse_lazy('googlenews:edit_news_label', kwargs={'news_pk': obj.sample.pk})
        row['link'] = """<a href="{}" class="btn btn-sm btn-info">Show</a>""".format(obj.sample.link)
        row['edit_news'] = """<a href="{}" class="btn btn-sm btn-info">Edit</a>""".format(edit_news_url)
        row['edit_label'] = """<a href="{}" class="btn btn-sm btn-primary">Edit Label</a>""".format(edit_label_url)

        if obj.label:
            # True variant news
            row['label'] = '<span class="btn btn-sm btn-success">{}</span>'.format(obj.label)
        else:
            row['label'] = '<span class="btn btn-sm btn-danger">{}</span>'.format(obj.label)

        return
