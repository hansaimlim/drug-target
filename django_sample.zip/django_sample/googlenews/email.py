from django.conf import settings
from django.core.mail import send_mail

def send_email_message(
    subject="Email title", 
    email_body=f'This is a test email from Django app', 
    recipients=["hansaim.lim@pfizer.com"]):

    send_mail(
        subject,
        email_body,
        settings.EMAIL_HOST_USER,
        recipients
    )

def send_receipt_message(recipients):
    subject = settings.EMAIL_SUBJECT_PREFIX + " Your email was received. (do not reply)"
    email_body = f'This is automated message to confirm that your message was successfully sent. We will respond to the issue as soon as possible.'
    send_mail(
        subject,
        email_body,
        settings.EMAIL_HOST_USER,
        recipients
    )

def send_user_message(sender, subject, message):
    send_mail(
        settings.EMAIL_SUBJECT_PREFIX + ' ' + subject,
        message+'\n\nFrom: {}'.format(sender),
        settings.EMAIL_HOST_USER,
        [settings.EMAIL_HOST_USER]
    )