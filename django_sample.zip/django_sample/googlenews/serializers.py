from rest_framework import serializers
from . import models

class GoogleNewsSerializer(serializers.ModelSerializer):
    class Meta:
        model = models.GoogleNewsRawData
        fields = '__all__'
