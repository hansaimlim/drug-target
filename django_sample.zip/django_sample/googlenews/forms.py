import magic
from django import forms
from django.core.exceptions import ValidationError
from django.core import validators
from django.conf import settings
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Field, Layout, Submit, Row, Column
from django.utils.deconstruct import deconstructible
from django.utils.translation import gettext_lazy as _
from django.template.defaultfilters import filesizeformat
from googlenews import models
from django.forms import ModelForm
import datetime
from bootstrap_datepicker_plus.widgets import DatePickerInput, TimePickerInput, DateTimePickerInput, MonthPickerInput, YearPickerInput

class NewsLabelForm(ModelForm):
    class Meta:
        model = models.GoogleNewsVariantLabel
        fields = [
            'sample',
            'label',
            'labeled_by'
        ]

        widgets = {
            'label': forms.CheckboxInput(),
        }

    def __init__(self, *args, **kwargs):
        super(NewsLabelForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.fields['sample'].disabled = True
        self.fields['labeled_by'].disabled = True


class NewsForm(ModelForm):
    class Meta:
        model = models.GoogleNewsRawData
        fields = [
            'link',
            'title',
            'source',
            'date',
            'snippet',
        ]
        widgets = {
            'date': DatePickerInput(
                options={
                    'minDate': (datetime.datetime.today()-datetime.timedelta(days=800)).strftime('%Y-%m-%d 00:00:00'),
                    'maxDate': (datetime.datetime.today()+datetime.timedelta(days=2)).strftime('%Y-%m-%d 23:59:59'),
                    'defaultDate': False,
                }
            ),
        }

class NewsSearchForm(forms.Form):
    keyword = forms.CharField(
        max_length=200,
        required=False,
        help_text="Keyword in title or abstract",
        validators=[
            validators.MinLengthValidator(4, "Please provide longer keyword (min 4 characters)."),
            validators.MaxLengthValidator(200, "Please provide keywords no longer than 200 characters.")
        ]
    )
    source = forms.ModelChoiceField(
        queryset=models.Source.objects.all().order_by(),
        to_field_name='name',
        required=False,
        empty_label='All'
    )
    labelChoices = [
        ('all', 'All'),
        ('true', 'True'),
        ('false', 'False'),
    ]
    label = forms.ChoiceField(
        choices=labelChoices,
        required=False,
        help_text="is relevant to new/emerging variants?"
    )

    def __init__(self, *args, **kwargs):
        super(NewsSearchForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.fields['keyword'].label = False
        self.fields['source'].label = False
        self.fields['label'].label = False