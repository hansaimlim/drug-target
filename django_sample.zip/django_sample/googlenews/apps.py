from django.apps import AppConfig


class GooglenewsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'googlenews'
