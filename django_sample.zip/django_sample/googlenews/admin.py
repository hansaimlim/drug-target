from django.contrib import admin
from googlenews import models
# Register your models here.
admin.site.register(models.Source)
admin.site.register(models.GoogleNewsRawData)
admin.site.register(models.GoogleNewsVariantLabel)