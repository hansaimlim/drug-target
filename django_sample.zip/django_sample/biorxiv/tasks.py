from __future__ import absolute_import, unicode_literals
from celery import shared_task
from datetime import datetime, date, timedelta
from django.conf import settings
from django.db.models.signals import post_save
from django.dispatch import receiver
import requests
from biorxiv import models
from googlenews.email import send_email_message

@receiver(post_save, sender=models.Article)
def create_label(sender, instance, created, **kwargs):
    keywords = settings.NEW_VARIANT_KEYWORDS
    if created:
        # create article label obj
        kw_point = 0
        for kw in keywords:
            if kw in instance.title.lower():
                kw_point += settings.KEYWORD_IN_TITLE_POINT
            if kw in instance.abstract.lower():
                kw_point += settings.KEYWORD_IN_SNIPPET_POINT
        if kw_point >= settings.BIORXIV_MIN_POINTS:
            label = True
        else:
            label = False
        lab_obj = models.ArticleVariantLabel.objects.create(
            article=instance, label=label, 
            labeled_by=None  # initial labeler is None
        )

@shared_task(name='collect_biorxiv')
def collect_biorxiv():
    base_url = "https://api.biorxiv.org/covid19/{}/json"
    cur = 0
    increment = 30
    max_count = 99999999 # update after first fetch

    while cur < max_count:
        data = requests.get(url=base_url.format(cur))
        data = data.json()
        msg = data['messages'][0]
        max_count = msg['total']
        cur += increment
        count = 0

        for d in data['collection']:
            if ('rel_doi' not in d) or ('rel_title' not in d) or ('rel_abs' not in d) or ('rel_link' not in d):
                continue
            if 'rel_date' not in d:
                date = None
            else:
                try:
                    date = datetime.strptime(d['rel_date'], "%Y-%m-%d")
                except:
                    date = None
            if 'rel_site' not in d:
                site = None
            else:
                site = d['rel_site']
            if 'category' not in d:
                category = None
            else:
                category = d['category']
            doi = d['rel_doi']
            title = d['rel_title']
            link = d['rel_link']
            abstract = d['rel_abs']

            article_obj = models.Article.objects.filter(doi=doi)
            if article_obj.count() == 0:
                if category:
                    cat_obj, _ = models.Category.objects.get_or_create(name=category)
                if site:
                    site_obj, _ = models.Site.objects.get_or_create(name=site)
                # create article obj
                article_obj = models.Article.objects.create(
                    doi=doi, title=title,
                    date=date, category=cat_obj, site=site_obj,
                    abstract=abstract, link=link
                )
                count += 1


@shared_task(name='notify_biorxiv')
def notify_biorxiv():
    now = datetime.now()
    n_days = 7
    min_date = now - timedelta(days=n_days)
    positives = models.ArticleVariantLabel.objects.all().filter(label=True).filter(article__date__isnull=False)
    recent_positives = positives.filter(article__date__gte=min_date)

    selected_article_string = ''

    if recent_positives.count() == 0:
        send_email_message(
            "No bioRxiv article matched variant keywords.",
            email_body="We found no bioRxiv article matching the variant keywords in the past {} days.".format(n_days),
            recipients=settings.BIORXIV_RECIPIENTS
        )
    else:
        for lab in recent_positives:
            a = lab.article
            selected_article_string += "Title: {}\nDate: {}\nDOI: {}\nLink: {}\nAbstract: {}\n\n".format(
                a.title, a.date, a.doi, a.link, a.abstract
            )
        send_email_message(
            "{} bioRxiv article(s) matched variant keywords.".format(recent_positives.count()),
            email_body="We found {} bioRxiv article(s) matching the variant keywords in the past {} days.\n\n{}".format(
                recent_positives.count(), n_days, selected_article_string),
            recipients=settings.BIORXIV_RECIPIENTS
        )
