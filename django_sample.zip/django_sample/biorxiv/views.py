from django.contrib.messages.views import SuccessMessageMixin
from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic.base import TemplateView
from django.urls import reverse_lazy
from django.conf import settings
from django.template.defaulttags import register
from django.db.models import Sum, Count
from django.core.mail import send_mail
from django.utils import timezone
from django.contrib import messages
from django.utils.safestring import mark_safe
import os
import time
import datetime
import json
from collections import Counter
from biorxiv import models
from biorxiv import forms

# Create your views here.

class ArticleListView(TemplateView):
    template_name = "biorxiv/article_list.html"
    model = models.Article

    def get(self, request):
        form = forms.ArticleSearchForm()
        ctx = {
            'form': form,
        }
        return render(request, self.template_name, ctx)

class UpdateArticleView(TemplateView):
    model = models.Article
    template_name = "biorxiv/update_article.html"

    def get_obj(self, pk):
        return get_object_or_404(self.model, pk=pk)

    def get(self, request, pk=None):
        obj = self.get_obj(pk)
        articleForm = forms.ArticleForm(instance=obj)
        ctx = {
            'object': obj,
            'pk': pk,
            'form': articleForm,
        }
        return render(request, self.template_name, ctx)

    def post(self, request, pk=None):
        obj = self.get_obj(pk)
        articleForm = forms.ArticleForm(request.POST, instance=obj)
        if articleForm.is_valid():
            articleForm.save()
            messages.success(request, mark_safe("<strong>Updated article: {}</strong>".format(obj.title)))
            return redirect('biorxiv:main')
        else:
            ctx = {
                'object': obj,
                'pk': pk,
                'form': articleForm,
            }
            messages.error(request, mark_safe("<strong>Form invalid</strong>"))
            return render(request, self.template_name, ctx)


class UpdateArticleLabelView(TemplateView):
    model = models.Article
    template_name = "biorxiv/update_article_label.html"

    def get_article_obj(self, pk):
        return get_object_or_404(self.model, pk=pk)

    def get_article_label_obj(self, article_obj):
        return models.ArticleVariantLabel.objects.filter(article=article_obj)

    def create_new_label(self, article_obj, user, label=False):
        article_label_obj = models.ArticleVariantLabel.objects.create(
            article=article_obj, labeled_by=user, label=label
        )
        return article_label_obj

    def get(self, request, article_pk=None):
        article_obj = self.get_article_obj(article_pk)
        article_label_obj = self.get_article_label_obj(article_obj)

        if article_label_obj.count() == 0:
            article_label_obj = self.create_new_label(article_obj, request.user)
        else:
            article_label_obj = article_label_obj.first()

        articleLabelForm = forms.ArticleLabelForm(instance=article_label_obj, initial={'labeled_by':request.user})

        ctx = {
            'article_obj': article_obj,
            'article_label_obj': article_label_obj,
            'form': articleLabelForm,
        }

        return render(request, self.template_name, ctx)

    def post(self, request, article_pk=None):
        article_obj = self.get_article_obj(article_pk)
        article_label_obj = self.get_article_label_obj(article_obj).first()
        articleLabelForm = forms.ArticleLabelForm(request.POST or None, instance=article_label_obj)

        if articleLabelForm.is_valid():
            articleLabelForm.save()
            messages.success(request, mark_safe("<strong>Updated article label: {}</strong>".format(article_obj.title)))
            return redirect("biorxiv:main")
        else:
            print(articleLabelForm.errors)
            articleLabelForm = forms.ArticleLabelForm(instance=article_label_obj, initial={'labeled_by':request.user})
            ctx = {
                'article_obj': article_obj,
                'article_label_obj': article_label_obj,
                'form': articleLabelForm,
            }
            messages.error(request, mark_safe("<strong>Form invalid</strong>"))
            return render(request, self.template_name, ctx)
    
