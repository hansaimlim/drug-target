from django.db import models
from django.core.validators import MinLengthValidator
from news_notifier.users.models import User
from django.conf import settings


class Category(models.Model):
    name = models.CharField(
        max_length=100, unique=True,
        help_text="publication category. e.g. infectious diseases"
    )

    def __str__(self):
        return "{}".format(self.name)

class Site(models.Model):
    name = models.CharField(
        max_length=100, unique=True,
        help_text="publication site. e.g. medRxiv"
    )

    def __str__(self):
        return "{}".format(self.name)

class Article(models.Model):
    """
    Articles in bioRxiv
    """
    doi = models.CharField(
        max_length=500, unique=True,
        help_text="Unique identifier for bioRxiv articles. e.g. 10.1101/2022.09.29.22280522"
    )
    title = models.CharField(
        max_length=500,
        help_text="Article title."
    )
    date = models.DateField(null=True, blank=True)
    category = models.ForeignKey(Category, null=True, blank=True, on_delete=models.CASCADE)
    site = models.ForeignKey(Site, null=True, blank=True, on_delete=models.CASCADE)
    abstract = models.TextField()
    link = models.URLField(max_length=1024, help_text="Link to full-text article.")

    def __str__(self):
        return "{}".format(self.title)


class ArticleVariantLabel(models.Model):
    article = models.OneToOneField(Article, on_delete=models.CASCADE, primary_key=True)
    label = models.BooleanField(default=False)
    labeled_by = models.ForeignKey(User, null=True, blank=True, default=None, on_delete=models.CASCADE)

    def __str__(self):
        return "Article: {}, Label: {}".format(self.article, self.label)