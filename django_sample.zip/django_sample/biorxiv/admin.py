from django.contrib import admin
from biorxiv import models

# Register your models here.
admin.site.register(models.Category)
admin.site.register(models.Site)
admin.site.register(models.Article)
admin.site.register(models.ArticleVariantLabel)