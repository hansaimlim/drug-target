from django.urls import path, reverse_lazy
from biorxiv import views
from biorxiv import ajax_datatable_views
from django.views.generic import TemplateView

app_name = 'biorxiv'
urlpatterns = [
    path('', views.ArticleListView.as_view(), name='main'),
    path('ajax_datatable/article_list/', ajax_datatable_views.ArticleListView.as_view(), name='ajax_datatable_article_list'),

    path('edit_article/<int:pk>/', views.UpdateArticleView.as_view(), name='edit_article'),
    path('edit_article_label/<int:article_pk>/', views.UpdateArticleLabelView.as_view(), name='edit_article_label'),
]