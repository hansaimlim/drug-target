from django.contrib.messages.views import SuccessMessageMixin
from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic import ListView
from django.views.generic.base import TemplateView
from django.core.paginator import Paginator
from django.urls import reverse_lazy
from django.conf import settings
from django.template.defaulttags import register
from django.template.loader import render_to_string
from django.db.models import Sum, Count, Q
from django.core.mail import send_mail
from django.utils import timezone
from ajax_datatable.views import AjaxDatatableView
import os
import requests
import time
import datetime
import json
from biorxiv import forms
from biorxiv import models

"""
column_defs = [{
    'name': 'currency',                 # required
    'data': None,
    'title': 'Currency',                # optional: default = field verbose_name or column name
    'visible': True,                    # optional: default = True
    'searchable': True,                 # optional: default = True if visible, False otherwise
    'orderable': True,                  # optional: default = True if visible, False otherwise
    'foreign_field': 'manager__name',   # optional: follow relation
    'm2m_foreign_field': 'manager__name',   # optional: follow m2m relation
    'placeholder': False,               # ???
    'className': 'css-class-currency',  # optional class name for cell
    'defaultContent': '<h1>test</h1>',  # ???
    'width': 300,                       # optional: controls the minimum with of each single column
    'choices': None,                    # see `Filtering single columns` below
    'initialSearchValue': None,         # see `Filtering single columns` below
    'autofilter': False,                # see `Filtering single columns` below
    'boolean': False,                   # treat calculated column as BooleanField
    'max_length': 0,                    # if > 0, clip result longer then max_length
    'lookup_field': '__icontains',      # used for searches; default: '__iexact' for columns with choices, '__icontains' in all other cases
}
"""

class ArticleListView(AjaxDatatableView):
    model = models.ArticleVariantLabel
    title = "bioRxiv preprint list"
    initial_order = [
        ["date", "desc"],
    ]
    length_menu = [
        [20, 50, 100], [20, 50, 100],
    ]
    search_values_separator = '+'

    column_defs = [
        {'name': 'id', 'visible': False, 'searchable': False, 'orderable': True},
        {'name': 'title', 'title': 'Title', 'visible': True, 'searchable': False, 'orderable': True, 'placeholder': True},
        {'name': 'doi', 'title': 'DOI', 'visible': False, 'searchable': False, 'orderable': True, 'foreign_field': 'article__doi'},
        {'name': 'date', 'title': 'Date', 'visible':True, 'searchable': False, 'orderable': True, 'foreign_field': 'article__date'},
        {'name': 'link', 'title': 'Article', 'visible':True, 'searchable': False, 'orderable': False, 'placeholder': True},
        {'name': 'abstract', 'title': 'Abstract', 'visible': False, 'searchable': False, 'orderable': False, 'placeholder': True},
        {'name': 'label', 'title': 'Is variant article', 'visible': True, 'searchable': False, 'orderable': True, 'placeholder':True},
        {'name': 'edit_article', 'title': 'Edit Article', 'visible': True, 'searchable': False, 'orderable': False, 'placeholder': True},
        {'name': 'edit_label', 'title': 'Edit Label', 'visible': True, 'searchable': False, 'orderable': False, 'placeholder': True},
    ]

    def get_initial_queryset(self, request=None):

        queryset = self.model.objects.all().order_by()
        keyword = request.POST.get('keyword')
        if keyword is not None:
            keyword = keyword.strip()
            queryset = queryset.filter(
                Q(article__title__icontains=keyword)|
                Q(article__abstract__icontains=keyword)
            )
        category = request.POST.get('category')
        site = request.POST.get('site')
        label = request.POST.get('label')

        if category != '':
            queryset = queryset.filter(article__category__name=category)
        if site != '':
            queryset = queryset.filter(article__site__name=site)
        if label.lower() == 'true':
            queryset = queryset.filter(label=True)
        elif label.lower() == 'false':
            queryset = queryset.filter(label=False)
        else:
            queryset = queryset

        return queryset

    def customize_row(self, row, obj):

        article_title = obj.article.title
        title_max_chars = 90
        if len(article_title) > title_max_chars:
            row['title'] = "{}...".format(article_title[:title_max_chars])
        else:
            row['title'] = "{}".format(article_title)

        edit_article_url = reverse_lazy('biorxiv:edit_article', kwargs={'pk': obj.article.pk})
        edit_label_url = reverse_lazy('biorxiv:edit_article_label', kwargs={'article_pk': obj.article.pk})
        row['link'] = """<a href="{}" class="btn btn-sm btn-info">Show</a>""".format(obj.article.link)
        row['edit_article'] = """<a href="{}" class="btn btn-sm btn-info">Edit</a>""".format(edit_article_url)
        row['edit_label'] = """<a href="{}" class="btn btn-sm btn-primary">Edit Label</a>""".format(edit_label_url)

        if obj.label:
            # True variant news
            row['label'] = '<span class="btn btn-sm btn-success">{}</span>'.format(obj.label)
        else:
            row['label'] = '<span class="btn btn-sm btn-danger">{}</span>'.format(obj.label)

        return