from django.contrib.messages.views import SuccessMessageMixin
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse_lazy
from django.conf import settings
from django.template.defaulttags import register
from django.db.models import Sum, Count
from django.http.response import HttpResponse
from django.http import HttpResponseRedirect
from django.contrib import messages
from django.utils.safestring import mark_safe
import os
import time
import json
import csv
from proteins import models
from proteins import forms
from nucleotides import models as nucl_models

# Create your views here.

def subtype_changed(request):
    ctx = {}
    if 'subtype' in request.POST:
        subtype = request.POST.get('subtype', [''])
        ctx['pdb_filter_success'] = True
        ctx['pdb_structures_to_display'] = [{'value':obj.pk,'name':str(obj)} for obj in models.PDBStructure.objects.filter(molecule_subtype__name__iexact=subtype).order_by().distinct()]
    else:
        ctx['pdb_filter_success'] = True
        ctx['pdb_structures_to_display'] = [{'value':obj.pk,'name':str(obj)} for obj in models.PDBStructure.objects.all().order_by().distinct()]
    return HttpResponse(json.dumps(ctx), content_type="application/json")


def isolate_id_changed(request):
    ctx = {}
    if 'isolate_id' in request.POST:
        isolate_id = request.POST['isolate_id'].strip().lstrip()
        ha_subtype = None
        # detect the id format
        if isolate_id.upper().startswith('EPI'):
            # either isolate id or molecule id
            if isolate_id.upper().startswith('EPI_ISL'):
                # id is isolate-level
                ha = models.Hemagglutinin.objects.filter(isolate__accession__iexact=isolate_id).first()
                if ha:
                    ha_subtype = ha.subtype or None
            else:
                # id is molecule-level
                ha = models.Hemagglutinin.objects.filter(accession__iexact=isolate_id).first()
                if ha:
                    ha_subtype = ha.subtype or None
        else:
            # id is strain name
            ha = models.Hemagglutinin.objects.filter(isolate__name__iexact=isolate_id).first()
            if ha:
                ha_subtype = ha.subtype or None

        if ha_subtype:
            # filter structure ids
            ctx['ha_filter_success'] = True
            ctx['ha_subtype'] = ha_subtype.name
            ctx['pdb_structures_to_display'] = [{'value':obj.pk,'name':str(obj)} for obj in models.PDBStructure.objects.filter(molecule_subtype=ha_subtype).order_by().distinct()]
            ctx['vaccines_to_display'] = [{'value':obj.pk,'name':str(obj)} for obj in models.VaccineHemagglutinin.objects.filter(ha__subtype=ha_subtype).order_by('-latest_vaccine_year').distinct()]
        else:
            # filter not successful
            ctx['ha_filter_success'] = False
            ctx['ha_subtype'] = 'Unknown'
            ctx['pdb_structures_to_display'] = None
            ctx['vaccines_to_display'] = None

    return HttpResponse(json.dumps(ctx), content_type="application/json")
