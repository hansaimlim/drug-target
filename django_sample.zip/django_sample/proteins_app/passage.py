import os
import re
import numpy as np
import pandas as pd
import json

NO_PASSAGE_KEYWORDS = [
    # if passage.lower() contains one of these,
    # assume the sample is not passaged
    'orig', 'riginal', 'no passage', 'not passaged',
    'clinical', 'diagnostic', 'nasopharyngeal'
]
NO_PASSAGE_EXACT_WORDS = [
    # if passage.lower() exactly matches one of these,
    # assume the sample is not passaged
    'ori', 'or', 'org', 'direct', 'zero', 'primary', 'swab',
    'organ sample', 'initial', 'otiginal', 'orginial',
    'orginal', 'organ',
]
EGG_PASSAGE_KEYWORDS = [
    # if passage.lower() contains one of these,
    # assume the sample is egg-passaged
    'embryo', 'egg', 'allantoic', 'amniotic',
]
UNKNOWN_PASSAGE_KEYWORDS = [
    # passage names that can be wrongly translated to others
    # thus, search for these keywords before pattern-matching
    'SPFCK', 'C2hCK', 'autopsy',
    'NC4E', 'QMC',
    'tissue', 'brain', 'type', 'yamagata', 'victoria',
    'CaCo', 'mouse', 'adapted',
]
UNKNOWN_PASSAGE_EXACT_WORDS = [
    'pi', 'cs', 'sv', '2p', 'ex', 'a1',
]

EGG_PATTERNS = [
    r'([EЕ])(\d+)',
    r'(EЕ)\s+(\d+)',
    r'(\d+CE)[\-\s]?(\d+)dpi',
    r'(CE)(\d+)',
    r'(Egg)\s*(\d*)',
    r'(AM)\s*(\d*)'
]
SIAT_PATTERNS = [
    r'(SIAT)\s*(\d*)',
    r'(S)\s*(\d*)',
]
MDCK_PATTERNS = [
    r'(MDCK)\s*(\d*)',
    r'(МDСК)\s*(\d*)',
    r'(M)\s*(d*)',
    r'(MDCK CELL).*(\d*)',
    r'(Madin[\s\-]*Darby\s*canine\s*kidney)\s*'
]
RHMK_PATTERNS = [
    r'([PRH]+MK)\s*(\d*)',
    r'(RII)\s*(\d*)',
    r'(monkey[\s\-]*kidney)\s*'
]
UNKNOWN_CELL_PATTERNS = [
    r'([CPX]+)\s*(\d*)',
    r'([С]+)\s*(\d*)',
    r'(vero)\s*(\d*)',
    r'(hela)\s*(\d*)',
]
PATTERNS = [
    #(patterns, passage_dict_key)
    # order matters!!
    (EGG_PATTERNS, 'egg'),
    (SIAT_PATTERNS, 'siat'),
    (RHMK_PATTERNS, 'rhmk'),
    (MDCK_PATTERNS, 'mdck'),
    (UNKNOWN_CELL_PATTERNS, 'unknown_cell'),
]

PASSAGE = {
    # 'original', 'egg', 'mdck', 'rhmk', 'siat', 'unknown_cell', 'unknown
    'original': {
        'name': 'original',
        'standard_name': 'Original Specimen',
    },
    'egg': {
        'name': 'egg',
        'standard_name': 'Egg',
    },
    'mdck': {
        'name': 'mdck',
        'standard_name': 'MDCK',
    },
    'rhmk': {
        'name': 'rhmk',
        'standard_name': 'RhMK',
    },
    'siat': {
        'name': 'siat',
        'standard_name': 'SIAT',
    },
    'unknown_cell': {
        'name': 'unknown_cell',
        'standard_name': 'Unknown Cell',
    },
    'unknown': {
        'name': 'unknown',
        'standard_name': 'Unknown',
    }
}
DELIMITERS = ['/', ',', '+', ' or ']
REMOVE_PATTERNS = [
    r'(.*)passage\s*detail[\-s]*\s*',
    r'passage[\-ds:]?\s*',
    r'detail[\-s:]*\s*',
    r'lineage[\-s:]*\s*[a-zA-Z0-9]*',
    r'seasonal[\-:]*\s*',
    r'experiment[al,]*\s*',
    r'part\s*\d*of\s*\d*',
    r'\d+\s*[a-zA-Z]*\s*post[\-\s]*infection\s*',
    r'bronchial wash',
    r'mouse',
    r'duck',
    r'swine',
]
def search_patterns(patterns, string):
    for pattern in patterns:
        match = re.search(pattern, string, re.IGNORECASE)  # search pattern in passage entry
        if match:
            return True
    return False

def standardize(passage):
    # standardize passage info to list of passages
    
    passage = str(passage).lower().strip().lstrip()
    # first, check if original
    if passage in NO_PASSAGE_EXACT_WORDS:
        return [PASSAGE['original']]
    for kw in NO_PASSAGE_KEYWORDS:
        if kw in passage:
            return [PASSAGE['original']]
    
    for p in REMOVE_PATTERNS:
        passage = re.sub(p, '', passage, flags=re.IGNORECASE)

    passage_split = [passage]  # default; just the passage as it is
    for d in DELIMITERS:
        if d in passage:
            delim = d
            passage_split = passage.split(delim)
            break
    identified_passages = []
    for pas in passage_split:
        matched = False
        unknown = False
        for kw in UNKNOWN_PASSAGE_KEYWORDS:
            if kw.lower() in pas.lower():
                # unknown keyword found
                identified_passages.append(PASSAGE['unknown'])
                unknown = True

        if not unknown:
            # unknown keyword not found; search for known keywords
            for (pats, key) in PATTERNS:
                matched = search_patterns(pats, pas)
                if matched:
                    identified_passages.append(PASSAGE[key])
                    break
            # no match found at the end of pattern search
            if not matched:
                identified_passages.append(PASSAGE['unknown'])

    return identified_passages


def convert_passage(passage):
    # convert original passage string into standardized passage information
    info = {
        'passage_original': passage,
        'passage_known': False,  # is passage info identifiable?
        'is_passaged'  : False,  # is passaged? False if original specimen
        'egg_passaged' : False,  # is egg-passaged
        'cell_passaged': False,  # is cell-passaged
        'passage_converted': '', # converted passages, comma-delimited
    }

    pas = standardize(passage)
    pa_conv_string = []
    for pa in pas:
        # 'original', 'egg', 'mdck', 'rhmk', 'siat', 'unknown_cell', 'unknown
        name = pa['name']
        if name == 'original':
            info['passage_known'] = True
            info['is_passaged'] = False
            info['egg_passaged'] = False
            info['cell_passaged'] = False
        elif name == 'egg':
            info['passage_known'] = True
            info['is_passaged'] = True
            info['egg_passaged'] = True
        elif name in ['mdck', 'rhmk', 'siat', 'unknown_cell']:
            info['passage_known'] = True
            info['is_passaged'] = True
            info['cell_passaged'] = True
        
        pa_conv_string.append(pa['standard_name'])
    pa_conv_string = ','.join(pa_conv_string)
    info['passage_converted'] = pa_conv_string
    return info