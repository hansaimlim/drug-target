from django.apps import AppConfig


class ProteinsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'proteins'
