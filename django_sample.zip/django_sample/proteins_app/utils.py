import string
import random
import json
import numpy as np


class NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.bool_):
            return bool(obj)
        return json.JSONEncoder.default(self, obj)

def load_json(filename):
    with open(filename, 'r') as fp:
        data = json.load(fp)
    return data

def save_json(data,filename):
    with open(filename, 'w') as fp:
        json.dump(data, fp, sort_keys=True, indent=4, cls=NumpyEncoder)


def random_filename(size=11):
    chars = string.ascii_uppercase + string.ascii_lowercase + string.digits
    return ''.join(random.SystemRandom().choice(chars) for _ in range(size))

def get_conservation_color(conservation=0.0):
    conservation_colors = {
        'high': 'rgba(0,128,255,0.8)',
        'medium': 'rgba(0,204,102,0.8)',
        'low': 'rgba(222,45,38,0.8)',
    }
    if conservation >= 80.0:
        color = conservation_colors['high']
    elif conservation >= 60.0:
        color = conservation_colors['medium']
    else:
        color = conservation_colors['low']
    return color

def get_gap_color(gap=0.0):
    gap_colors = {
        'high': 'rgba(222,45,38,0.8)',
        'medium': 'rgba(204,204,204,1)',
        'low': 'rgba(204,204,204,1)',
    }
    if gap >= 80.0:
        color = gap_colors['high']
    elif gap >= 60.0:
        color = gap_colors['medium']
    else:
        color = gap_colors['low']
    return color

def get_amino_acid_class_value(aa):
    # classification information from
    # https://www.sigmaaldrich.com/US/en/technical-documents/technical-article/protein-biology/protein-structural-analysis/amino-acid-reference-chart

    aliphatic = ['a', 'i', 'l', 'm', 'v']
    aromatic  = ['f', 'w', 'y']
    polar     = ['n', 'c', 'q', 's', 't']
    acidic    = ['d', 'e']
    basic     = ['r', 'h', 'k']
    unique    = ['g', 'p']
    others    = ['x']
    gap       = ['-']
    if aa.lower() in aliphatic:
        val = 1
    elif aa.lower() in aromatic:
        val = 2
    elif aa.lower() in polar:
        val = 3
    elif aa.lower() in acidic:
        val = 4
    elif aa.lower() in basic:
        val = 5
    elif aa.lower() in unique:
        val = 6
    elif aa.lower() in others:
        val = 7
    else:
        val = None

    return val


def get_amino_acid_charge_class(one):
    if len(one) == 3:
        one = one2three(one)
    elif len(one) == 1:
        one = one
    else:
        raise ValueError("Invalid amino acid code (either 1 or 3 letter). Given {}".format(one))

    if one.lower() in ['r', 'h', 'k']:
        return 'positive'
    elif one.lower() in ['d', 'e']:
        return 'negative'
    else:
        return 'neutral'


AMINOACID = {
    'ala': 'a',
    'arg': 'r',
    'asn': 'n',
    'asp': 'd',
    'asx': 'b',
    'cys': 'c',
    'glu': 'e',
    'gln': 'q',
    'glx': 'z',
    'gly': 'g',
    'his': 'h',
    'ile': 'i',
    'leu': 'l',
    'lys': 'k',
    'met': 'm',
    'phe': 'f',
    'pro': 'p',
    'ser': 's',
    'thr': 't',
    'trp': 'w',
    'tyr': 'y',
    'val': 'v'
}
AminoAcid = {
    'triplet_code': ['ALA', 'CYS', 'ASP', 'GLU', 'PHE', 'GLY', 'HIS',
                     'ILE', 'LYS', 'LEU', 'MET', 'ASN', 'PRO', 'GLN',
                     'ARG', 'SER', 'THR', 'VAL', 'TRP', 'TYR',
                     'ASX', 'GLX'],
    'standard3': ['ALA', 'CYS', 'ASP', 'GLU', 'PHE', 'GLY', 'HIS',
                     'ILE', 'LYS', 'LEU', 'MET', 'ASN', 'PRO', 'GLN',
                     'ARG', 'SER', 'THR', 'VAL', 'TRP', 'TYR'],
    'standard1': ['A', 'C', 'D', 'E', 'F', 'G', 'H',
                     'I', 'K', 'L', 'M', 'N', 'P', 'Q',
                     'R', 'S', 'T', 'V', 'W', 'Y'],
    'singlet_code': ['A', 'C', 'D', 'E', 'F', 'G', 'H',
                     'I', 'K', 'L', 'M', 'N', 'P', 'Q',
                     'R', 'S', 'T', 'V', 'W', 'Y',
                     'B', 'Z'],
    'three2one': {
        'ALA': 'A', 'CYS': 'C', 'ASP': 'D', 'GLU': 'E', 'PHE': 'F', 'GLY': 'G',
        'HIS': 'H', 'ILE': 'I', 'LYS': 'K', 'LEU': 'L', 'MET': 'M', 'ASN': 'N',
        'PRO': 'P', 'GLN': 'Q', 'ARG': 'R', 'SER': 'S', 'THR': 'T', 'VAL': 'V',
        'TRP': 'W', 'TYR': 'Y', 'ASX': 'B', 'GLX': 'Z'
        },

    'one2three': {
        'A': 'ALA', 'C': 'CYS', 'D': 'ASP', 'E': 'GLU', 'F': 'PHE', 'G': 'GLY',
        'H': 'HIS', 'I': 'ILE', 'K': 'LYS', 'L': 'LEU', 'M': 'MET', 'N': 'ASN',
        'P': 'PRO', 'Q': 'GLN', 'R': 'ARG', 'S': 'SER', 'T': 'THR', 'V': 'VAL',
        'W': 'TRP', 'Y': 'TYR', 'B': 'ASX', 'Z': 'GLX'
        },
    'standardASA': {
        # Reference: CM. Topham, J.C. Smith Computational Biology and Chemistry 54 (2015) 33-43
        # Fully-geometry optimized values
        # unit: Angstrom-squared, A^2
        'ALA': 108.50, 'ARG': 246.37, 'ASN': 156.64,
        'ASP': 146.17, 'CYS': 138.40, 'GLN': 181.94,
        'GLU': 177.12, 'GLY': 81.30,  'HIS': 184.51,
        'ILE': 181.50, 'LEU': 182.10, 'LYS': 204.85,
        'MET': 199.13, 'PHE': 208.47, 'PRO': 142.48, # PRO_UP
        'VAL': 152.69, 'SER': 115.91, # SER_TRANS,
        'THR': 140.10, 'TRP': 253.79, 'TYR': 216.69,
        # Non-standard amino acids. Table S7.
        'CSD': 152.62, 'CSO': 150.84, 'OCS': 167.75,
        'SCY': 202.41, 'CGU': 211.99, 'PCA': 208.85, # PCA_C
        'HIC': 214.94, 'HIP': 238.74, 'NEP': 255.45,
        'NLE': 190.29, 'ALY': 279.58, 'M3I': 285.09,
        'MLY': 261.88, 'MLZ': 243.52, 'FME': 289.70, # FME_E
        'MSE': 206.35, 'HYP': 152.63, 'SEP': 197.97,
        'TPO': 212.83, 'PTR': 293.26, 'TYI': 319.96,
        'TYS': 291.20, 'NVA': 160.70,
        # stats to handle missing data; (computed using standard amino acids only)
        'MEAN': 170.933, 'MEDIAN': 179.31, 'STDEV': 43.31
    }
}

def three2one(three):
    return AminoAcid['three2one'].get(three.upper(), 'x')

def one2three(one):
    return AminoAcid['one2three'].get(one.upper(), 'UNK')

def get_standard_asa(aa):
    if len(aa) == 3:
        asa = AminoAcid['standardASA'].get(aa.upper(), None)
    elif len(aa) == 1:
        asa = AminoAcid['standardASA'].get(one2three(aa), None)
    else:
        raise ValueError("Invalid amino acid code (either 1 or 3 letter). Given {}".format(aa))
    return asa

def get_residue_pair_potential(res1, res2):
    """Get pair potential. Inputs could be 3 or 1-letter amino acid code.
    reference: Keskin, O., et al. "Empirical solvent‐mediated potentials hold for both 
               intra‐molecular and inter‐molecular inter‐residue interactions." 
               Protein Science 7.12 (1998): 2578-2586
               https://onlinelibrary.wiley.com/doi/abs/10.1002/pro.5560071211
    """
    res1 = res1.upper()
    res2 = res2.upper()
    valid3 = list(AminoAcid['three2one'].keys())
    if len(res1) == 3:
        if res1 in valid3:
            res1 = AminoAcid['three2one'][res1]
        else:
            return 0
    if len(res2) == 3:
        if res2 in valid3:
            res2 = AminoAcid['three2one'][res2]
        else:
            return 0
    pair = '-'.join(sorted([res1, res2]))
    ppdict = {
        'Q-Y': -4.75, 'Q-Q': -4.71, 'Q-S': -3.06, 'Q-R': -4.13,
        'H-R': -3.24, 'Q-T': -3.44, 'Q-W': -4.87, 'Q-V': -4.29, 'C-F': -4.81,
        'S-W': -2.86, 'E-E': -2.85, 'C-N': -1.76, 'E-G': -1.58, 'C-L': -6.13,
        'C-K': -2.28, 'C-I': -5.53, 'C-H': -4.79, 'C-G': -3.43, 'E-L': -4.35,
        'C-E': -3.02, 'C-D': -3.56, 'E-I': -3.99, 'E-H': -3.15, 'E-K': -2.83,
        'E-T': -2.34, 'E-W': -3.84, 'E-V': -3.2, 'E-Q': -3.45, 'E-P': -1.7,
        'C-Y': -4.71, 'E-R': -4.05, 'C-W': -4.7, 'C-V': -4.82, 'C-T': -2.92,
        'C-S': -3.41, 'C-R': -4.41, 'C-Q': -4.37, 'C-P': -2.97, 'M-Y': -5.01,
        'H-Y': -3.78, 'H-T': -2.73, 'M-T': -3.33, 'H-V': -4.14, 'M-V': -5.16,
        'M-Q': -4.46, 'M-P': -3.11, 'M-S': -3.33, 'M-R': -4.13, 'H-L': -4.85,
        'H-M': -4.47, 'H-N': -3.05, 'M-N': -3.05, 'H-H': -3.08, 'H-I': -4.55,
        'H-K': -2.14, 'S-Y': -3.43, 'F-Y': -5.33, 'F-V': -5.33, 'S-V': -2.95,
        'K-M': -2.36, 'K-L': -3.24, 'F-R': -4.51, 'F-S': -4.01, 'F-P': -3.46,
        'F-Q': -4.89, 'F-N': -3.89, 'K-V': -2.19, 'F-L': -6.65, 'F-M': -5.58,
        'K-S': -1.91, 'F-K': -2.7, 'F-H': -3.82, 'F-I': -6.11, 'F-F': -6.45,
        'F-G': -3.76, 'F-T': -3.85, 'K-Y': -2.64, 'S-T': -2.22, 'N-W': -3.31,
        'S-S': -2.14, 'V-Y': -4.54, 'V-V': -4.86, 'V-W': -4.7, 'K-W': -3.12,
        'K-T': -1.64, 'N-Y': -3.14, 'K-N': -1.63, 'K-R': -2.11, 'A-I': -4.45,
        'A-H': -3.29, 'A-K': -1.91, 'A-M': -4.42, 'A-L': -5.02, 'A-N': -2.06,
        'A-A': -3.51, 'A-C': -3.99, 'K-P': -0.5, 'A-E': -2.69, 'A-D': -2.74,
        'A-G': -2.24, 'A-F': -4.43, 'A-Y': -3.96, 'E-F': -4.1, 'A-Q': -3.65,
        'A-P': -1.78, 'A-S': -2.49, 'A-R': -3.26, 'A-T': -2.38, 'A-W': -4.66,
        'A-V': -3.86, 'G-K': -1.32, 'G-I': -3.5, 'G-H': -2.47, 'G-N': -1.63,
        'G-M': -3.02, 'G-L': -3.79, 'I-I': -5.97, 'I-K': -2.88, 'I-M': -5.37,
        'I-L': -6.67, 'I-N': -3.42, 'I-Q': -4.65, 'I-P': -3.09, 'I-S': -3.47,
        'I-R': -4.29, 'I-T': -3.61, 'I-W': -5.79, 'I-V': -5.31, 'I-Y': -5.39,
        'G-R': -2.71, 'G-Q': -3.02, 'G-P': -1.01, 'G-W': -3.77, 'G-V': -2.77,
        'G-T': -1.81, 'R-R': -3.98, 'C-M': -5.07, 'E-N': -2.43, 'C-C': -7.23,
        'K-K': -1.02, 'P-P': -0.83, 'P-Q': -2.67, 'K-Q': -2.56, 'F-W': -5.72,
        'D-M': -3.69, 'E-S': -2.57, 'W-Y': -5.12, 'Y-Y': -4.58, 'E-Y': -3.62,
        'W-W': -5.16, 'P-T': -1.24, 'R-S': -2.78, 'P-V': -2.43, 'P-W': -3.96,
        'R-V': -3.7, 'R-W': -4.54, 'R-T': -2.43, 'P-S': -1.56, 'G-G': -1.77,
        'R-Y': -4.32, 'P-Y': -2.92, 'D-D': -2.47, 'D-E': -2.35, 'D-F': -3.52,
        'D-G': -1.84, 'D-H': -2.93, 'D-I': -3.46, 'D-K': -2.47, 'D-L': -4.16,
        'G-Y': -3.34, 'D-N': -2.5, 'D-P': -1.24, 'D-Q': -3.15, 'D-R': -3.92,
        'D-S': -2.34, 'D-T': -2.41, 'D-V': -3.28, 'D-W': -3.81, 'D-Y': -3.63,
        'M-W': -5.49, 'N-V': -2.76, 'L-Y': -5.67, 'N-T': -2.05, 'H-W': -4.5,
        'N-R': -2.67, 'N-S': -2.13, 'N-P': -1.01, 'N-Q': -3.0, 'L-P': -3.75,
        'L-Q': -5.36, 'L-R': -5.01, 'L-S': -4.12, 'L-T': -4.28, 'L-V': -6.03,
        'L-W': -6.4, 'H-P': -1.8, 'G-S': -1.68, 'L-L': -7.16, 'L-M': -6.24,
        'L-N': -3.94, 'E-M': -3.76, 'N-N': -1.99, 'H-S': -3.12, 'M-M': -5.89,
        'T-T': -2.12, 'T-V': -2.87, 'T-W': -3.48, 'T-Y': -3.33, 'H-Q': -4.2,
        'P-R': -2.43
    }
    if pair in ppdict:
        return ppdict[pair]
    else:
        return 0


def get_extended_vdw_radii(resName=None):
    """Resname is 3-letter amino acid code.
    If resname not in the dict, the whole dict is returned.
    """
    VDW_RADII_EXTENDED = {
      'ALA': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'OXT': 1.40},
      'ARG': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.87,
              'CD': 1.87, 'NE': 1.65, 'CZ': 1.76,
              'NH1': 1.65, 'NH2': 1.65, 'OXT': 1.40},
      'ASP': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.76,
              'OD1': 1.40, 'OD2': 1.40, 'OXT': 1.40},
      'ASN': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.76,
              'OD1': 1.40, 'ND2': 1.65, 'OXT': 1.40},
      'CYS': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'SG': 1.85, 'OXT': 1.40},
      'GLU': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.87,
              'CD': 1.76, 'OE1': 1.40, 'OE2': 1.40, 'OXT': 1.40},
      'GLN': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.87,
              'CD': 1.76, 'OE1': 1.40, 'NE2': 1.65, 'OXT': 1.40},
      'GLY': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'OXT': 1.40},
      'HIS': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.76,
              'ND1': 1.65, 'CD2': 1.76, 'CE1': 1.76,
              'NE2': 1.65, 'OXT': 1.40},
      'ILE': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG1': 1.87,
              'CG2': 1.87, 'CD1': 1.87, 'OXT': 1.40},
      'LEU': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.87,
              'CD1': 1.87, 'CD2': 1.87, 'OXT': 1.40},
      'LYS': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.87,
              'CD': 1.87, 'CE': 1.87, 'NZ': 1.50, 'OXT': 1.40},
      'MET': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.87,
              'SD': 1.85, 'CE': 1.87, 'OXT': 1.40},
      'PHE': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.76,
              'CD1': 1.76, 'CD2': 1.76, 'CE1': 1.76,
              'CE2': 1.76, 'CZ': 1.76, 'OXT': 1.40},
      'PRO': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.87,
              'CD': 1.87, 'OXT': 1.40},
      'SER': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'OG': 1.40, 'OXT': 1.40},
      'THR': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'OG1': 1.40,
              'CG2': 1.87, 'OXT': 1.40},
      'TRP': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.76,
              'CD1': 1.76, 'CD2': 1.76, 'NE1': 1.65,
              'CE2': 1.76, 'CE3': 1.76, 'CZ2': 1.76,
              'CZ3': 1.76, 'CH2': 1.76, 'OXT': 1.40},
      'TYR': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.76,
              'CD1': 1.76, 'CD2': 1.76, 'CE1': 1.76,
              'CE2': 1.76, 'CZ': 1.76, 'OH': 1.40, 'OXT': 1.40},
      'VAL': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG1': 1.87,
              'CG2': 1.87, 'OXT': 1.40},
      'ASX': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.76,
              'AD1': 1.50, 'AD2': 1.50},
      'GLX': {'N': 1.65, 'CA': 1.87, 'C': 1.76,
              'O': 1.40, 'CB': 1.87, 'CG': 1.76,
              'CD': 1.87, 'AE1': 1.50, 'AE2': 1.50, 'OXT': 1.40},
      'ACE': {'C': 1.76, 'O': 1.40, 'CA': 1.87},
      'PCA': {'C': 1.76, 'N': 1.65, 'O': 1.40, 'CA': 1.87, 'H': 1.20, 'S': 1.85,
              'CB':1.87, 'CZ':1.76, 'NZ':1.50, 'CD':1.81, 'CE':1.81,
              'CG':1.81, 'C1':1.80, 'P':1.90 },
      'UNK': {'C': 1.76, 'N':1.65, 'O':1.40, 'CA':1.87, 'H':1.20, 'S':1.85,
              'CB':1.87, 'CZ':1.76, 'NZ':1.50, 'CD':1.81, 'CE':1.81,
              'CG':1.81, 'C1':1.80, 'P':1.90 }
      }
    if resName is None:
        return VDW_RADII_EXTENDED
    if len(resName) == 1:
        resName = AminoAcid['one2three'][resName]
    if resName in VDW_RADII_EXTENDED:
        return VDW_RADII_EXTENDED[resName]
    else:
        return VDW_RADII_EXTENDED