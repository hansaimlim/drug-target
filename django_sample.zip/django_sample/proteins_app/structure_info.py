import os

REFERENCE_MATCH = {
    # keys are ref.reference_name
    # values: list of pdb ids (for STRUCTURE_INFO[pdb_id])
    "H2": [],
    "H1N1pdm": ["4m4y"],
    "H1_PR34": ["4m4y"],
    "H7N7": [],
    "H4": [],
    "H1_1933": ["4m4y"],
    "H3": ["4o5n"],
    "H1post1995": ["4m4y"],
    "H7N3": [],
    "H5": [],
    "H6": [],
    "B_Victoria": ["4fqm"],
    "B_Yamagata": ["2rfu"],
    "B_Unknown": ["4fqm"],
}
STRUCTURE2REFERENCENAME = {
    "4m4y": "H1_PR34",
    "4o5n": "H3",
    "4fqm": "B_Victoria",
    "2rfu": "B_Yamagata",
}

STRUCTURE_INFO = {
            "2rfu":
            {
                "name": "B/Hong_Kong/8/1973",
                "description": "Crystal structure of influenza B virus hemagglutinin in complex with LSTc receptor analog",
                "short_description": "HA - B/Hong Kong/8/1973",
                "isolateSubtype": "B",
                "moleculeSubtype": "B-Yamagata",
                "segment": "HA",
                "segment_chains": ["A", "B"],
                "chain_info": {
                    "A":
                        {
                            "name": "Hemaggutinin HA1",
                            "segment": "HA",
                            "uniprot_accession": "P03462",
                        },
                    "B":
                        {
                            "name": "Hemaggutinin HA2",
                            "segment": "HA",
                            "uniprot_accession": "P03462",
                        },
                }
            },
            "4o5n":
            {
                "name": "A/Victoria/361/2011",
                "description": "Crystal structure of A/Victoria/361/2011 (H3N2) influenza virus hemagglutinin",
                "isolateSubtype": "A / H3N2",
                "short_description": "HA - A/Victoria/361/2011",
                "moleculeSubtype": "H3",
                "segment": "HA",
                "segment_chains": ["A", "B"],
                "chain_info": {
                    "A":
                        {
                            "name": "Hemaggutinin HA1",
                            "segment": "HA",
                            "uniprot_accession": "A0A097PF39",
                        },
                    "B":
                        {
                            "name": "Hemaggutinin HA2",
                            "segment": "HA",
                            "uniprot_accession": "L0HR89",
                        },
                }
            },
            # "5gjs":
            # {
            #     "name": "A/California/04/2009",
            #     "description": "Crystal structure of H1 hemagglutinin from A/California/04/2009 in complex with a neutralizing antibody 3E1",
            #     "isolateSubtype": "A / H1N1",
            #     "short_description": "Antibody on HA stem",
            #     "moleculeSubtype": "H1",
            #     "segment": "HA",
            #     "segment_chains": ["A", "B"],
            #     "chain_info": {
            #         "A":
            #             {
            #                 "name": "Hemaggutinin HA1",
            #                 "segment": "HA",
            #                 "uniprot_accession": "C3W5S1",
            #             },
            #         "B":
            #             {
            #                 "name": "Hemaggutinin HA2",
            #                 "segment": "HA",
            #                 "uniprot_accession": "C3W5S1",
            #             },
            #         "L":
            #             {
            #                 "name": "Neutralizing antibody 3E1 LC",
            #                 "segment": None,
            #                 "uniprot_accession": None,
            #             },
            #         "H":
            #             {
            #                 "name": "Neutralizing antibody 3E1 HC",
            #                 "segment": None,
            #                 "uniprot_accession": None,
            #             }
            #     }
            # },
            # "4gxu":
            # {
            #     "name": "A/Brevig Mission/1/1918",
            #     "description": "Crystal structure of antibody 1F1 bound to the 1918 influenza hemagglutinin",
            #     "isolateSubtype": "A / H1N1",
            #     "short_description": "Antibody on HA head",
            #     "moleculeSubtype": "H1",
            #     "segment": "HA",
            #     "segment_chains": ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"],
            #     "chain_info": {
            #         "A":
            #             {
            #                 "name": "Hemaggutinin HA1",
            #                 "segment": "HA",
            #                 "uniprot_accession": "Q9WFX3",
            #             },
            #         "C":
            #             {
            #                 "name": "Hemaggutinin HA1",
            #                 "segment": "HA",
            #                 "uniprot_accession": "Q9WFX3",
            #             },
            #         "E":
            #             {
            #                 "name": "Hemaggutinin HA1",
            #                 "segment": "HA",
            #                 "uniprot_accession": "Q9WFX3",
            #             },
            #         "G":
            #             {
            #                 "name": "Hemaggutinin HA1",
            #                 "segment": "HA",
            #                 "uniprot_accession": "Q9WFX3",
            #             },
            #         "I":
            #             {
            #                 "name": "Hemaggutinin HA1",
            #                 "segment": "HA",
            #                 "uniprot_accession": "Q9WFX3",
            #             },
            #         "K":
            #             {
            #                 "name": "Hemaggutinin HA1",
            #                 "segment": "HA",
            #                 "uniprot_accession": "Q9WFX3",
            #             },
            #         "B":
            #             {
            #                 "name": "Hemaggutinin HA2",
            #                 "segment": "HA",
            #                 "uniprot_accession": "Q9WFX3",
            #             },
            #         "D":
            #             {
            #                 "name": "Hemaggutinin HA2",
            #                 "segment": "HA",
            #                 "uniprot_accession": "Q9WFX3",
            #             },
            #         "F":
            #             {
            #                 "name": "Hemaggutinin HA2",
            #                 "segment": "HA",
            #                 "uniprot_accession": "Q9WFX3",
            #             },
            #         "H":
            #             {
            #                 "name": "Hemaggutinin HA2",
            #                 "segment": "HA",
            #                 "uniprot_accession": "Q9WFX3",
            #             },
            #         "J":
            #             {
            #                 "name": "Hemaggutinin HA2",
            #                 "segment": "HA",
            #                 "uniprot_accession": "Q9WFX3",
            #             },
            #         "L":
            #             {
            #                 "name": "Hemaggutinin HA2",
            #                 "segment": "HA",
            #                 "uniprot_accession": "Q9WFX3",
            #             },
            #         "M":
            #             {
            #                 "name": "Antibody 1F1, HC",
            #                 "segment": None,
            #                 "uniprot_accession": None,
            #             },
            #         "O":
            #             {
            #                 "name": "Antibody 1F1, HC",
            #                 "segment": None,
            #                 "uniprot_accession": None,
            #             },
            #         "Q":
            #             {
            #                 "name": "Antibody 1F1, HC",
            #                 "segment": None,
            #                 "uniprot_accession": None,
            #             },
            #         "S":
            #             {
            #                 "name": "Antibody 1F1, HC",
            #                 "segment": None,
            #                 "uniprot_accession": None,
            #             },
            #         "U":
            #             {
            #                 "name": "Antibody 1F1, HC",
            #                 "segment": None,
            #                 "uniprot_accession": None,
            #             },
            #         "W":
            #             {
            #                 "name": "Antibody 1F1, HC",
            #                 "segment": None,
            #                 "uniprot_accession": None,
            #             },
            #         "N":
            #             {
            #                 "name": "Antibody 1F1, LC",
            #                 "segment": None,
            #                 "uniprot_accession": None,
            #             },
            #         "P":
            #             {
            #                 "name": "Antibody 1F1, LC",
            #                 "segment": None,
            #                 "uniprot_accession": None,
            #             },
            #         "R":
            #             {
            #                 "name": "Antibody 1F1, LC",
            #                 "segment": None,
            #                 "uniprot_accession": None,
            #             },
            #         "T":
            #             {
            #                 "name": "Antibody 1F1, LC",
            #                 "segment": None,
            #                 "uniprot_accession": None,
            #             },
            #         "V":
            #             {
            #                 "name": "Antibody 1F1, LC",
            #                 "segment": None,
            #                 "uniprot_accession": None,
            #             },
            #         "X":
            #             {
            #                 "name": "Antibody 1F1, LC",
            #                 "segment": None,
            #                 "uniprot_accession": None,
            #             },
            #     }
            # },
            # "5w42": 
            # {
            #     "name": "A/Minnesota/11/2010",
            #     "description": "Crystal structure of human monoclonal antibody H3v-47 in complex with influenza virus hemagglutinin from A/Minnesota/11/2010 (H3N2)",
            #     "isolateSubtype": "A / H3N2",
            #     "short_description": "Antibody on HA head",
            #     "moleculeSubtype": "H3",
            #     "segment": "HA",
            #     "segment_chains": ["A", "B"],
            #     "chain_info": {
            #         "A":
            #             {
            #                 "name": "Hemaggutinin HA1",
            #                 "segment": "HA",
            #                 "uniprot_accession": "I0AXC3",
            #             },
            #         "B":
            #             {
            #                 "name": "Hemaggutinin HA2",
            #                 "segment": "HA",
            #                 "uniprot_accession": "I0AXC3",
            #             },
            #         "H":
            #             {
            #                 "name": "Fab H3v-47 HC",
            #                 "segment": None,
            #                 "uniprot_accession": "Q6N089",
            #             },
            #         "L":
            #             {
            #                 "name": "Fab H3v-47 LC",
            #                 "segment": None,
            #                 "uniprot_accession": "Q8TCD0",
            #             }
            #     }
            # },
            "2aeq": 
            {
                "name": "A/Memphis/31/98",
                "description": "An epidemiologically significant epitope of a 1998 influenza virus neuraminidase forms a highly hydrated interface in the NA-antibody complex",
                "isolateSubtype": "A / H3N2",
                "short_description": "Antibody complex",
                "moleculeSubtype": "N2",
                "segment": "NA",
                "segment_chains": ["A"],
                "chain_info": {
                    "A":
                        {
                            "name": "Neuraminidase",
                            "segment": "NA",
                            "uniprot_accession": None,
                        },
                    "H":
                        {
                            "name": "FAB heavy chain",
                            "segment": None,
                            "uniprot_accession": None,
                        },
                    "L":
                        {
                            "name": "FAB light chain",
                            "segment": None,
                            "uniprot_accession": None,
                        },
                }
            },
            "4m4y":
            {
                "name": "A/California/04/2009",
                "description": "Crystal structure of a 2009 H1N1 influenza virus hemagglutinin with a stabilization mutation HA2 E47G",
                "isolateSubtype": "A / H1N1",
                "short_description": "HA hexamer - A/California/04/2009",
                "moleculeSubtype": "H1",
                "segment": "HA",
                "segment_chains": ["A", "C", "E", "D", "E", "F"],
                "chain_info": {
                    "A":
                        {
                            "name": "Hemaggutinin HA1",
                            "segment": "HA",
                            "uniprot_accession": "C3W5S1",
                        },
                    "C":
                        {
                            "name": "Hemaggutinin HA1",
                            "segment": "HA",
                            "uniprot_accession": "C3W5S1",
                        },
                    "E":
                        {
                            "name": "Hemaggutinin HA1",
                            "segment": "HA",
                            "uniprot_accession": "C3W5S1",
                        },
                    "D":
                        {
                            "name": "Hemaggutinin HA2",
                            "segment": "HA",
                            "uniprot_accession": "C3W5S1",
                        },
                    "B":
                        {
                            "name": "Hemaggutinin HA2",
                            "segment": "HA",
                            "uniprot_accession": "C3W5S1",
                        },
                    "F":
                        {
                            "name": "Hemaggutinin HA2",
                            "segment": "HA",
                            "uniprot_accession": "C3W5S1",
                        },
                }
            },
            "3ti5":
            {
                "name": "A/California/04/2009",
                "description": "Crystal structure of 2009 pandemic H1N1 neuraminidase complexed with Zanamivir",
                "isolateSubtype": "A / H1N1",
                "short_description": "NA tetramer - A/California/04/2009",
                "moleculeSubtype": "N1",
                "segment": "NA",
                "segment_chains": ["A", "B"],
                "chain_info": {
                    "A":
                        {
                            "name": "Neuraminidase",
                            "segment": "NA",
                            "uniprot_accession": "C3W5S3",
                        },
                    "B":
                        {
                            "name": "Neuraminidase",
                            "segment": "NA",
                            "uniprot_accession": "C3W5S3",
                        },
                    
                }
            },
            # "4fqk": 
            # {
            #     "name": "B/Brisbane/60/2008",
            #     "description": "Influenza B/Brisbane/60/2008 hemagglutinin Fab CR8059 complex",
            #     "isolateSubtype": "B",
            #     "short_description": "Antibody on HA head",
            #     "moleculeSubtype": "B-Victoria",
            #     "segment": "HA",
            #     "segment_chains": ["A", "B", "C", "D"],
            #     "chain_info": {
            #         "A":
            #             {
            #                 "name": "Hemaggutinin HA1",
            #                 "segment": "HA",
            #                 "uniprot_accession": "C0LT38",
            #             },
            #         "C":
            #             {
            #                 "name": "Hemaggutinin HA1",
            #                 "segment": "HA",
            #                 "uniprot_accession": "C0LT38",
            #             },
            #         "B":
            #             {
            #                 "name": "Hemaggutinin HA2",
            #                 "segment": "HA",
            #                 "uniprot_accession": "C0LT38",
            #             },
            #         "D":
            #             {
            #                 "name": "Hemaggutinin HA2",
            #                 "segment": "HA",
            #                 "uniprot_accession": "C0LT38",
            #             },
            #         "E":
            #             {
            #                 "name": "Antibody CR8059 HC",
            #                 "segment": None,
            #                 "uniprot_accession": "",
            #             },
            #         "H":
            #             {
            #                 "name": "Antibody CR8059 HC",
            #                 "segment": None,
            #                 "uniprot_accession": "",
            #             },
            #         "F":
            #             {
            #                 "name": "Antibody CR8059 LC",
            #                 "segment": None,
            #                 "uniprot_accession": "",
            #             },
            #         "L":
            #             {
            #                 "name": "Antibody CR8059 LC",
            #                 "segment": None,
            #                 "uniprot_accession": "",
            #             },
            #     }
            # },
            "4fqm":
            {
                "name": "B/Brisbane/60/2008",
                "description": "Structure of B/Brisbane/60/2008 Influenza Hemagglutinin",
                "isolateSubtype": "B",
                "short_description": "HA hexamer - B/Brisbane/60/2008",
                "moleculeSubtype": "B-Victoria",
                "segment": "HA",
                "segment_chains": ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L"],
                "chain_info": {
                    "A":
                        {
                            "name": "Hemaggutinin HA1",
                            "segment": "HA",
                            "uniprot_accession": "C0LT38",
                        },
                    "C":
                        {
                            "name": "Hemaggutinin HA1",
                            "segment": "HA",
                            "uniprot_accession": "C0LT38",
                        },
                    "E":
                        {
                            "name": "Hemaggutinin HA1",
                            "segment": "HA",
                            "uniprot_accession": "C0LT38",
                        },
                    "G":
                        {
                            "name": "Hemaggutinin HA1",
                            "segment": "HA",
                            "uniprot_accession": "C0LT38",
                        },
                    "I":
                        {
                            "name": "Hemaggutinin HA1",
                            "segment": "HA",
                            "uniprot_accession": "C0LT38",
                        },
                    "K":
                        {
                            "name": "Hemaggutinin HA1",
                            "segment": "HA",
                            "uniprot_accession": "C0LT38",
                        },
                    "B":
                        {
                            "name": "Hemaggutinin HA2",
                            "segment": "HA",
                            "uniprot_accession": "C0LT38",
                        },
                    "D":
                        {
                            "name": "Hemaggutinin HA2",
                            "segment": "HA",
                            "uniprot_accession": "C0LT38",
                        },
                    "F":
                        {
                            "name": "Hemaggutinin HA2",
                            "segment": "HA",
                            "uniprot_accession": "C0LT38",
                        },
                    "H":
                        {
                            "name": "Hemaggutinin HA2",
                            "segment": "HA",
                            "uniprot_accession": "C0LT38",
                        },
                    "J":
                        {
                            "name": "Hemaggutinin HA2",
                            "segment": "HA",
                            "uniprot_accession": "C0LT38",
                        },
                    "L":
                        {
                            "name": "Hemaggutinin HA2",
                            "segment": "HA",
                            "uniprot_accession": "C0LT38",
                        },
                }
            },
            "4cpn":
            {
                "name": "B/Brisbane/60/2008",
                "description": "Structure of the Neuraminidase from the B/Brisbane/60/2008 virus in complex with Zanamivir",
                "isolateSubtype": "B",
                "short_description": "NA tetramer - B/Brisbane/60/2008",
                "moleculeSubtype": "B-Victoria",
                "segment": "NA",
                "segment_chains": ["A", "B"],
                "chain_info": {
                    "A":
                        {
                            "name": "Neuraminidase",
                            "segment": "NA",
                            "uniprot_accession": "C0LT34",
                        },
                    "B":
                        {
                            "name": "Neuraminidase",
                            "segment": "NA",
                            "uniprot_accession": "C0LT34",
                        },
                }
            }
        }