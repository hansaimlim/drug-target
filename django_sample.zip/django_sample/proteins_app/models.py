from django.db import models
from django.core.validators import MinLengthValidator
from django.contrib.auth.models import User
from django.conf import settings
from django.utils import timezone
from django.contrib.postgres.fields import ArrayField
import datetime
# Create your models here.

class UpdateType(models.TextChoices):
    INIT = "1", "Initial load"
    UPDATE = "2", "Update"

class DatabaseStatus(models.TextChoices):
    ON = "1", "Database is on"
    UPDATE_IN_PROGRESS_ISOLATE = "2", "Update in progress - isolate and sequence data update"
    UPDATE_IN_PROGRESS_ANNOTATIONS = "3", "Update in progress - annotations"
    UPDATE_IN_PROGRESS_CLADE_ASSIGNMENT = "4", "Update in progress - clade assignment"


class UpdateHistory(models.Model):
    metadata_file = models.CharField(
        max_length=256,
        default='',
        help_text='json metadata file for this update.'
    )
    counts = models.JSONField(
        default=dict,
        help_text="counts of table rows AFTER update"
    )
    description = models.CharField(
        max_length=3000,
        default='',
        help_text="A short description for the update. Max 3000 characters."
    )
    status = models.CharField(
        max_length=3, choices=DatabaseStatus.choices,
        default=DatabaseStatus.ON
    )
    date_started = models.DateTimeField(auto_now_add=True)
    date_last_updated = models.DateTimeField(auto_now=True)

    class Meta:
        get_latest_by = "date_started"
        verbose_name = "update history"
        verbose_name_plural = "update histories"

    def __str__(self):
        return "Updated at {}".format(self.date_last_updated)

class IsolateSubtype(models.Model):
    name = models.CharField(
        max_length=10,
        unique=True,
        help_text="Isolate-level subtype. e.g. A/H3N2"
    )

    def __str__(self):
        return self.name

class MoleculeSubtype(models.Model):
    name = models.CharField(
        max_length=10,
        unique=True,
        help_text="Molecule-level subtype. e.g. H1"
    )

    def __str__(self):
        return self.name

class Lineage(models.Model):
    name = models.CharField(
        max_length=20,
        unique=True,
        help_text="Lineage name. e.g. pdm09"
    )

    def __str__(self):
        return self.name

    
class Clade(models.Model):
    name = models.CharField(
        max_length=10,
        unique=False,
        help_text="Smallest unit of clade. May not be unique; subclades are separated. e.g. 6B.1A -> [6B, 1A] instead of '6B.1A'"
    )
    full_name = models.CharField(
        max_length=100,
        unique=True,
        help_text="Full name of the clade; e.g. '6B.1A.5a.1'"
    )
    short_name = models.CharField(
        max_length=20,
        default='',
        help_text="Short name for the clade. e.g. 2a.3 for clade 3C.2a1b.2a.2a.3"
    )
    parent = models.ForeignKey('self', null=True, blank=True, on_delete=models.CASCADE)
    level = models.PositiveSmallIntegerField(default=0)
    
    def __str__(self):
        return self.full_name

class Laboratory(models.Model):
    """for both origin_lab and submit_lab"""
    name = models.CharField(
        max_length=200,
        unique=True,
        help_text="Laboratory name. e.g. Centers for Disease Control and Prevention"
    )
    short_name = models.CharField(
        default="",
        max_length=30,
        blank=True,
        help_text="Short name for laboratory. e.g. CDC"
    )

    def __str__(self):
        return self.name

class Continent(models.Model):
    """
    location:
    Continent / Country / Region 
    """
    name = models.CharField(
        max_length=30,
        unique=True,
        help_text="Continent name. e.g. North America"
    )

    def __str__(self):
        return self.name

class Country(models.Model):
    name = models.CharField(
        max_length=100,
        unique=True,
        help_text="Country name. e.g. United States"
    )

    def __str__(self):
        return self.name

class Region(models.Model):
    name = models.CharField(
        max_length=100,
        unique=True,
        help_text="Region name, if available. e.g. West Virginia"
    )

    def __str__(self):
        return self.name


class Host(models.Model):
    name = models.CharField(
        max_length=200,
        unique=True,
        help_text="Isolate host. e.g. Human (or Unknown)"
    )

    def __str__(self):
        return self.name


class Gender(models.Model):
    name = models.CharField(
        max_length=10,
        unique=True,
        help_text="Gender for host. e.g. Male"
    )

    def __str__(self):
        return self.name

class AgeUnit(models.Model):
    name = models.CharField(
        max_length=6,
        unique=True,
        help_text="Age unit. e.g. Y for year"
    )

    def __str__(self):
        return self.name

class Passage(models.Model):
    name = models.CharField(
        max_length=200,
        unique=True,
        help_text="(Unique) Passage text as appeared in the database, after p.strip().lstrip()."
    )
    standardized_name = models.CharField(
        max_length=100,
        help_text="System-converted passages separated by comma. e.g. Unknown Cell,Unknown Cell,SIAT"
    )
    is_known = models.BooleanField(
        default=False,
        blank=True,
        help_text="True if passage info can be identified. False for unknown/unidentifiable passage info."
    )
    is_passaged = models.BooleanField(
        default=False,
        blank=True,
        help_text="True if any passaged. False if original specimen. If False (original), it cannot be egg or cell-passaged."
    )
    is_egg_passaged = models.BooleanField(
        default=False,
        blank=True,
        help_text="True if egg-passaged"
    )
    is_cell_passaged = models.BooleanField(
        default=False,
        blank=True,
        help_text="True if cell-passaged"
    )

    def __str__(self):
        return self.name



class Isolate(models.Model):
    accession = models.CharField(
        max_length=200,
        unique=True,
        help_text="(Unique) Isolate ID. e.g. EPI_ISL_101247"
    )
    name = models.CharField(
        max_length=200,
        help_text="Isolate name. e.g. A/Colorado/18/2011"
    )
    segment_ids = models.JSONField(default=dict)
    submit_sample_id = models.CharField(max_length=300, default='', null=True, blank=True)
    origin_sample_id = models.CharField(max_length=300, default='', null=True, blank=True)
    collection_date = models.DateField(
        default=None,
        null=True,
        blank=True,
        help_text="Collection date, if available."
    )
    submission_date = models.DateField(
        default=None,
        null=True,
        blank=True,
        help_text="Submission date, if available."
    )
    host = models.ForeignKey(Host, null=True, blank=True, on_delete=models.PROTECT)
    host_age = models.FloatField(
        default=None,
        null=True,
        blank=True,
        help_text="Host age without unit"
    )
    clade = models.ForeignKey(Clade, null=True, blank=True, on_delete=models.PROTECT)  # clade may be unassigned
    passage = models.ForeignKey(Passage, null=True, blank=True, on_delete=models.PROTECT)
    host_age_unit = models.ForeignKey(AgeUnit, null=True, blank=True, on_delete=models.CASCADE)
    host_gender = models.ForeignKey(Gender, null=True, blank=True, on_delete=models.CASCADE)
    lineage = models.ForeignKey(Lineage, null=True, blank=True, on_delete=models.CASCADE)
    continent = models.ForeignKey(Continent, null=True, blank=True, on_delete=models.CASCADE)
    country = models.ForeignKey(Country, null=True, blank=True, on_delete=models.CASCADE)
    region = models.ForeignKey(Region, null=True, blank=True, on_delete=models.CASCADE)

    subtype = models.ForeignKey(IsolateSubtype, null=True, blank=True, on_delete=models.CASCADE)
    submit_lab = models.ForeignKey(Laboratory, null=True, blank=True, related_name="submit_lab", on_delete=models.CASCADE)
    origin_lab = models.ForeignKey(Laboratory, null=True, blank=True, related_name="origin_lab", on_delete=models.CASCADE)

    def __str__(self):
        return self.name


class Hemagglutinin(models.Model):
    accession = models.CharField(
        max_length=200,
        unique=True,
        help_text="(Unique) HA-ID, no hyphens or underscores. e.g. EPI348174"
    )
    subtype = models.ForeignKey(MoleculeSubtype, null=True, blank=True, on_delete=models.CASCADE)
    isolate = models.ForeignKey(Isolate, on_delete=models.CASCADE)
    sequence = models.TextField(help_text="Protein primary sequence.")

    def __str__(self):
        if self.isolate:
            return self.isolate.name
        else:
            return "Isolate unknown"

class Neuraminidase(models.Model):
    accession = models.CharField(
        max_length=200,
        unique=True,
        help_text="(Unique) NA-ID, no hyphens or underscores. e.g. EPI348173"
    )
    subtype = models.ForeignKey(MoleculeSubtype, null=True, blank=True, on_delete=models.CASCADE)
    isolate = models.ForeignKey(Isolate, on_delete=models.CASCADE)
    sequence = models.TextField(help_text="Protein primary sequence.")

    def __str__(self):
        if self.isolate:
            return self.isolate.name
        else:
            return "Isolate unknown"


class NuclearProtein(models.Model):
    accession = models.CharField(
        max_length=200,
        unique=True,
        help_text="(Unique) NP-ID, no hyphens or underscores. e.g. EPI348173"
    )
    isolate = models.ForeignKey(Isolate, related_name='nuclearprotein_isolate', on_delete=models.CASCADE)
    sequence = models.TextField(default='', help_text="Protein primary sequence from GISAID database.")

    def __str__(self):
        if self.isolate:
            return self.isolate.name
        else:
            return "Isolate unknown"


class NuclearExportProtein(models.Model):
    accession = models.CharField(
        max_length=200,
        unique=True,
        help_text="(Unique) NEP-ID, no hyphens or underscores. e.g. EPI348173"
    )
    isolate = models.ForeignKey(Isolate, related_name='nuclearexportprotein_isolate', on_delete=models.CASCADE)
    sequence = models.TextField(default='', help_text="Protein primary sequence from GISAID database.")

    def __str__(self):
        if self.isolate:
            return self.isolate.name
        else:
            return "Isolate unknown"

class MatrixProtein(models.Model):
    accession = models.CharField(
        max_length=200,
        unique=True,
        help_text="(Unique) M1-ID, no hyphens or underscores. e.g. EPI348173"
    )
    isolate = models.ForeignKey(Isolate, related_name='matrixprotein1_isolate', on_delete=models.CASCADE)
    sequence = models.TextField(default='', help_text="Protein primary sequence from GISAID database.")

    def __str__(self):
        if self.isolate:
            return self.isolate.name
        else:
            return "Isolate unknown"
    

class MatrixProtein2(models.Model):
    accession = models.CharField(
        max_length=200,
        unique=True,
        help_text="(Unique) M2-ID, no hyphens or underscores. e.g. EPI348173"
    )
    isolate = models.ForeignKey(Isolate, related_name='matrixprotein2_isolate', on_delete=models.CASCADE)
    sequence = models.TextField(default='', help_text="Protein primary sequence from GISAID database.")

    def __str__(self):
        if self.isolate:
            return self.isolate.name
        else:
            return "Isolate unknown"


class NonStructuralProtein(models.Model):
    accession = models.CharField(
        max_length=200,
        unique=True,
        help_text="(Unique) NS1-ID, no hyphens or underscores. e.g. EPI348173"
    )
    isolate = models.ForeignKey(Isolate, related_name='nonstructuralprotein1_isolate', on_delete=models.CASCADE)
    sequence = models.TextField(default='', help_text="Protein primary sequence from GISAID database.")

    def __str__(self):
        if self.isolate:
            return self.isolate.name
        else:
            return "Isolate unknown"


class PolymeraseA(models.Model):
    accession = models.CharField(
        max_length=200,
        unique=True,
        help_text="(Unique) PA-ID, no hyphens or underscores. e.g. EPI348173"
    )
    isolate = models.ForeignKey(Isolate, related_name='polymerasea_isolate', on_delete=models.CASCADE)
    sequence = models.TextField(default='', help_text="Protein primary sequence from GISAID database.")

    def __str__(self):
        if self.isolate:
            return self.isolate.name
        else:
            return "Isolate unknown"

class PolymeraseB1(models.Model):
    accession = models.CharField(
        max_length=200,
        unique=True,
        help_text="(Unique) PB1-ID, no hyphens or underscores. e.g. EPI348173"
    )
    isolate = models.ForeignKey(Isolate, related_name='polymeraseb1_isolate', on_delete=models.CASCADE)
    sequence = models.TextField(default='', help_text="Protein primary sequence from GISAID database.")

    def __str__(self):
        if self.isolate:
            return self.isolate.name
        else:
            return "Isolate unknown"
    
class PolymeraseB1F2(models.Model):
    accession = models.CharField(
        max_length=200,
        unique=True,
        help_text="(Unique) PB1-F2-ID, no hyphens or underscores. e.g. EPI348173"
    )
    isolate = models.ForeignKey(Isolate, related_name='polymeraseb1f2_isolate', on_delete=models.CASCADE)
    sequence = models.TextField(default='', help_text="Protein primary sequence from GISAID database.")

    def __str__(self):
        if self.isolate:
            return self.isolate.name
        else:
            return "Isolate unknown"

class PolymeraseB2(models.Model):
    accession = models.CharField(
        max_length=200,
        unique=True,
        help_text="(Unique) PB2-ID, no hyphens or underscores. e.g. EPI348173"
    )
    isolate = models.ForeignKey(Isolate, related_name='polymeraseb2_isolate', on_delete=models.CASCADE)
    sequence = models.TextField(default='', help_text="Protein primary sequence from GISAID database.")

    def __str__(self):
        if self.isolate:
            return self.isolate.name
        else:
            return "Isolate unknown"


class ReferenceHemagglutinin(models.Model):
    ha = models.ForeignKey(Hemagglutinin, blank=True, null=True, on_delete=models.CASCADE)
    reference_name = models.CharField(
        max_length=20,
        unique=True,
        help_text="(Unique) Type of reference. e.g. H1N1pdm or H3"
    )
    full_sequence = models.TextField(help_text="Protein primary full-sequence. (signal peptide + mature sequence)")
    mature_sequence = models.TextField(help_text="Mature sequence.")
    signal_peptide = models.TextField(help_text="Signal peptide.")
    epitopes = models.JSONField(default=dict)  # residue index -> epitope name
    
    def __str__(self):
        return self.reference_name


class VaccineHemagglutinin(models.Model):
    ha = models.ForeignKey(Hemagglutinin, on_delete=models.CASCADE)
    vaccine_years = ArrayField(models.IntegerField())
    latest_vaccine_year = models.PositiveSmallIntegerField(default=1)

    class Meta:
        get_latest_by = "-latest_vaccine_year"

    def __str__(self):
        passage = []
        if self.ha.isolate.passage.is_egg_passaged:
            passage.append('Egg')
        if self.ha.isolate.passage.is_cell_passaged:
            passage.append('Cell')
        if len(passage) == 1:
            return "{}. ({}-based {}, latest vaccine year={})".format(self.ha.isolate.name, passage[0], self.ha.isolate.subtype, self.latest_vaccine_year)
        else:
            return "{}. ({}; latest vaccine year={})".format(self.ha.isolate.name, self.ha.isolate.subtype, self.latest_vaccine_year)



class VaccineToReferenceHemagglutinin(models.Model):
    # same as PairwiseAlignedHemagglutinin
    # for (vaccine HA - Reference HA) pairs
    vaccine = models.ForeignKey(VaccineHemagglutinin, on_delete=models.CASCADE)
    reference = models.ForeignKey(ReferenceHemagglutinin, on_delete=models.CASCADE)
    score = models.FloatField(default=0.0, help_text="pairwise alignment score")
    vaccine_aligned= models.TextField(help_text="Aligned query sequence.")
    reference_aligned = models.TextField(help_text="Aligned reference sequence.")
    vaccine_start = models.PositiveSmallIntegerField(default=1)
    reference_start = models.PositiveSmallIntegerField(default=1)

    def __str__(self):
        return "{} aligned against {}".format(self.vaccine.ha.isolate.name, self.reference.reference_name)
    
class PairwiseAlignedHemagglutinin(models.Model):
    query = models.ForeignKey(Hemagglutinin, on_delete=models.CASCADE)
    reference = models.ForeignKey(ReferenceHemagglutinin, on_delete=models.CASCADE)
    score = models.FloatField(default=0.0, help_text="pairwise alignment score")
    query_aligned = models.TextField(help_text="Aligned query sequence.")
    reference_aligned = models.TextField(help_text="Aligned reference sequence.")
    query_start = models.PositiveSmallIntegerField(default=1)
    reference_start = models.PositiveSmallIntegerField(default=1)

    def __str__(self):
        return "{} aligned against {}".format(self.query.accession, self.reference.accession)


class PDBStructure(models.Model):
    pdb_id = models.CharField(
        max_length=10, unique=True,
        help_text="4-letter PDB ID for the whole structure."
    )
    isolate_subtype = models.ForeignKey(IsolateSubtype, on_delete=models.CASCADE)
    molecule_subtype = models.ForeignKey(MoleculeSubtype, on_delete=models.CASCADE)
    description = models.CharField(
        max_length=1000, default='',
        help_text="Text description for the PDB structure."
    )
    short_description = models.CharField(
        max_length=200, default='',
        help_text="Short, highlighed description for the structure. e.g. with antibody on stem; HA monomer; etc"
    )
    chain_info = models.JSONField(default=dict)
    pair_potential = models.JSONField(default=dict)
    sasa = models.JSONField(default=dict)  # SASA
    relative_sasa = models.JSONField(default=dict)  # percent scale relative SASA
    epitopes = models.JSONField(default=dict)  # chain_id -> {residue_number -> epitope_name}
    pdb_file = models.CharField(
        max_length=500, default='',
        help_text="Full path to the pdb file (.pdb) not (.cif)."
    )
    
    def __str__(self):
        return "{} (PDB:{}. {})".format(self.molecule_subtype, self.pdb_id, self.short_description)

class ReferenceHemagglutininStructureAligned(models.Model):
    reference = models.ForeignKey(ReferenceHemagglutinin, on_delete=models.CASCADE)
    structure = models.ForeignKey(PDBStructure, on_delete=models.CASCADE)
    position_map = models.JSONField(default=dict)

    def __str__(self):
        return "{} to {}".format(self.reference.reference_name, self.structure.pdb_id)
    

SEGMENT_MODELS = {
    'HA': Hemagglutinin,
    'NA': Neuraminidase,
    'NP': NuclearProtein,
    'NEP': NuclearExportProtein,
    'PB2': PolymeraseB2,
    'PB1': PolymeraseB1,
    'PB1-F2': PolymeraseB1F2,
    'PA': PolymeraseA,
    'MP': MatrixProtein,
    'M1': MatrixProtein,
    'M2': MatrixProtein2,
    'NS': NonStructuralProtein,
    'NS1': NonStructuralProtein,
    'NS2': NuclearExportProtein,
}