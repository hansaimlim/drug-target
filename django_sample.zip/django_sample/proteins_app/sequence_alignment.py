import os
import json
import random
from proteins import utils
from django.conf import settings
from Bio.Blast.Applications import NcbiblastpCommandline
from Bio.Blast import NCBIXML


def parse_alignment_output(blast_outfile):
    # blast outfile from outfmt=5; xml output
    data = {}
    for record in NCBIXML.parse(open(blast_outfile)):
        if record.alignments:
            for align in record.alignments:
                for hsp in align.hsps:
                    data['query'] = hsp.query
                    data['subject'] = hsp.sbjct
                    data['score'] = hsp.bits
                    data['query_start'] = hsp.query_start
                    data['subject_start'] = hsp.sbjct_start
    return data

def pairwise_align(ref_seq='', query_seq='', clean=True, work_dir=None):
    # pairwise align using blastp
    if not work_dir:
        work_dir = settings.BLASTP_TEMP_DIR
    cur_dir = os.getcwd()
    os.chdir(work_dir)
    query_file = os.path.join(work_dir, utils.random_filename(size=19))
    ref_file = os.path.join(work_dir, utils.random_filename(size=18))
    out_file = os.path.join(work_dir, utils.random_filename(size=17))
    with open(query_file, 'w') as out:
        out.write('>Query\n')
        out.write('\n'.join([query_seq[i:i+60] for i in range(0, len(query_seq), 60)]))
    with open(ref_file, 'w') as out:
        out.write('>Reference\n')
        out.write('\n'.join([ref_seq[i:i+60] for i in range(0, len(ref_seq), 60)]))
    cline = NcbiblastpCommandline(query=query_file, subject=ref_file, html=False, outfmt=5, out=out_file, max_hsps=1)
    cline()
    aln_output = parse_alignment_output(out_file)
    # subs_mat = substitution_matrices.load(subs_mat)  # BLAST default is BLOSUM62
    # aln = pairwise2.align.globalds(ref_seq, query_seq, subs_mat, gap_open_penalty, gap_extension_penalty)
    if clean:
        os.system("rm {} {} {}".format(query_file, ref_file, out_file))
    os.chdir(cur_dir)

    return {
        'reference_aligned': aln_output['subject'] if 'subject' in aln_output else None,
        'reference_start': aln_output['subject_start'] if 'subject_start' in aln_output else None,  # 1-based index where alignment starts
        'query_aligned': aln_output['query'] if 'query' in aln_output else None,
        'query_start': aln_output['query_start'] if 'query_start' in aln_output else None,  # 1-based index where alignment starts
        'score': aln_output['score'] if 'score' in aln_output else None
    }

def collect_position_map(alignments):
    position_maps = {}  # reference residue number -> [{'reference_residue':'G', 'chain_id': 'A', 'chain_residue_number': 32, 'chain_residue': 'G'}]
    for chain_id in alignments:
        aln = alignments[chain_id]
        refseq = aln['ref_aligned']
        queryseq = aln['query_aligned']
        query_resno = aln['query_residue_numbers']
        ref_idx = aln['ref_start']  # 1-based; sliding on sequence
        qry_idx = aln['query_start'] - 1  # 0-based; sliding on query_resno array
        for i, (ref, qry) in enumerate(zip(refseq, queryseq)):
            if ref != '-':
                
                if qry != '-':
                    query_res_idx = int(query_resno[qry_idx])  # must convert int64 -> int
                    # residue match in 3D structure
                    d = {
                        'reference_residue': ref,
                        'chain_id': chain_id,
                        'chain_residue_number': query_res_idx,
                        'chain_residue': qry
                    }
                    if ref_idx not in position_maps:
                        position_maps[ref_idx] = []
                    position_maps[ref_idx].append(d)
            
            # increment residue numbering
            if ref != '-':
                ref_idx += 1
            if qry != '-':
                qry_idx += 1

    # position_maps = json.dumps(position_maps, indent=4, sort_keys=True, cls=utils.NumpyEncoder)
    return position_maps


def collect_epitope_map(alignments, epitope_dict):
    epitope_maps = {}  # chain_id -> {chain_residue_number -> epitope_name}
    for chain_id in alignments:
        if chain_id not in epitope_maps:
            epitope_maps[chain_id] = {}
        aln = alignments[chain_id]
        refseq = aln['ref_aligned']
        queryseq = aln['query_aligned']
        query_resno = aln['query_residue_numbers']
        ref_idx = aln['ref_start']  # 1-based; sliding on sequence
        qry_idx = aln['query_start'] - 1  # 0-based; sliding on query_resno array
        for i, (ref, qry) in enumerate(zip(refseq, queryseq)):
            if ref != '-':
                if qry != '-':
                    query_res_idx = int(query_resno[qry_idx])  # must convert int64 -> int
                    if ref_idx in epitope_dict:
                        epitope_name = epitope_dict[ref_idx]
                        epitope_maps[chain_id][query_res_idx] = epitope_name
            # increment residue numbering
            if ref != '-':
                ref_idx += 1
            if qry != '-':
                qry_idx += 1
    return epitope_maps



def run_mafft(input_fasta, max_iter=1000, thread=4, strategy='globalpair', work_dir=None, clean=True):
    if not work_dir:
        work_dir = settings.MSA_TEMP_DIR
    cur_dir = os.getcwd()
    os.chdir(work_dir)
    output_file = os.path.join(work_dir, utils.random_filename(size=17))
    if strategy.lower() in ['global', 'globalpair', 'glob']:
        strategy_option = '--globalpair'
    elif strategy.lower() in ['local', 'localpair', 'loc']:
        strategy_option = '--localpair'
    elif strategy.lower() in ['genaf', 'genafpair', 'gen']:
        strategy_option = '--genafpair'
    else:
        strategy_option = '--globalpair'
    
    cmd = "mafft --quiet --thread {thread} --maxiterate {max_iter} {strategy} {input_fasta} > {output_file}".format(
        thread=thread, max_iter=max_iter, strategy=strategy_option, input_fasta=input_fasta, output_file=output_file
    )
    os.system(cmd)
    os.chdir(cur_dir)
    return output_file