import os
import sys
import re
import time
import numpy as np
import pandas as pd
import json
from datetime import datetime
from django.conf import settings
from proteins import utils
from proteins import models
import pymongo
from Bio import SeqIO, Seq
from proteins import sequence_alignment as sa
from nucleotides import models as nucl_models

if __name__ == "__main__":
    cli = pymongo.MongoClient(settings.MONGODB_URL)
    flu_db = cli['flu_db']