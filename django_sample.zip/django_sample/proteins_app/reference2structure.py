import os
import numpy as np
import json
import pandas as pd
from Bio import pairwise2
from Bio import SeqIO
from Bio.Align import substitution_matrices
from biotite.structure.io import pdb
from biotite import structure as bts
from django.conf import settings
from proteins import utils
from proteins import models
from proteins import structure_info as si
from proteins import sequence_alignment as sa


def get_position_map(ref_obj, pdb_object):

    chain_info = pdb_object.chain_info
    segment_chains = [c for c in chain_info if chain_info[c]['segment']]
    pdb_obj = pdb.PDBFile.read(pdb_object.pdb_file)
    pdb_structure = pdb.get_structure(pdb_obj, model=1, altloc='occupancy')
    alignments = {}
    for chain in bts.chain_iter(pdb_structure):
        aa_filt = bts.filter_amino_acids(chain)
        chain = chain[aa_filt]
        if chain.shape[0] < 1:
            continue
        num_res = bts.get_residue_count(chain)
        chain_id = chain[0].chain_id
        if chain_id not in segment_chains:
            # skip non-influenza chains, e.g. Fabs
            continue
        res = bts.get_residues(chain)
        threes = res[1]
        res_num = res[0]
        chain_seq = ''.join([utils.three2one(three).upper() for three in threes])
        aln = sa.pairwise_align(ref_seq=ref_obj.ha.sequence, query_seq=chain_seq, clean=True)
        ref_aln = aln['reference_aligned']
        chain_aln = aln['query_aligned']
        score = aln['score']  # bitscore
        d = {
            'ref_id': ref_obj.ha.accession,
            'query_pdb_id': pdb_object.pdb_id,
            'chain_id': chain_id,
            'ref_aligned': ref_aln,
            'ref_start': aln['reference_start'],
            'query_aligned': chain_aln,
            'query_start': aln['query_start'],
            'query_residue_numbers': res_num,  # 1-based residue indices in pdb file
            'score': score,
        }
        alignments[chain_id] = d

    position_map = sa.collect_position_map(alignments)
    return position_map
