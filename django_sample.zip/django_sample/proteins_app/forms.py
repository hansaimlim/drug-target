import magic
from django import forms
from django.core.exceptions import ValidationError
from django.core import validators
from django.conf import settings
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Field, Layout, Submit, Row, Column
from django.utils.deconstruct import deconstructible
from django.utils.translation import gettext_lazy as _
from django.template.defaultfilters import filesizeformat
from django_select2 import forms as s2forms
from proteins import models
from nucleotides import models as nucl_models

# https://stackoverflow.com/a/27916582
@deconstructible
class FileValidator(object):
    error_messages = {
     'max_size': "File too large %(size)s. Maximum size %(max_size)s.",
     'min_size': "File too small %(size)s. Minimum size %(min_size)s.",
     'content_type': "File type %(content_type)s not supported.",
    }

    def __init__(self, max_size=None, min_size=None, content_types=()):
        self.max_size = max_size
        self.min_size = min_size
        self.content_types = content_types

    def __call__(self, data):
        if self.max_size is not None and data.size > self.max_size:
            params = {
                'max_size': filesizeformat(self.max_size),
                'size': filesizeformat(data.size),
            }
            raise ValidationError(self.error_messages['max_size'],
                                   'max_size', params)
        if self.min_size is not None and data.size < self.min_size:
            params = {
                'min_size': filesizeformat(self.min_size),
                'size': filesizeformat(data.size)
            }
            raise ValidationError(self.error_messages['min_size'],
                                   'min_size', params)
        if self.content_types:
            content_type = magic.from_buffer(data.read(), mime=True)
            data.seek(0)
            if content_type not in self.content_types:
                params = { 'content_type': content_type }
                raise ValidationError(self.error_messages['content_type'],
                                   'content_type', params)

    def __eq__(self, other):
        return (
            isinstance(other, FileValidator) and
            self.max_size == other.max_size and
            self.min_size == other.min_size and
            self.content_types == other.content_types
        )

class DownloadForm(forms.Form):
    sequence_type_choices = [
        ('protein', 'Amino acid'),
        ('nucleotide', 'Nucleotide')
    ]
    sequence_type = forms.ChoiceField(
        label="Sequence type",
        choices=sequence_type_choices,
        required=False,
        initial='protein',
        widget=forms.RadioSelect,
    )
    segment_names = list(models.SEGMENT_MODELS.keys())
    segment_choices = [(s, s) for s in segment_names]
    segment_option = forms.MultipleChoiceField(
        label="Segment (multiselect)",
        required=False,
        widget=forms.CheckboxSelectMultiple,
        choices=segment_choices,
    )

    filename = forms.CharField(
        label="Filename (optional)",
        required=False,
        widget=forms.TextInput,
    )

    def __init__(self, *args, **kwargs):
        super(DownloadForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        # self.fields['sequence_type'].label = False
        # self.fields['segment_option'].label = False


class MSAForm(forms.Form):
    sequence_type_choices = [
        ('protein', 'Amino acid'),
        ('nucleotide', 'Nucleotide')
    ]
    sequence_type = forms.ChoiceField(
        label="Sequence type",
        choices=sequence_type_choices,
        required=False,
        initial='protein',
        widget=forms.RadioSelect,
    )
    segment_names = list(models.SEGMENT_MODELS.keys())
    segment_choices = [(s, s) for s in segment_names]
    segment_option = forms.ChoiceField(
        label="Segment",
        required=False,
        initial='HA',
        widget=forms.RadioSelect,
        choices=segment_choices,
    )

    def __init__(self, *args, **kwargs):
        super(MSAForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()


class StructureVisualizationForm(forms.Form):
    inputChoices = [
        ('justpdb', 'Just PDB structure'),
        ('upload', 'Upload HA sequence'),
        ('choice', 'Choose HA from database')
    ]
    input_option = forms.ChoiceField(
        choices=inputChoices,
        required=False,
        initial="choice",
        widget=forms.RadioSelect,
    )

    input_sequence = forms.CharField(
        required=False,
        widget=forms.Textarea
    )

    input_strain_name = forms.CharField(
        required=False,
        widget=forms.TextInput,
    )

    pdb_structure = forms.ModelChoiceField(
        queryset=models.PDBStructure.objects.all().order_by('-molecule_subtype__name'),
        required=True,
    )

    def __init__(self, *args, **kwargs):
        super(StructureVisualizationForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.fields['input_option'].label = False
        self.fields['input_sequence'].label = False
        self.fields['input_strain_name'].label = False
        self.fields['pdb_structure'].label = False


class PairwiseComparisonForm(forms.Form):

    # subtype = forms.ModelChoiceField(
    #     queryset=models.MoleculeSubtype.objects.filter(name__in=['H1', 'H3', 'B-Victoria', 'B-Yamagata', 'B-Unknown']),
    #     required=True,
    #     to_field_name='name',
    #     widget=forms.RadioSelect,
    # )
    inputChoices = [
        ('upload', 'Upload HA sequence'),
        ('choice', 'Choose HA from database')
    ]
    input_option = forms.ChoiceField(
        choices=inputChoices,
        required=False,
        initial="choice",
        widget=forms.RadioSelect,
    )

    input_sequence = forms.CharField(
        required=False,
        widget=forms.Textarea
    )

    input_strain_name = forms.CharField(
        required=False,
        widget=forms.TextInput,
    )

    vaccine = forms.ModelChoiceField(
        queryset=models.VaccineHemagglutinin.objects.all().order_by('-ha__subtype__name').order_by('-latest_vaccine_year'),
        required=True,
    )

    pdb_structure = forms.ModelChoiceField(
        queryset=models.PDBStructure.objects.all().order_by('-molecule_subtype__name'),
        required=True,
    )

    def __init__(self, *args, **kwargs):
        super(PairwiseComparisonForm, self).__init__(*args, **kwargs)
        self.helper = FormHelper()
        # self.fields['subtype'].label = False
        self.fields['input_option'].label = False
        self.fields['input_sequence'].label = False
        self.fields['vaccine'].label = False
        self.fields['input_strain_name'].label = False
        # self.fields['input_sequence_db'].label = False
        self.fields['pdb_structure'].label = False