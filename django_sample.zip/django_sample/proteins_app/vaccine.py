import os

H3N2_VACCINES = {
        "A/Sydney/5/97": {
            "name": "A/Sydney/5/1997",
            "years": [1998, 1999],
            "passage": "egg",
        },
        "A/Moscow/10/99": {
            "name": "A/Moscow/10/1999",
            "years": [2000, 2001, 2002, 2003],
            "passage": "egg",
        },
        "A/Fujian/411/2002": {
            "name": "A/Fujian/411/2002",
            "years": [2004],
            "passage": "egg",
        },
        "A/Wellington/1/2004": {
            "name": "A/Wellington/1/2004",
            "years": [2005],
            "passage": "egg",
        },
        "A/California/7/2004": {
            "name": "A/California/7/2004",
            "years": [2006],
            "passage": "egg",
        },

        "A/Wisconsin/67/2005": {
            "name": "A/Wisconsin/67/2005",
            "years": [2006, 2007],
            "passage": "egg",
        },
        "A/Brisbane/10/2007": {
            "name": "A/Brisbane/10/2007",
            "years": [2008, 2009],
            "passage": "egg",
        },

        "A/Perth/16/2009": {
            "name": "A/Perth/16/2009",
            "years": [2010, 2011],
            "passage": "egg",
        },
        "A/Victoria/361/2011": {
            "name": "A/Victoria/361/2011",
            "years": [2012],
            "passage": "egg",
        },
        "A/Texas/50/2012": {
            "name": "A/Texas/50/2012",
            "years": [2013, 2014],
            "passage": "egg",
        },
        "A/Switzerland/9715293/2013": {
            "name": "A/Switzerland/9715293/2013",
            "years": [2015],
            "passage": "egg",
        },
        "A/Hong Kong/4801/2014": {
            "name": "A/Hong Kong/4801/2014",
            "years": [2016, 2017],
            "passage": "egg",
        },
        "A/Singapore/Infimh-16-0019/2016": {
            "name": "A/Singapore/Infimh-16-0019/2016",
            "years": [2018],
            "passage": "egg",
        },
        "A/Switzerland/8060/2017": {
            "name": "A/Switzerland/8060/2017",
            "years": [2019],
            "passage": "egg",
        },
        "A/Kansas/14/2017": {
            "name": "A/Kansas/14/2017",
            "years": [2019],
            "passage": "egg",
        },
        "A/South Australia/34/2019": {
            "name": "A/South Australia/34/2019",
            "years": [2020],
            "passage": "egg",
        },
        "A/Hong Kong/2671/2019": {
            "name": "A/Hong Kong/2671/2019",
            "years": [2020],
            "passage": "egg",
        },
        "A/Hong Kong/45/2019": {
            "name": "A/Hong Kong/45/2019",
            "years": [2020],
            "passage": "cell",
        },
        "A/Cambodia/e0826360/2020": {
            "name": "A/Cambodia/e0826360/2020",
            "years": [2021, 2022],
            "passage": "egg",
            "isolate_id": "EPI_ISL_806547",
        },
        "A/Cambodia/e0826360/2020-cell": {
            "name": "A/Cambodia/e0826360/2020",
            "years": [2021, 2022],
            "passage": "cell",
            "isolate_id": "EPI_ISL_944639",
        },
        "A/Darwin/9/2021": {
            "name": "A/Darwin/9/2021",
            "years": [2022, 2023],
            "passage": "egg",
            "isolate_id": "EPI_ISL_2233240",
        },
        "A/Darwin/6/2021": {
            "name": "A/Darwin/6/2021",
            "years": [2022, 2023],
            "passage": "cell",
            "isolate_id": "EPI_ISL_3534319",
        },
}
H1N1_VACCINES = {
        "A/Beijing/262/95": {
            "name": "A/Beijing/262/95",
            "years": [1998, 1999],
            "passage": "egg"
        },
        "A/New Caledonia/20/99": {
            "name": "A/New Caledonia/20/99",
            "years": [2000, 2001, 2002, 2003, 2004, 2005, 2006],
            "passage": "egg",
        },
        "A/Solomon Islands/3/2006": {
            "name": "A/Solomon Islands/3/2006",
            "years": [2007],
            "passage": "egg",
        },
        "A/Brisbane/59/2007": {
            "name": "A/Brisbane/59/2007",
            "years": [2008, 2009],
            "passage": "egg",
        },
        "A/California/07/2009": {
            "name": "A/California/07/2009",
            "years": [2010, 2011, 2012, 2013, 2014, 2015, 2016],
            "passage": "egg",
        },
        "A/Michigan/45/2015": {
            "name": "A/Michigan/45/2015",
            "years": [2017, 2018],
            "passage": "egg",
        },
        "A/Brisbane/02/2018": {
            "name": "A/Brisbane/02/2018",
            "years": [2019],
            "passage": "egg",
        },
        "A/Guangdong-Maonan/SWL1536/2019": {
            "name": "A/Guangdong-Maonan/SWL1536/2019",
            "years": [2020],
            "passage": "egg",
        },
        "A/Hawaii/70/2019": {
            "name": "A/Hawaii/70/2019",
            "years": [2020],
            "passage": "cell",
        },
        "A/Victoria/2570/2019": {
            "name": "A/Victoria/2570/2019",
            "years": [2021, 2022],
            "passage": "egg",
            "isolate_id": "EPI_ISL_417210",
        },
        "A/Wisconsin/588/2019": {
            "name": "A/Wisconsin/588/2019",
            "years": [2021, 2022],
            "passage": "cell",
            "isolate_id": "EPI_ISL_404460",
        },
        "A/Sydney/5/2021": {
            "name": "A/Sydney/5/2021",
            "years": [2023],
            "passage": "egg",
            "isolate_id": "EPI_ISL_7458682",
        },
        "A/Sydney/5/2021-cell": {
            "name": "A/Sydney/5/2021",
            "years": [2023],
            "passage": "cell",
            "isolate_id": "EPI_ISL_8767089",
        },
}

VICTORIA_VACCINES = {
        "B/Beijing/184/1993":{
            "name": "B/Beijing/184/1993",
            "years": [1998, 1999, 2000],
            "passage": "egg",
        },
        "B/Sichuan/379/1999":{
            "name": "B/Sichuan/379/1999",
            "years": [2001],
            "passage": "egg",
        },
        "B/Hong Kong/330/2001":{
            "name": "B/Hong Kong/330/2001",
            "years": [2002, 2003],
            "passage": "egg",
        },
        "B/Shanghai/361/2002":{
            "name": "B/Shanghai/361/2002",
            "years": [2004, 2005],
            "passage": "egg",
        },
        "B/Malaysia/2506/2004": {
            "name": "B/Malaysia/2506/2004",
            "years": [2006, 2007],
            "passage": "egg",
        },
        "B/Florida/4/2006": {
            "name": "B/Florida/4/2006",
            "years": [2008],
            "passage": "egg",
        },
        "B/Brisbane/60/2008": {
            "name": "B/Brisbane/60/2008",
            "years": [2009, 2010, 2011, 2013, 2014, 2015, 2016, 2017],
            "passage": "egg",
        },
        "B/Wisconsin/01/2010": {
            "name": "B/Wisconsin/01/2010",
            "years": [2012],
            "passage": "egg",
        },
        "B/Colorado/6/2017": {
            "name": "B/Colorado/6/2017",
            "years": [2018, 2019],
            "passage": "egg",
        },
        "B/Washington/02/2019": {
            "name": "B/Washington/02/2019",
            "years": [2020, 2021],
            "passage": "egg",
            "isolate_id": "EPI_ISL_352076",
        },
        "B/Washington/02/2019-cell": {
            "name": "B/Washington/02/2019",
            "years": [2021, 2022],
            "passage": "cell",
            "isolate_id": "EPI_ISL_347829",
        },
        "B/Austria/1359417/2021": {
            "name": "B/Austria/1359417/2021",
            "years": [2022, 2023],
            "passage": "egg",
            "isolate_id": "EPI_ISL_1519459",
        },
        "B/Austria/1359417/2021-cell": {
            "name": "B/Austria/1359417/2021",
            "years": [2022, 2023],
            "passage": "cell",
            "isolate_id": "EPI_ISL_983345",
        },
        "B/Austria/1359417/2021-2": {
            "name": "B/Austria/1359417/2021",
            "years": [2023],
            "passage": "egg",
            "isolate_id": "EPI_ISL_2378894",
        }
}

YAMAGATA_VACCINES = {
        "B/Beijing/184/1993":{
            "name": "B/Beijing/184/93",
            "years": [1998, 1999, 2000],
            "passage": "egg",
        },
        "B/Sichuan/379/99":{
            "name": "B/Sichuan/379/1999",
            "years": [2001],
            "passage": "egg",
        },
        "B/Hong Kong/330/2001":{
            "name": "B/Hong Kong/330/2001",
            "years": [2002, 2003],
            "passage": "egg",
        },
        "B/Malaysia/2506/2004": {
            "name": "B/Malaysia/2506/2004",
            "years": [2006, 2007],
            "passage": "egg",
        },
        "B/Brisbane/60/2008": {
            "name": "B/Brisbane/60/2008",
            "years": [2009, 2010, 2011],
            "passage": "egg",
        },
        "B/Shanghai/361/2002": {
            "name": "B/Shanghai/361/2002",
            "years": [2004, 2005],
            "passage": "egg",
        },
        "B/Florida/4/2006": {
            "name": "B/Florida/4/2006",
            "years": [2008],
            "passage": "egg",
        },
        "B/Wisconsin/01/2010": {
            "name": "B/Wisconsin/01/2010",
            "years": [2012],
            "passage": "egg",
        },
        "B/Massachusetts/02/2012": {
            "name": "B/Massachusetts/02/2012",
            "years": [2013, 2014],
            "passage": "egg",
        },
        "B/Phuket/3073/2013": {
            "name": "B/Phuket/3073/2013",
            "years": [2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023],
            "passage": "egg",
            "isolate_id": "EPI_ISL_168822"
        },
        "B/Phuket/3073/2013-cell": {
            "name": "B/Phuket/3073/2013",
            "years": [2023],
            "passage": "cell",
            "isolate_id": "EPI_ISL_161843"
        },
        
}