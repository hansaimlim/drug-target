from django.contrib.messages.views import SuccessMessageMixin
from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic import ListView
from django.views.generic.base import TemplateView
from django.core.paginator import Paginator
from django.urls import reverse_lazy
from django.conf import settings
from django.template.defaulttags import register
from django.template.loader import render_to_string
from django.db.models import Sum, Count, Q
from django.core.mail import send_mail
from django.utils import timezone
from ajax_datatable.views import AjaxDatatableView
import os
import requests
import time
import datetime
import json
from proteins import forms
from proteins import models
from nucleotides import models as nucl_models

"""
column_defs = [{
    'name': 'currency',                 # required
    'data': None,
    'title': 'Currency',                # optional: default = field verbose_name or column name
    'visible': True,                    # optional: default = True
    'searchable': True,                 # optional: default = True if visible, False otherwise
    'orderable': True,                  # optional: default = True if visible, False otherwise
    'foreign_field': 'manager__name',   # optional: follow relation
    'm2m_foreign_field': 'manager__name',   # optional: follow m2m relation
    'placeholder': False,               # ???
    'className': 'css-class-currency',  # optional class name for cell
    'defaultContent': '<h1>test</h1>',  # ???
    'width': 300,                       # optional: controls the minimum with of each single column
    'choices': None,                    # see `Filtering single columns` below
    'initialSearchValue': None,         # see `Filtering single columns` below
    'autofilter': False,                # see `Filtering single columns` below
    'boolean': False,                   # treat calculated column as BooleanField
    'max_length': 0,                    # if > 0, clip result longer then max_length
    'lookup_field': '__icontains',      # used for searches; default: '__iexact' for columns with choices, '__icontains' in all other cases
}
"""


class IsolateView(AjaxDatatableView):
    model = models.Isolate
    title = "Isolate List"
    initial_order = [
        ["collection_date", "desc"],
    ]
    length_menu = [
        [10, 20, 50, 100, 5000], [10, 20, 50, 100, 5000],
    ]
    latest_by = 'collection_date'
    show_date_filters = True
    search_values_separator = '+'

    column_defs = [
        {'name': 'check-select', 'visible': True, 'searchable': False, 'orderable': False, 'placeholder': True, 'title': ' '},
        AjaxDatatableView.render_row_tools_column_def(),
        {'name': 'id', 'visible': False, 'searchable': False, 'orderable': True},
        {'name': 'compare_ha', 'title': 'Compare HA', 'visible': True, 'searchable': False, 'orderable': False, 'placeholder': True},
        {'name': 'accession', 'visible':True, 'title': 'ID', 'searchable':True, 'orderable': True,},
        {'name': 'name', 'visible': True, 'title': 'Name', 'searchable': True, 'orderable': True},
        {'name': 'clade', 'visible': True, 'title': 'Clade', 
            'searchable': True, 'orderable': True, 'foreign_field': 'clade__full_name', 
            'choices': True, 'autofilter': True},
        {'name': 'passaged', 'visible': True, 'title': 'Passaged', 
            'searchable': True, 'orderable': True, 'foreign_field': 'passage__is_passaged',
            'choices': True, 'autofilter': True,
        },
        {'name': 'egg_passaged', 'visible': True, 'title': 'Egg-passaged', 
            'searchable': True, 'orderable': True, 'foreign_field': 'passage__is_egg_passaged',
            'choices': True, 'autofilter': True,
        },
        {'name': 'cell_passaged', 'visible': True, 'title': 'Cell-passaged', 
            'searchable': True, 'orderable': True, 'foreign_field': 'passage__is_cell_passaged',
            'choices': True, 'autofilter': True,
        },
        {'name': 'subtype', 'visible': True, 'title': 'Isolate Subtype',
            'searchable': True, 'orderable': True, 'foreign_field': 'subtype__name',
            'choices': True, 'autofilter': True,
        },
        {'name': 'lineage', 'visible': True, 'title': 'Lineage', 
            'searchable': True, 'orderable': True, 'foreign_field': 'lineage__name',
            'choices': True, 'autofilter': True,
        },
        {'name': 'continent', 'visible': True, 'title': 'Continent',
            'searchable': True, 'orderable': True, 'foreign_field': 'continent__name',
            'choices': True, 'autofilter': True,
        },
        {'name': 'collection_date', 'title': 'Collection Date', 'visible': True, 'searchable': False, 'orderable': True},
    ]

    def customize_row(self, row, obj):
        isolate_name = obj.name
        hemagglutinin = models.Hemagglutinin.objects.filter(isolate=obj).first()
        row['check-select'] = '<div class="form-check ms-2"><input class="form-check-input select-one" type="checkbox" value="" data-pk="{pk}" id="checkbox-isolate-{pk}"></div>'.format(pk=obj.pk)
        if (not hemagglutinin) or (not hemagglutinin.subtype):
            submit_url = '#'
            row['compare_ha'] = '<a href={} class="btn btn-sm btn-outline-primary disabled">N/A &nbsp;<i class="fa-solid fa-ban"></i></a>'.format(submit_url)
        elif (hemagglutinin.subtype.name in ['H1', 'H3']) or (hemagglutinin.subtype.name.startswith('B')):
            # valid ha subtype
            submit_url = reverse_lazy('proteins:submit_pairwise_alignment_name', kwargs={'name':obj.accession})
            row['compare_ha'] = '<a href={} class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-code-compare"></i>&nbsp;Compare</a>'.format(submit_url)
        else:
            submit_url = '#'
            row['compare_ha'] = '<a href={} class="btn btn-sm btn-outline-primary disabled">N/A &nbsp;<i class="fa-solid fa-ban"></i></a>'.format(submit_url)

    def render_row_details(self, pk, request=None):
        obj = self.model.objects.get(pk=pk)
        hemagglutinin = models.Hemagglutinin.objects.filter(isolate=obj).first()
        ha_sequence = [hemagglutinin.sequence[i:i+100] for i in range(0,len(hemagglutinin.sequence),100)] if hemagglutinin else None
        neuraminidase = models.Neuraminidase.objects.filter(isolate=obj).first()
        na_sequence = [neuraminidase.sequence[i:i+100] for i in range(0,len(neuraminidase.sequence),100)] if neuraminidase else None

        ha_nucl = nucl_models.Hemagglutinin.objects.filter(isolate=obj).first()
        ha_nucl_seq = [ha_nucl.sequence[i:i+100] for i in range(0,len(ha_nucl.sequence),100)] if ha_nucl else None
        na_nucl = nucl_models.Neuraminidase.objects.filter(isolate=obj).first()
        na_nucl_seq = [na_nucl.sequence[i:i+100] for i in range(0,len(na_nucl.sequence),100)] if na_nucl else None
        template_name = 'ajax_datatable/proteins/isolate_details.html'

        ctx = {
            'isolate': obj,
            'hemagglutinin': hemagglutinin,
            'ha_sequence': ha_sequence,
            'neuraminidase': neuraminidase,
            'na_sequence': na_sequence,
            'ha_nt': ha_nucl,
            'na_nt': na_nucl,
            'ha_nt_sequence': ha_nucl_seq,
            'na_nt_sequence': na_nucl_seq,
        }
        return render_to_string(template_name, ctx)


class HemagglutininView(AjaxDatatableView):
    model = models.Hemagglutinin
    title = "Hemagglutinin List"
    initial_order = [
        ["collection_date", "desc"],
    ]

    length_menu = [
        [10, 20, 50, 100, 5000], [10, 20, 50, 100, 5000],
    ]
   
    search_values_separator = '+'
    column_defs = [
        AjaxDatatableView.render_row_tools_column_def(),
        {'name': 'id', 'visible': False, 'searchable': False, 'orderable': True},
        {'name': 'compare_ha', 'title': 'Compare HA', 'visible': True, 'searchable': False, 'orderable': False, 'placeholder': True},
        {'name': 'accession', 'visible':True, 'title': 'ID', 'searchable':True, 'orderable': True,},
        {'name': 'name', 'visible': True, 'title': 'Name', 'searchable': True, 'orderable': True,
            'foreign_field': 'isolate__name',
        },
        {'name': 'clade', 'visible': True, 'title': 'Clade', 
            'searchable': True, 'orderable': True, 'foreign_field': 'isolate__clade__full_name', 
            'choices': True, 'autofilter': True,},
        # {'name': 'passage', 'visible': True, 'title': 'Passage', 
        #     'searchable': True, 'orderable': True, 'foreign_field': 'isolate__passage__standardized_name',
        #     'choices': True, 'autofilter': True,
        # },
        {'name': 'subtype', 'visible': True, 'title': 'HA Subtype', 
            'searchable': True, 'orderable': True, 'foreign_field': 'subtype__name',
            'choices': True, 'autofilter': True,
        },
        {'name': 'collection_date', 'title': 'Collection Date', 'visible': True, 
            'searchable': False, 'orderable': True,
            'foreign_field': 'isolate__collection_date'
        },
    ]

    def customize_row(self, row, obj):
        if not obj.subtype:
            submit_url = '#'
            row['compare_ha'] = '<a href={} class="btn btn-sm btn-outline-primary disabled">N/A &nbsp;<i class="fa-solid fa-ban"></i></a>'.format(submit_url)

        elif (obj.subtype.name in ['H1', 'H3']) or (obj.subtype.name.startswith('B')):
            # valid ha subtype
            submit_url = reverse_lazy('proteins:submit_pairwise_alignment_name', kwargs={'name':obj.accession})
            row['compare_ha'] = '<a href={} class="btn btn-sm btn-outline-primary"><i class="fa-solid fa-code-compare"></i>&nbsp;Compare</a>'.format(submit_url)
        else:
            submit_url = '#'
            row['compare_ha'] = '<a href={} class="btn btn-sm btn-outline-primary disabled">N/A &nbsp;<i class="fa-solid fa-ban"></i></a>'.format(submit_url)


    def render_row_details(self, pk, request=None):
        hemagglutinin = self.model.objects.get(pk=pk)
        isolate = hemagglutinin.isolate
        ha_sequence = [hemagglutinin.sequence[i:i+100] for i in range(0,len(hemagglutinin.sequence),100)] if hemagglutinin else None
        ha_nucl = nucl_models.Hemagglutinin.objects.filter(isolate=isolate).first()
        ha_nucl_seq = [ha_nucl.sequence[i:i+100] for i in range(0,len(ha_nucl.sequence),100)] if ha_nucl else None

        template_name = 'ajax_datatable/proteins/ha_details.html'
        ctx = {
            'isolate': isolate,
            'hemagglutinin': hemagglutinin,
            'ha_sequence': ha_sequence,
            'ha_nt': ha_nucl,
            'ha_nt_sequence': ha_nucl_seq,
        }
        return render_to_string(template_name, ctx)


class NeuraminidaseView(AjaxDatatableView):
    model = models.Neuraminidase
    title = "Neuraminidase List"
    initial_order = [
        ["collection_date", "desc"],
    ]

    length_menu = [
        [10, 20, 50, 100, 5000], [10, 20, 50, 100, 5000],
    ]
   
    search_values_separator = '+'
    column_defs = [
        AjaxDatatableView.render_row_tools_column_def(),
        {'name': 'id', 'visible': False, 'searchable': False, 'orderable': True},
        {'name': 'accession', 'visible':True, 'title': 'ID', 'searchable':True, 'orderable': True,},
        {'name': 'name', 'visible': True, 'title': 'Name', 'searchable': True, 'orderable': True,
            'foreign_field': 'isolate__name',
        },
        {'name': 'clade', 'visible': True, 'title': 'Clade', 
            'searchable': True, 'orderable': True, 'foreign_field': 'isolate__clade__full_name', 
            'choices': True, 'autofilter': True,},
        # {'name': 'passage', 'visible': True, 'title': 'Passage', 
        #     'searchable': True, 'orderable': True, 'foreign_field': 'isolate__passage__standardized_name',
        #     'choices': True, 'autofilter': True,
        # },
        {'name': 'subtype', 'visible': True, 'title': 'NA Subtype', 
            'searchable': True, 'orderable': True, 'foreign_field': 'subtype__name',
            'choices': True, 'autofilter': True,
        },
        {'name': 'collection_date', 'title': 'Collection Date', 'visible': True, 
            'searchable': False, 'orderable': True,
            'foreign_field': 'isolate__collection_date'
        },
    ]

    def render_row_details(self, pk, request=None):
        neuraminidase = self.model.objects.get(pk=pk)
        isolate = neuraminidase.isolate
        na_sequence = [neuraminidase.sequence[i:i+100] for i in range(0,len(neuraminidase.sequence),100)] if neuraminidase else None

        na_nucl = nucl_models.Neuraminidase.objects.filter(isolate=isolate).first()
        na_nucl_seq = [na_nucl.sequence[i:i+100] for i in range(0,len(na_nucl.sequence),100)] if na_nucl else None

        template_name = 'ajax_datatable/proteins/na_details.html'
        ctx = {
            'isolate': isolate,
            'neuraminidase': neuraminidase,
            'na_sequence': na_sequence,
            'na_nt': na_nucl,
            'na_nt_sequence': na_nucl_seq,
        }
        return render_to_string(template_name, ctx)