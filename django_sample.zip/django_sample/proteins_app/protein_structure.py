import os
import numpy as np
from biotite import structure as bts
from proteins import utils

def compute_euclidean_distance(coord1, coord2):
    """Calculate euclidean distance."""
    dist = np.linalg.norm(
        np.array(coord1, dtype=np.float32) - np.array(coord2, dtype=np.float32))
    return dist


def compute_sasa(atomarray, probe_radius=1.4, point_number=1000, ignore_ions=True):
    """
    Using Biotite, compute residue-wise solvent-accessible surface area (SASA)
    Also, compute relative sasa in percent scale based on standard SASA
    """
    aa_filt = bts.filter_amino_acids(atomarray)
    atomarray = atomarray[aa_filt]
    sasa_per_atom = bts.sasa(
        atomarray, probe_radius=probe_radius, point_number=point_number, ignore_ions=ignore_ions
    )
    sasa_per_res = bts.apply_residue_wise(atomarray, sasa_per_atom, np.nansum)
    sasa_per_res = bts.spread_residue_wise(atomarray, sasa_per_res)

    sasa_dict = {}  # chain_id -> {res_id: sasa}
    rel_sasa_dict = {}  # chain_id -> {res_id: relsasa}

    for atom, sasa in zip(atomarray, sasa_per_res):
        sasa = float(sasa)
        chain_id = str(atom.chain_id)
        res_id = int(atom.res_id)
        if chain_id not in sasa_dict:
            sasa_dict[chain_id] = {}
        if chain_id not in rel_sasa_dict:
            rel_sasa_dict[chain_id] = {}

        standard_sasa = utils.get_standard_asa(atom.res_name)
        if standard_sasa:
            rel_sasa = 100.0 * (sasa / standard_sasa)
        else:
            rel_sasa = None
        sasa_dict[chain_id][res_id] = sasa
        rel_sasa_dict[chain_id][res_id] = rel_sasa


    return {
        'sasa_dict': sasa_dict,
        'rel_sasa_dict': rel_sasa_dict,
    }



def is_in_contact(res, atomarray, padding=0.5):
    # check if any atom in residue is in contact with any atom in atomarray
    for atom in res:
        vdw_dict1 = utils.get_extended_vdw_radii(resName=atom.res_name)
        atom_vdw = vdw_dict1.get(atom.atom_name, None)
        if not atom_vdw:
            continue
        for atom2 in atomarray:
            vdw_dict2 = utils.get_extended_vdw_radii(resName=atom2.res_name)
            atom2_vdw = vdw_dict2.get(atom2.atom_name, None)
            if not atom2_vdw:
                continue
            dist = compute_euclidean_distance(atom.coord, atom2.coord)
            if dist <= (atom_vdw+atom2_vdw+padding):
                return True
    return False


def compute_center_of_mass_residue(atomarray, res_name=None):
    """Calculate center of mass for the given RESIDUE.
    Input atomarray for single residue.
    """
    AtomDict = {
          'ACE':['CA'], 'ALA':['CB'], 'GLY':['CA'], 'SER':['OG'],
          'ASN':['OD1', 'ND2'], 'ASP':['OD1', 'OD2'], 'CYS':['SG'],
          'PRO':['CB', 'CG', 'CD'], 'THR':['OG1'], 'VAL':['CG1','CG2'],
          'ARG':['NE', 'NH1', 'NH2'], 'GLN':['OE1', 'NE2'],
          'GLU':['OE1', 'OE2'], 'HIS':['CG', 'ND1', 'CD2', 'CE1', 'NE2'],
          'ILE':['CD1'], 'LEU':['CD1', 'CD2'], 'LYS':['NZ'],
          'MET':['SD'], 'PHE':['CG', 'CD1', 'CD2', 'CE1', 'CE2', 'CZ'],
          'TRP':['CD1', 'CD2', 'NE1', 'CE2', 'CE3', 'CZ2', 'CZ3', 'CH2'],
          'TYR':['CG', 'CD1', 'CD2', 'CE1', 'CE2', 'CZ', 'OH']}
    if res_name is None:
        res_name = getattr(atomarray[0], 'res_name')
    Ca_atom = atomarray[atomarray.atom_name == "CA"]
    Ca_coord = Ca_atom.coord
    total_coords = np.array([0.0, 0.0, 0.0], dtype=np.float32)
    atom_count = 0
    if res_name in AtomDict:
        target_atoms = AtomDict[res_name]
    else:
        return Ca_coord
    for atom in atomarray:
        atom_name = getattr(atom, 'atom_name')
        if atom_name in target_atoms:
            total_coords += atom.coord
            atom_count += 1
    if atom_count > 0:
        final_coords = total_coords / atom_count
    else:
        final_coords = Ca_coord

    return final_coords


def compute_residue_pair_potential(residue, target_residues, com_dist_max=7.0, res_id_diff=4):
    """Compute residue pair potential for each residue in interface.
    interface_residue_ids: list of residue ids in interface; [interacting_residue_ids] + [nearby_residue_ids]
    For each pair of residues:
        if |res_id1 - res_id2| >= res_id_diff  # sequentially distant
        and if com_dist(res1, res2) <= com_dist_max  # spatially close
        compute pairpot(res1, res2)
    Returns list of (res_id, 3-letter-code, sum-pair-potential)
    residue = {'chain_id': atom.chain_id, 'res_id': atom.res_id, 'res_name': atom.res_name, 'atomarray': res, 'com': compute_center_of_mass_residue(res)}
    """
    chain_id = residue['chain_id']
    res_id = residue['res_id']
    res_name = residue['res_name']
    res_com = residue['com'] # center-of-mass
    pair_pot = 0.0

    for tr in target_residues:
        target_chain_id = tr['chain_id']
        target_res_id = tr['res_id']
        target_res_com = tr['com']
        target_res_name = tr['res_name']
        if target_chain_id == chain_id:
            # on the same chain; must be sequentially distant
            if np.absolute(res_id - target_res_id) < res_id_diff:
                # too close on the same chain
                continue
        if compute_euclidean_distance(res_com, target_res_com) > com_dist_max:
            # spatially too distant
            continue

        # pairs of residues that are sequentially distant but spatially close
        # compute pair potential
        pair_pot += utils.get_residue_pair_potential(res_name, target_res_name)
    return pair_pot


def collect_residue_pair_potential(all_residues, com_dist_max=7.0, res_id_diff=4):
    # all_residues: {'chain_id':chain_id, 'res_id': res_id, 'res_name': res_name, 'com': center-of-mass}
    pair_pot_dict = {}
    target_residues = {}
    for i, r in enumerate(all_residues):
        chain_id = r['chain_id']
        res_id = r['res_id']
        res_name = r['res_name']
        if chain_id not in target_residues:
            target_residues[chain_id] = {}
        if (res_id,res_name) not in target_residues[chain_id]:
            target_residues[chain_id][(res_id,res_name)] = []
        
        com = r['com']
        for j, r2 in enumerate(all_residues):
            if j <= i:
                continue
            com2 = r2['com']
            chain_id2 = r2['chain_id']
            res_id2 = r2['res_id']
            if chain_id == chain_id2:
                # must be sequentially apart
                if np.absolute(res_id - res_id2) < res_id_diff:
                    continue
                if compute_euclidean_distance(com, com2) <= com_dist_max:
                    target_residues[chain_id][(res_id,res_name)].append(r2)
            else:
                if compute_euclidean_distance(com, com2) <= com_dist_max:
                    target_residues[chain_id][(res_id,res_name)].append(r2)

    for chain_id in target_residues:
        pair_pot_dict[chain_id] = {}
        for (res_id,res_name) in target_residues[chain_id]:
            targets = target_residues[chain_id][(res_id,res_name)]
            pair_pot = 0.0
            for t in targets:
                pair_pot += utils.get_residue_pair_potential(res_name, t['res_name'])
            pair_pot_dict[chain_id][res_id] = pair_pot
    return pair_pot_dict
