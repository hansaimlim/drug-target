from django.urls import path, reverse_lazy
from proteins import views
from proteins import ajax_views
from proteins import ajax_datatable_views
from django.views.generic import TemplateView

app_name = 'proteins'
urlpatterns = [
    path('', views.MainView.as_view(), name='home'),
    path('submit_pairwise_alignment', views.SubmitPairwiseAlignmentView.as_view(), name='submit_pairwise_alignment'),
    path('submit_structure_visualization', views.SubmitStructureVisualizationView.as_view(), name='submit_structure_visualization'),
    path('submit_pairwise_alignment/<str:name>', views.SubmitPairwiseAlignmentView.as_view(), name='submit_pairwise_alignment_name'),
    path('pairwise_hemagglutinin_alignment', views.PairwiseAlignmentStructureView.as_view(), name='visualize_pairwise_alignment'),
    path('hemagglutinin_structure', views.HemagglutininStructureView.as_view(), name='hemagglutinin_3d_structure'),
    path('isolates', views.IsolateView.as_view(), name='isolates'),
    path('hemagglutinins', views.HemagglutininView.as_view(), name='hemagglutinins'),
    path('neuraminidases', views.NeuraminidaseView.as_view(), name='neuraminidases'),

    # ajax
    # path('ajax/subtype-changed', ajax_views.subtype_updated, name='ajax_subtype_changed'),
    path('ajax/isolate_id_changed', ajax_views.isolate_id_changed, name='ajax_isolate_id_changed'),
    path('ajax/subtype_changed', ajax_views.subtype_changed, name='ajax_subtype_changed'),
    # path('ajax/download_sequences', ajax_views.download_sequences, name='ajax_download_sequences'),
    path('ajax_datatable/isolates/', ajax_datatable_views.IsolateView.as_view(), name="ajax_datatable_isolates"),
    path('ajax_datatable/hemagglutnins/', ajax_datatable_views.HemagglutininView.as_view(), name="ajax_datatable_hemagglutnins"),
    path('ajax_datatable/neuraminidases/', ajax_datatable_views.NeuraminidaseView.as_view(), name="ajax_datatable_neuraminidases"),

    # download
    
]
