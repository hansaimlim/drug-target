import os
import re
import numpy as np
import pandas as pd
import json


EPITOPES = {
    # epitopes defined for Hemagglutinin HA1
    'H1': {
        'reference_article': "Anderson, C.S., McCall, P.R., Stern, H.A. et al. Antigenic cartography of H1N1 influenza viruses using sequence-based antigenic distance calculation. BMC Bioinformatics 19, 51 (2018). https://doi.org/10.1186/s12859-018-2042-4",
        'reference_id': 'EPI351614',  # EPI_ISL_102493|A/MDCK/Germany/[A/Puerto Rico/8/1934]-RKI-V4genzel2010 (H1N1)? 
        'epitopes' : {
            'Sa': [141, 142, 170, 171, 172, 173, 174, 176, 177, 178 , 179, 180, 181],
            'Sb': list(range(201, 213)),
            'Ca1': list(range(183, 188)) + list(range(220, 223)) + list(range(252, 255)),
            'Ca2': list(range(154, 160)) + [238, 239],
            'Cb': list(range(87, 93)),
        },
    },
    'H3': {
        'reference_article': "Lee, M., & Chen, J. S. (2004). Predicting Antigenic Variants of Influenza A/H3N2 Viruses. Emerging Infectious Diseases, 10(8), 1385-1390. https://doi.org/10.3201/eid1008.040107",
        'reference_id': 'EPI128425',  # EPI_ISL_236|A/Aichi/2/1968
        'epitopes': {
            'A': [122, 124, 126, 130, 131, 132, 133, 135, 137, 138, 140, 142, 143, 144, 145, 146, 150, 152, 168],
            'B': [128, 129] + list(range(155, 161)) + [163, 164, 165] + list(range(186, 191)) + [192, 193, 194, 196, 197, 198],
            'C': list(range(44,49)) + [50, 51, 53, 54, 273, 275, 276, 278, 279, 280, 294, 297, 299, 300, 304, 305, 307, 308, 309, 310, 311, 312],
            'D': [96, 102, 103, 117, 121, 167] + list(range(170, 178)) + [179, 182, 201, 203, 207, 208, 209] + list(range(212, 221)) + list(range(226, 231)) + [238, 240, 242, 244, 246, 247, 248],
            'E': [57, 59, 62, 63, 67, 75, 78] + list(range(80, 84)) + [86, 87, 88, 91, 92, 94, 109, 260, 261, 262, 265],
        },
    },
    'B':  {
        'reference_article': "Wang Q, Cheng F, Lu M, Tian X, Ma J. Crystal structure of unliganded influenza B virus hemagglutinin. J Virol. 2008 Mar;82(6):3011-20. doi: 10.1128/JVI.02477-07. Epub 2008 Jan 9. PMID: 18184701; PMCID: PMC2259021.",
        'reference_id': 'EPI129451',  # EPI_ISL_11429|B/Hong_Kong/8/1973|B_/_H0N0||Yamagata|1973-01-01|EPI129451|HA
        'epitopes': {
            '120-loop': list(range(116, 138)),
            '150-loop': list(range(141, 151)),
            '160-loop': list(range(162, 168)),
            '190-helix': list(range(194, 203)),
        }
    }
}

def check_reference_name(refname):
    if refname.lower().startswith('b'):
        ep = EPITOPES['B']
    elif refname.lower().startswith('h1'):
        ep = EPITOPES['H1']
    elif refname.lower().startswith('h3'):
        ep = EPITOPES['H3']
    else:
        ep = None
    return ep
    

def get_epitope_dict_for_reference(refname):
    ep = check_reference_name(refname)['epitopes']
    if not ep:
        return None
    epi_dict = {}
    for epi_name in ep:
        indices = ep[epi_name]
        for i in indices:
            epi_dict[i] = epi_name  # e.g. 122->'A' for H3; 118->'120-loop' for B
    return epi_dict


def get_epitope_reference_id(refname):
    ep = check_reference_name(refname)
    if not ep:
        return None
    return ep['reference_id']  # HA molecule ID
