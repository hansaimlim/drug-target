from django.contrib.messages.views import SuccessMessageMixin
from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.views.generic import ListView
from django.views.generic.base import TemplateView
from django.core.paginator import Paginator
from django.urls import reverse_lazy
from django.conf import settings
from django.template.defaulttags import register
from django.db.models import Sum, Count, Q
from django.utils import timezone
from django.core.mail import send_mail, mail_admins
from django.http.response import HttpResponse
from django.http import HttpResponseRedirect
from django.contrib import messages
from django.utils.safestring import mark_safe
import os
import re
import requests
import time
import datetime
import json
from collections import Counter
from proteins import models
from proteins import forms
from proteins import sequence_alignment as sa
from proteins import structure_info as si
from proteins import reference2structure as ref2pdb
from annotations import models as annot_models
from nucleotides import models as nucl_models
from annotations import glycosylation as glyc
from bootstrap_datepicker_plus.widgets import DatePickerInput
# Create your views here.

@register.filter(name='get_value', is_safe=True)
def get_value(dictionary, key):
    return dictionary.get(key, None)

@register.filter(name='get_value_force_str', is_safe=True)
def get_value_force_str(dictionary, key):
    return dictionary.get(str(key), None)

class MainView(TemplateView):
    template_name = 'main.html'



class SubmitPairwiseAlignmentView(TemplateView):
    template_name = 'proteins/submit_pairwise_comparison.html'

    def get(self, request, name=None):
        if name:
            form = forms.PairwiseComparisonForm(
                initial={'input_option':'choice', 'input_strain_name':name}
            )
        else:
            print("variable 'name' not provided")
            form = forms.PairwiseComparisonForm()
        ctx = {
            'form': form,
        }
        return render(request, self.template_name, ctx)



class SubmitStructureVisualizationView(TemplateView):
    template_name = 'proteins/submit_structure_visualization.html'

    def get(self, request):
        form = forms.StructureVisualizationForm()
        ctx = {
            'form': form,
        }
        return render(request, self.template_name, ctx)


class HemagglutininStructureView(TemplateView):
    template_name = 'proteins/hemagglutinin_structure.html'

    def get(self, request):
        ctx = {}
        form = forms.StructureVisualizationForm(request.POST, request.FILES or None)
        if form.is_valid():
            structure_obj = form.cleaned_data.get('pdb_structure')  # pdb_structure
            reference_obj = models.ReferenceHemagglutinin.objects.filter(reference_name=si.STRUCTURE2REFERENCENAME[structure_obj.pdb_id]).first()
            alignment_obj = models.ReferenceHemagglutininStructureAligned.objects.filter(structure=structure_obj).filter(reference=reference_obj).first()
            if alignment_obj is None:
                # reference-structure alignment is missing
                position_map = ref2pdb.get_position_map(reference_obj, structure_obj)
                alignment_obj, created = models.ReferenceHemagglutininStructureAligned.objects.get_or_create(
                    reference=reference_obj, structure=structure_obj, position_map=position_map
                )
            ha_chain_ids = [c for c in structure_obj.chain_info if structure_obj.chain_info.get(c,{'segment':''})['segment'].lower() == 'ha']
            position_map = alignment_obj.position_map
            sorted_ref_idxs = list(sorted([int(idx) for idx in position_map]))
            ha_positions = []
            
            for ref_idx in sorted_ref_idxs:
                pmaps = position_map.get(str(ref_idx),[])
                d = {
                    'ref_idx' : ref_idx,
                    'selector': ' or '.join(["{}:{}".format(pr['chain_residue_number'], pr['chain_id']) for pr in pmaps if pr['chain_id'] in ha_chain_ids]),
                    'chain_residue': None,
                    'reference_residue': None,
                    'chain_residue_number': None,
                    'rel_sasa': None,
                    'sasa': None,
                    'pair_potential': None,
                }
                if d['selector'].strip() == '':
                    d['selector'] = None
                for pmap in pmaps:
                    # print(pmap)
                    if pmap['chain_id'] in ha_chain_ids:
                        d['chain_residue'] = pmap['chain_residue']
                        d['reference_residue'] = pmap['reference_residue']
                        d['chain_residue_number'] = pmap['chain_residue_number']
                        d['rel_sasa'] = structure_obj.relative_sasa.get(str(pmap['chain_residue_number']), None)
                        d['sasa'] = structure_obj.sasa.get(str(pmap['chain_residue_number']), None)
                        d['pair_potential'] = structure_obj.pair_potential.get(str(pmap['chain_residue_number']), None)
                ha_positions.append(d)
            ha_positions_rows = {row_idx:ha_positions[i:i+100] for row_idx, i in enumerate(range(0, len(ha_positions), 100))}
            ctx = {
                'pdb_file': structure_obj.pdb_file.replace(settings.MEDIA_ROOT, '/media'),
                'structure_obj': structure_obj,
                'chain_info': structure_obj.chain_info,
                'position_map': alignment_obj.position_map,
                'ha_positions': ha_positions,
                'ha_positions_rows': ha_positions_rows,
            }
            # print(ha_positions_rows)
        else:
            messages.error(request, mark_safe("<strong>Please fix the issues in the form.</strong>"))
            return redirect("proteins:submit_structure_visualization")
        return render(request, self.template_name, ctx)

    def post(self, request):
        form = forms.StructureVisualizationForm(request.POST, request.FILES or None)
        aa_pattern = re.compile("[A-Z]+")
        if form.is_valid():
            input_option = form.cleaned_data.get('input_option') # upload or choose
            input_sequence = form.cleaned_data.get('input_sequence')  # sequence text
            if input_option.lower() == 'justpdb':
                structure_obj = form.cleaned_data.get('pdb_structure')  # pdb_structure
                reference_obj = models.ReferenceHemagglutinin.objects.filter(reference_name=si.STRUCTURE2REFERENCENAME[structure_obj.pdb_id]).first()
                alignment_obj = models.ReferenceHemagglutininStructureAligned.objects.filter(structure=structure_obj).filter(reference=reference_obj).first()
                if alignment_obj is None:
                    # reference-structure alignment is missing
                    position_map = ref2pdb.get_position_map(reference_obj, structure_obj)
                    alignment_obj, created = models.ReferenceHemagglutininStructureAligned.objects.get_or_create(
                        reference=reference_obj, structure=structure_obj, position_map=position_map
                    )
                ha_chain_ids = [c for c in structure_obj.chain_info if structure_obj.chain_info.get(c,{'segment':''})['segment'].lower() == 'ha']
                position_map = alignment_obj.position_map
                sorted_ref_idxs = list(sorted([int(idx) for idx in position_map]))
                ha_positions = []
                for ref_idx in sorted_ref_idxs:
                    pmaps = position_map.get(str(ref_idx),[])
                    d = {
                        'index_line': '|' if (ref_idx % 10) == 0 else None,
                        'query_idx': ref_idx,
                        'query_residue': None,
                        'ref_idx' : ref_idx,
                        'selector': ' or '.join(["{}:{}".format(pr['chain_residue_number'], pr['chain_id']) for pr in pmaps if pr['chain_id'] in ha_chain_ids]),
                        'chain_residue': None,
                        'reference_residue': None,
                        'chain_residue_number': None,
                        'rel_sasa': None,
                        'sasa': None,
                        'pair_potential': None,
                    }
                    if d['selector'].strip() == '':
                        d['selector'] = None
                    for pmap in pmaps:
                        # print(pmap)
                        if pmap['chain_id'] in ha_chain_ids:
                            d['chain_id'] = pmap['chain_id']
                            d['chain_residue'] = pmap['chain_residue']
                            d['reference_residue'] = pmap['reference_residue']
                            d['query_residue'] = pmap['reference_residue']
                            d['chain_residue_number'] = pmap['chain_residue_number']
                            d['rel_sasa'] = structure_obj.relative_sasa.get(str(pmap['chain_residue_number']), None)
                            d['sasa'] = structure_obj.sasa.get(str(pmap['chain_residue_number']), None)
                            d['pair_potential'] = structure_obj.pair_potential.get(str(pmap['chain_residue_number']), None)
                    ha_positions.append(d)
                ha_positions_rows = {row_idx:ha_positions[i:i+100] for row_idx, i in enumerate(range(0, len(ha_positions), 100))}
                ctx = {
                    'input_option_text': input_option.lower(),
                    'input_sequence_id': None,
                    'pdb_file': structure_obj.pdb_file.replace(settings.MEDIA_ROOT, '/media'),
                    'structure_obj': structure_obj,
                    'chain_info': structure_obj.chain_info,
                    'position_map': alignment_obj.position_map,
                    'ha_positions': ha_positions,
                    'ha_positions_rows': ha_positions_rows,
                }
                return render(request, self.template_name, ctx)
            elif input_option.lower() == 'upload':
                # get sequence from user-input
                input_sequence_lines = input_sequence.splitlines()
                if input_sequence_lines[0].startswith('>'):
                    # input_id provided
                    input_sequence_id = input_sequence_lines[0].replace('>','').split('|')[0]
                    input_sequence = ''.join(input_sequence_lines[1:])
                else:
                    input_sequence_id = None
                    input_sequence = ''.join(input_sequence_lines)
                input_clade = "Unknown"
                input_glyc_sites = glyc.find_glycosylation_sites(input_sequence)
                if not aa_pattern.fullmatch(input_sequence):
                    # sequence contains wrong characters
                    messages.error(request, mark_safe("<strong>Non-standard amino acid found in sequence. It cannot be aligned.</strong>"))
                    return redirect("proteins:submit_structure_visualization")
            elif input_option.lower() == 'choice':
                # get sequence from db
                input_strain_name = form.cleaned_data.get('input_strain_name').strip().lstrip()  # ''
                input_ha = models.Hemagglutinin.objects.filter(
                    Q(accession__iexact=input_strain_name) |
                    Q(isolate__accession__iexact=input_strain_name) |
                    Q(isolate__name__iexact=input_strain_name)
                )
                if input_ha.count() == 0:
                    # input sequence not found in db
                    messages.error(request, mark_safe("<strong>Could not find {} from the database.</strong><br />Some isolate names contain leading-0s or underscores instead of spaces, for example, <code>A/North_Carolina/02/2021</code> instead of <code>A/North Carolina/2/2021</code>.<br />If molecule ID is available, please use it <code>(e.g. EPI1942772)</code>. Otherwise, please paste amino acid sequence using <strong>'upload sequence' mode.</strong>".format(input_strain_name)))
                    return redirect("proteins:submit_structure_visualization")
                else:
                    input_ha = input_ha.first()
                    input_sequence = input_ha.sequence
                    input_sequence_id = input_strain_name
                    if input_ha.isolate.clade:
                        input_clade = input_ha.isolate.clade.full_name
                    else:
                        input_clade = "Unknown"
                    glycs = annot_models.HemagglutininGlycosylationSite.objects.filter(protein=input_ha).first()
                    if glycs:
                        input_glyc_sites = glycs.protein_sites
                    else:
                        input_glyc_sites = None

            input_sequence_count_x = input_sequence.count('X')
            if (input_sequence_count_x >= 10) or ((input_sequence_count_x/len(input_sequence))>0.02):
                messages.warning(request, mark_safe("<strong>Warning: input sequence is of low quality, containing {} unknown amino acid 'X'.</strong>".format(input_sequence_count_x)))

            structure_obj = form.cleaned_data.get('pdb_structure')  # pdb_structure
            reference_obj = models.ReferenceHemagglutinin.objects.filter(reference_name=si.STRUCTURE2REFERENCENAME[structure_obj.pdb_id]).first()
            alignment_obj = models.ReferenceHemagglutininStructureAligned.objects.filter(structure=structure_obj).filter(reference=reference_obj).first()
            alignment_input_ref = sa.pairwise_align(ref_seq=reference_obj.ha.sequence, query_seq=input_sequence)
            if alignment_obj is None:
                # reference-structure alignment is missing
                position_map = ref2pdb.get_position_map(reference_obj, structure_obj)
                alignment_obj, created = models.ReferenceHemagglutininStructureAligned.objects.get_or_create(
                    reference=reference_obj, structure=structure_obj, position_map=position_map
                )

            egg_adaptation_sites = annot_models.EggAdaptationEnrichmentScore.objects.filter(subtype=reference_obj.ha.subtype).filter(score__gte=0.5)
            egg_adaptation_dict = {
                (e.position, e.amino_acid):{
                    'score':e.score, 'count_original': e.count_original,
                    'count_cell': e.count_cell, 'count_egg': e.count_egg,
                    'position': e.position, 'amino_acid': e.amino_acid,
                } 
                for e in egg_adaptation_sites
            }
            egg_adaptation_sites2 = annot_models.EggAdaptationResidue.objects.filter(subtype=reference_obj.ha.subtype)
            egg_adaptation_dict2 = {
                (e.position, e.to_amino_acid):{
                    'position': e.position, 'from_aa': e.from_amino_acid, 'to_aa': e.to_amino_acid,
                    'publication': e.publication,
                } for e in egg_adaptation_sites2

            }
            position_map = alignment_obj.position_map
            ha_chain_ids = [c for c in structure_obj.chain_info if structure_obj.chain_info.get(c,{'segment':''})['segment'].lower() == 'ha']
            ha_positions = []
            query_res_count = 0
            reference_res_count = 0
            for idx, (q, r) in enumerate(zip(alignment_input_ref['query_aligned'], alignment_input_ref['reference_aligned'])):
                query_idx = query_res_count + alignment_input_ref['query_start']
                ref_idx = reference_res_count + alignment_input_ref['reference_start']
                pmaps = position_map.get(str(ref_idx),[])
                d = {
                    'index_line': '|' if (ref_idx % 10) == 0 else None,
                    'query_idx': query_idx,
                    'query_residue': q,
                    'reference_residue': r,
                    'ref_idx' : ref_idx,
                    'selector': ' or '.join(["{}:{}".format(pr['chain_residue_number'], pr['chain_id']) for pr in pmaps if pr['chain_id'] in ha_chain_ids]),
                    'chain_residue': None,
                    'chain_residue_number': None,
                    'rel_sasa': None,
                    'sasa': None,
                    'pair_potential': None,
                }
                if d['selector'].strip() == '':
                    d['selector'] = None
                for pmap in pmaps:
                    # print(pmap)
                    if pmap['chain_id'] in ha_chain_ids:
                        d['chain_id'] = pmap['chain_id']
                        d['chain_residue'] = pmap['chain_residue']
                        d['reference_residue'] = pmap['reference_residue']
                        d['chain_residue_number'] = pmap['chain_residue_number']
                        d['rel_sasa'] = structure_obj.relative_sasa.get(str(pmap['chain_residue_number']), None)
                        d['sasa'] = structure_obj.sasa.get(str(pmap['chain_residue_number']), None)
                        d['pair_potential'] = structure_obj.pair_potential.get(str(pmap['chain_residue_number']), None)
                ha_positions.append(d)
                if q != '-':
                    query_res_count += 1
                if r != '-':
                    reference_res_count += 1
            ha_positions_rows = {row_idx:ha_positions[i:i+100] for row_idx, i in enumerate(range(0, len(ha_positions), 100))}

            ctx = {
                'input_option_text': input_option.lower(),
                'input_sequence_id': input_sequence_id,
                'pdb_file': structure_obj.pdb_file.replace(settings.MEDIA_ROOT, '/media'),
                'structure_obj': structure_obj,
                'chain_info': structure_obj.chain_info,
                'position_map': alignment_obj.position_map,
                'ha_positions': ha_positions,
                'ha_positions_rows': ha_positions_rows,
            }

            return render(request, self.template_name, ctx)
        else:
            messages.error(request, mark_safe("<strong>Please fix the issues in the form.</strong>"))
            return redirect("proteins:submit_structure_visualization")


def collect_glyc_sites_conversion(glyc_sites):
    site_conversion = {}
    for idx in glyc_sites:
        site = glyc_sites[idx]
        start = site['aa_start'] + 1
        site_conversion[start] = idx
        site_conversion[start+1] = idx
        site_conversion[start+2] = idx
    return site_conversion

def collect_mutations_for_structure_visualization(alignment_input_vac, vaccine2reference, position_map, structure_obj, ref_obj, input_glyc_sites, vaccine_glyc_sites, egg_adaptation_dict, egg_adaptation_dict2={}):
    # Returns mutations list and triple alignment list
    # mutations contains dicts: ref_idx, qry_idx, vac_aa, qry_aa, mutation_selector for each reference position
    # triple_alignment contains tuples: (query_res, ref_res, pdb_res(if any)) for each position(query-ref)
    # glyc_sites is a dict for the input protein, not vaccine or others
        # {'1': {'aa_end': 26, 'aa_motif': 'NST', 'aa_start': 23},
        # '2': {'aa_end': 40, 'aa_motif': 'NGT', 'aa_start': 37},
        # '3': {'aa_end': 56, 'aa_motif': 'NAT', 'aa_start': 53},
        # '4': {'aa_end': 63, 'aa_motif': 'NSS', 'aa_start': 60},
        # '5': {'aa_end': 81, 'aa_motif': 'NCT', 'aa_start': 78},
        # '6': {'aa_end': 140, 'aa_motif': 'NES', 'aa_start': 137},
        # '7': {'aa_end': 144, 'aa_motif': 'NWT', 'aa_start': 141},
        # '8': {'aa_end': 151, 'aa_motif': 'NGT', 'aa_start': 148},
        # '9': {'aa_end': 183, 'aa_motif': 'NVT', 'aa_start': 180},
        # '10': {'aa_end': 264, 'aa_motif': 'NST', 'aa_start': 261},
        # '11': {'aa_end': 303, 'aa_motif': 'NGS', 'aa_start': 300},
        # '12': {'aa_end': 501, 'aa_motif': 'NET', 'aa_start': 498}}
    


    # numbering is based on the reference sequence
    vac_idx = alignment_input_vac['reference_start']
    qry_idx = alignment_input_vac['query_start']
    
    triple_alignment = []  # (query, vaccine, pdb) residues
    substitutions = []  # triple_alignment items for substitutions only
    chains = {
        # to store chain-id => pdb-length and indel-count, substitution-count
        # if indel-count > 80% pdb-length, assume the input does not contain sequence for this chain
        # if substitution-count > 80% pdb-length, assume the input contains something else than this chain 
    }
    input_glyc_site_index = collect_glyc_sites_conversion(input_glyc_sites)
    vaccine_glyc_site_index = collect_glyc_sites_conversion(vaccine_glyc_sites)

    for ref_i in position_map:
        pmaps = position_map[ref_i]
        for pm in pmaps:
            chain_id = pm['chain_id']
            if chain_id not in chains:
                chains[chain_id] = {
                    'pdb_length': 1,
                    'Indel_count': 0,
                    'Substitution_count': 0,
                }
            else:
                chains[chain_id]['pdb_length'] += 1
    
    for i, (v, q) in enumerate(zip(alignment_input_vac['reference_aligned'], alignment_input_vac['query_aligned'])):
        ref_idx = vaccine2reference.get(vac_idx, None)
        if ref_idx:
            ref_idx -= len(ref_obj.signal_peptide)
        pmaps = position_map.get(str(ref_idx), None)
        if pmaps:
            pdb_residues = [{'chain_id': p['chain_id'], 'residue_number': p['chain_residue_number'], 'residue': p['chain_residue']} for p in pmaps]
            epitope_name = structure_obj.epitopes.get(pdb_residues[0]['chain_id'], '').get(str(pdb_residues[0]['residue_number']), None)
            rel_sasa = structure_obj.relative_sasa.get(pdb_residues[0]['chain_id'],{}).get(str(pdb_residues[0]['residue_number']), None)
            pair_potential = structure_obj.pair_potential.get(pdb_residues[0]['chain_id'],{}).get(str(pdb_residues[0]['residue_number']), None)
            selector = ' or '.join(["{}:{}".format(pr['residue_number'], pr['chain_id'],) for pr in pdb_residues])
        else:
            pdb_residues = []
            epitope_name = None
            rel_sasa = None
            pair_potential = None
            selector = None
        mismatch_type = None
        if v != q:
            # mismatch
            mismatch_type = 'Indel' if (v=='-') or (q=='-') else 'Substitution'

        if qry_idx in input_glyc_site_index:
            input_glyc_site = input_glyc_sites[input_glyc_site_index[qry_idx]]
        else:
            input_glyc_site = None
        if vac_idx in vaccine_glyc_site_index:
            vaccine_glyc_site = vaccine_glyc_sites[vaccine_glyc_site_index[vac_idx]]
        else:
            vaccine_glyc_site = None
        
        if vaccine_glyc_site and (not input_glyc_site):
            # glyc. site losing mutation
            glyc_site_change = -1
            
        elif (not vaccine_glyc_site) and input_glyc_site:
            # glyc. site adding mutation
            glyc_site_change = 1
        else:
            # glyc. site not changed
            glyc_site_change = None

        if (ref_idx, q) in egg_adaptation_dict:
            query_egg_adaptation = egg_adaptation_dict[(ref_idx, q)]
        else:
            query_egg_adaptation = None
        if (ref_idx, v) in egg_adaptation_dict:
            vaccine_egg_adaptation = egg_adaptation_dict[(ref_idx, v)]
        else:
            vaccine_egg_adaptation = None

            # {
            #     'position': e.position, 'from_aa': e.from_amino_acid, 'to_aa': e.to_amino_acid,
            #     'publication': e.publication,
            # }

        if (ref_idx, q) in egg_adaptation_dict2:
            query_egg_adaptation_tag = egg_adaptation_dict2[(ref_idx, q)]
        else:
            query_egg_adaptation_tag = None
        if (ref_idx, v) in egg_adaptation_dict2:
            vaccine_egg_adaptation_tag = egg_adaptation_dict2[(ref_idx, v)]
        else:
            vaccine_egg_adaptation_tag = None

        t = {
            'qry_aa': q,
            'qry_idx': qry_idx,
            'vac_idx': vac_idx,
            'ref_idx': ref_idx,  # offset applied for signal peptide length
            'vac_aa': v,
            'mismatch_type': mismatch_type,
            'pdb_residues': pdb_residues,  # later filtered by chains_not_compared
            'rel_sasa': rel_sasa,  # relative sasa for the first chain residue
            'pair_potential': pair_potential, # pair potential for the first chain residue
            'selector': selector,
            'chain_tag': None,  # warning, not compared, etc for the chain
            'query_residue_tag': None,  # leading gap, hidden, etc for the residue
            'reference_residue_tag': None,
            'pdb_residue_tag': None,
            'epitope_name': epitope_name,
            'qry_glycosylation': input_glyc_site,
            'vac_glycosylation': vaccine_glyc_site,
            'glyc_site_change' : glyc_site_change,
            'qry_egg_adaptation': query_egg_adaptation,
            'vac_egg_adaptation': vaccine_egg_adaptation,
            'qry_egg_adaptation_pub': query_egg_adaptation_tag,
            'vac_egg_adaptation_pub': vaccine_egg_adaptation_tag
        }
        triple_alignment.append(t)
        if mismatch_type:
            if mismatch_type == 'Substitution':
                charge_change = {'from':'', 'to':''}
                aa_class_change = {'from':'', 'to':''}
                t = {
                    'qry_aa': q,
                    'ref_idx': ref_idx,  # offset applied for signal peptide length
                    'vac_aa': v,
                    'rel_sasa': rel_sasa,  # relative sasa for the first chain residue
                    'pair_potential': pair_potential, # pair potential for the first chain residue
                    'selector': selector,
                    'epitope_name': epitope_name,
                    'qry_glycosylation': input_glyc_site,
                    'vac_glycosylation': vaccine_glyc_site,
                    'glyc_site_change' : glyc_site_change,
                    'qry_egg_adaptation': query_egg_adaptation,
                    'vac_egg_adaptation': vaccine_egg_adaptation,
                    'qry_egg_adaptation_pub': query_egg_adaptation_tag,
                    'vac_egg_adaptation_pub': vaccine_egg_adaptation_tag
                }
                substitutions.append(t)

        if v != '-':
            # ref aa exists;
            vac_idx += 1
        if q != '-':
            # query aa exists
            qry_idx += 1
    
    chains_not_compared = []
    chains_warning = []
    for c in chains:
        if (float(chains[c]['Indel_count']) / chains[c]['pdb_length']) > 0.8:
            chains_not_compared.append(c)
        if (float(chains[c]['Substitution_count']) / chains[c]['pdb_length']) > 0.8:
            chains_warning.append(c)

    selectors = {
        'leading_gaps': [],
        'trailing_gaps': [],
        'indels': [],
        'substitutions': [],
    }
    for t in triple_alignment:
        for pr in t['pdb_residues']:
            chain_id = pr['chain_id']
            if chain_id in chains_not_compared:
                t['chain_tag'] = 'not_compared'
            if chain_id in chains_warning:
                t['chain_tag'] = 'warning'
        if len(t['pdb_residues']) == 0:
            t['pdb_residue_tag'] = 'hidden'
        if t['qry_aa'] == '-':
            if t['qry_idx'] == 1:
                # leading gap for input sequence
                t['query_residue_tag'] = 'leading_gap'
                selectors['leading_gaps'] += t['pdb_residues']
            elif t['qry_idx'] == qry_idx:
                # trailing gap for input sequence
                t['query_residue_tag'] = 'trailing_gap'
                selectors['trailing_gaps'] += t['pdb_residues']        
        elif t['vac_aa'] == '-':
            if t['vac_idx'] == 1:
                # leading gap for reference sequence
                t['reference_residue_tag'] = 'leading_gap'
                selectors['leading_gaps'] += t['pdb_residues']
            elif t['vac_idx'] == vac_idx:
                # trailing gap for reference sequence
                t['reference_residue_tag'] = 'trailing_gap'
                selectors['trailing_gaps'] += t['pdb_residues']
        elif t['mismatch_type'] is not None:
            # not leading/trailing gap, but a mismatch
            if t['mismatch_type'].lower() == 'indel':
                selectors['indels'] += t['pdb_residues']
            elif t['mismatch_type'].lower() == 'substitution':
                selectors['substitutions'] += t['pdb_residues']
    
    for sele in selectors:
        selector_string = ' or '.join(["{}:{}".format(s['residue_number'], s['chain_id']) for s in selectors[sele]])
        selectors[sele] = selector_string if selector_string != '' else '0'

    return {
        'triple_alignment': triple_alignment,
        'substitutions': substitutions,
        'chains_not_compared': chains_not_compared,  # chain IDs to NOT show mutated residues
        'chains_warning': chains_warning,  # chains with too many substitutions; warning
        'residue_selectors' : selectors,  # 8:A or 9:A or ,... to select residues on 3D structure for coloring
    }

def get_vaccine2reference_dict(vaccine_obj, reference_obj):
    vaccine2reference_obj = models.VaccineToReferenceHemagglutinin.objects.filter(vaccine=vaccine_obj).filter(reference=reference_obj).first()
    vaccine2reference = {}
    vac_idx = vaccine2reference_obj.vaccine_start
    ref_idx = vaccine2reference_obj.reference_start
    for i, (v, r) in enumerate(zip(vaccine2reference_obj.vaccine_aligned, vaccine2reference_obj.reference_aligned)):
        if v != '-':
            vaccine2reference[vac_idx] = ref_idx
            vac_idx += 1
        if r != '-':
            ref_idx += 1
    return vaccine2reference

class PairwiseAlignmentStructureView(TemplateView):
    template_name = "proteins/pairwise_alignment_structure.html"

    def get(self, request):
        subtype = "H3"
        pdb_id = "5w42"
        vaccine_name = "A/Sydney/5/97"
        
        input_seq = models.Hemagglutinin.objects.all().filter(subtype__name=subtype).first()  # user input will replace this
        reference_obj = models.ReferenceHemagglutinin.objects.filter(reference_name=subtype).first()  # may include vaccine sequences
        structure_obj = models.PDBStructure.objects.filter(pdb_id=pdb_id).first()
        vaccine_obj = models.VaccineHemagglutinin.objects.filter(ha__isolate__name__iexact=vaccine_name).first()
        vaccine2reference = get_vaccine2reference_dict(vaccine_obj, reference_obj)
        
        alignment_obj = models.ReferenceHemagglutininStructureAligned.objects.filter(structure=structure_obj).filter(reference=reference_obj).first()

        alignment_input_vac = sa.pairwise_align(ref_seq=vaccine_obj.ha.sequence, query_seq=input_seq.sequence)
        position_map = alignment_obj.position_map # reference residue number -> [{'reference_residue':'G', 'chain_id': 'A', 'chain_residue_number': 32, 'chain_residue': 'G'}]

        egg_adaptation_sites = annot_models.EggAdaptationEnrichmentScore.objects.filter(subtype=reference_obj.ha.subtype).filter(score__gte=0.5)
        egg_adaptation_dict = {
            (e.position, e.amino_acid):{
                'score':e.score, 'count_original': e.count_original,
                'count_cell': e.count_cell, 'count_egg': e.count_egg,
                'position': e.position, 'amino_acid': e.amino_acid,
            } 
            for e in egg_adaptation_sites
        }

        mutation_info = collect_mutations_for_structure_visualization(alignment_input_vac, vaccine2reference, position_map, structure_obj, reference_obj, egg_adaptation_dict)
        ctx = {
            'pdb_file': structure_obj.pdb_file.replace(settings.MEDIA_ROOT, '/media'),
            'structure_obj': structure_obj,
            'reference_obj': reference_obj,
            'vaccine_obj': vaccine_obj,
            'chain_info': structure_obj.chain_info,
            'residue_selectors': mutation_info['residue_selectors'],
            'triple_alignment': mutation_info['triple_alignment'],
            'chains_not_compared': mutation_info['chains_not_compared'],
            'chains_warning': mutation_info['chains_warning'],
            'substitutions': mutation_info['substitutions'],
        }
        return render(request, self.template_name, ctx)


    def post(self, request):
        form = forms.PairwiseComparisonForm(request.POST, request.FILES or None)
        aa_pattern = re.compile("[A-Z]+")
        if form.is_valid():
            input_option = form.cleaned_data.get('input_option') # upload or choose
            input_sequence = form.cleaned_data.get('input_sequence')  # sequence text
            if input_option.lower() == 'upload':
                # get sequence from user-input
                input_sequence_lines = input_sequence.splitlines()
                if input_sequence_lines[0].startswith('>'):
                    # input_id provided
                    input_sequence_id = input_sequence_lines[0].replace('>','').split('|')[0]
                    input_sequence = ''.join(input_sequence_lines[1:])
                else:
                    input_sequence_id = None
                    input_sequence = ''.join(input_sequence_lines)
                input_clade = "Unknown"
                input_glyc_sites = glyc.find_glycosylation_sites(input_sequence)
                if not aa_pattern.fullmatch(input_sequence):
                    # sequence contains wrong characters
                    messages.error(request, mark_safe("<strong>Non-standard amino acid found in sequence. It cannot be aligned.</strong>"))
                    return redirect("proteins:submit_pairwise_alignment")
            elif input_option.lower() == 'choice':
                # get sequence from db
                input_strain_name = form.cleaned_data.get('input_strain_name').strip().lstrip()  # ''
                input_ha = models.Hemagglutinin.objects.filter(
                    Q(accession__iexact=input_strain_name) |
                    Q(isolate__accession__iexact=input_strain_name) |
                    Q(isolate__name__iexact=input_strain_name)
                )
                if input_ha.count() == 0:
                    # input sequence not found in db
                    messages.error(request, mark_safe("<strong>Could not find {} from the database.</strong><br />Some isolate names contain leading-0s or underscores instead of spaces, for example, <code>A/North_Carolina/02/2021</code> instead of <code>A/North Carolina/2/2021</code>.<br />If molecule ID is available, please use it <code>(e.g. EPI1942772)</code>. Otherwise, please paste amino acid sequence using <strong>'upload sequence' mode.</strong>".format(input_strain_name)))
                    return redirect("proteins:submit_pairwise_alignment")
                else:
                    input_ha = input_ha.first()
                    input_sequence = input_ha.sequence
                    input_sequence_id = input_strain_name
                    if input_ha.isolate.clade:
                        input_clade = input_ha.isolate.clade.full_name
                    else:
                        input_clade = "Unknown"
                    glycs = annot_models.HemagglutininGlycosylationSite.objects.filter(protein=input_ha).first()
                    if glycs:
                        input_glyc_sites = glycs.protein_sites
                    else:
                        input_glyc_sites = None

            input_sequence_count_x = input_sequence.count('X')
            if (input_sequence_count_x >= 10) or ((input_sequence_count_x/len(input_sequence))>0.02):
                messages.warning(request, mark_safe("<strong>Warning: input sequence is of low quality, containing {} unknown amino acid 'X'.</strong>".format(input_sequence_count_x)))

            vaccine_obj = form.cleaned_data.get('vaccine')  # vaccine
            vaccine_glyc_sites = annot_models.HemagglutininGlycosylationSite.objects.filter(protein=vaccine_obj.ha).first().protein_sites
            structure_obj = form.cleaned_data.get('pdb_structure')  # pdb_structure
            if vaccine_obj.ha.subtype != structure_obj.molecule_subtype:
                # subtype mismatch
                messages.warning(request, mark_safe("<strong>Warning: Vaccine - Structure subtype mismatch ({} - {}).</strong>".format(
                    vaccine_obj.ha.subtype, structure_obj.molecule_subtype)))

            if vaccine_obj.ha.isolate.clade:
                vaccine_clade = vaccine_obj.ha.isolate.clade.full_name
            else:
                vaccine_clade = "Unknown"
            reference_obj = models.ReferenceHemagglutinin.objects.filter(reference_name=si.STRUCTURE2REFERENCENAME[structure_obj.pdb_id]).first()

            alignment_obj = models.ReferenceHemagglutininStructureAligned.objects.filter(structure=structure_obj).filter(reference=reference_obj).first()
            if alignment_obj is None:
                # reference-structure alignment is missing
                position_map = ref2pdb.get_position_map(reference_obj, structure_obj)
                alignment_obj, created = models.ReferenceHemagglutininStructureAligned.objects.get_or_create(
                    reference=reference_obj, structure=structure_obj, position_map=position_map
                )

            egg_adaptation_sites = annot_models.EggAdaptationEnrichmentScore.objects.filter(subtype=reference_obj.ha.subtype).filter(score__gte=0.5)
            egg_adaptation_dict = {
                (e.position, e.amino_acid):{
                    'score':e.score, 'count_original': e.count_original,
                    'count_cell': e.count_cell, 'count_egg': e.count_egg,
                    'position': e.position, 'amino_acid': e.amino_acid,
                } 
                for e in egg_adaptation_sites
            }
            egg_adaptation_sites2 = annot_models.EggAdaptationResidue.objects.filter(subtype=reference_obj.ha.subtype)
            egg_adaptation_dict2 = {
                (e.position, e.to_amino_acid):{
                    'position': e.position, 'from_aa': e.from_amino_acid, 'to_aa': e.to_amino_acid,
                    'publication': e.publication,
                } for e in egg_adaptation_sites2

            }
            position_map = alignment_obj.position_map
            alignment_input_vac = sa.pairwise_align(ref_seq=vaccine_obj.ha.sequence, query_seq=input_sequence)
            vaccine2reference = get_vaccine2reference_dict(vaccine_obj, reference_obj)
            mutation_info = collect_mutations_for_structure_visualization(alignment_input_vac, vaccine2reference, position_map, structure_obj, reference_obj, input_glyc_sites, vaccine_glyc_sites, egg_adaptation_dict, egg_adaptation_dict2=egg_adaptation_dict2)


            ctx = {
                'pdb_file': structure_obj.pdb_file.replace(settings.MEDIA_ROOT, '/media'),
                'structure_obj': structure_obj,
                'reference_obj': reference_obj,
                'reference_strain': reference_obj.ha.isolate,
                'vaccine_obj': vaccine_obj,
                'vaccine_clade': vaccine_clade,
                'chain_info': structure_obj.chain_info,
                'residue_selectors': mutation_info['residue_selectors'],
                'triple_alignment': mutation_info['triple_alignment'],
                'chains_not_compared': mutation_info['chains_not_compared'],
                'chains_warning': mutation_info['chains_warning'],
                'substitutions': mutation_info['substitutions'],
                'input_sequence_id': input_sequence_id,
                'input_clade': input_clade,
            }
            return render(request, self.template_name, ctx)

        else:
            messages.error(request, mark_safe("<strong>Please fix the issues in the form.</strong>"))
            return redirect("proteins:submit_pairwise_alignment")

class IsolateView(TemplateView):
    template_name = "proteins/isolates.html"

    def get(self, request):
        ctx = {
            'last_update': models.UpdateHistory.objects.latest(),
            'download_form': forms.DownloadForm(),
            'msa_form': forms.MSAForm(),
        }

        return render(request, self.template_name, ctx)



class HemagglutininView(TemplateView):
    template_name = "proteins/hemagglutnins.html"

    def get(self, request):
        ctx = {
            'last_update': models.UpdateHistory.objects.latest()
        }
        
        return render(request, self.template_name, ctx)


class NeuraminidaseView(TemplateView):
    template_name = "proteins/neuraminidases.html"

    def get(self, request):
        ctx = {
            'last_update': models.UpdateHistory.objects.latest()
        }
        
        return render(request, self.template_name, ctx)