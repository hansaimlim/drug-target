/* Project specific Javascript goes here. */

function showLoader(){
    $("#loading-overlay").show();
}

function hideLoader(){
    $("#loading-overlay").hide();
}

function redirectTo(url){
    window.location = url;
}

function submitForm(form){
    form.submit();
}

function showLoaderOnClick(){
    showLoader();
}

